# Quickshell — Entorno de escritorio Wayland (variante Hyprland)

Barra de tareas + lanzador + workspaces + calendario + wallpapers + idle
inhibitor + luz nocturna + audio + red (con selección de Wi-Fi y
contraseña) + portapapeles + tray + power menu + notificaciones + tema
claro/oscuro + brillo + ventana activa + captura de pantalla (completa y
de área) + visor de ventanas abiertas + control de medios + panel de
configuración de la barra.

Incluye el **modo Caelestia** (marco redondeado alrededor de toda la
pantalla y paneles integrados a la barra) y **workspaces fijos siempre
visibles** (1..5 por defecto). Portado desde la variante Sway
(`~/.config/quickshell/sway`), manteniendo los backends nativos de
Hyprland (`Quickshell.Hyprland`, `hyprctl`, `hyprpaper`).

> ⚠️ Esto se construyó en un sandbox aislado sin pantalla ni Quickshell
> instalado, así que **no se pudo probar en vivo**. Cópialo a tu máquina real
> y ajusta lo que necesites — te dejo abajo cómo depurarlo.

## 1. Instalar dependencias

Funciona mejor con **Hyprland** (usa `Quickshell.Hyprland` para workspaces y
ventana activa). Si usas otro compositor wlroots, hay que cambiar esa parte
(ver sección "Otros compositores").

```bash
# Quickshell (compílalo o usa el paquete de tu distro/AUR)
# https://quickshell.outfoxxed.me/docs/

sudo apt install brightnessctl wl-clipboard network-manager grim slurp libnotify-bin
# cliphist (portapapeles) - no está en apt, instala el binario:
#   https://github.com/sentriz/cliphist/releases
# swww (wallpapers con transición, opcional) - compílalo o usa el binario:
#   https://github.com/LGFae/swww/releases
# hyprpaper (wallpapers, alternativa nativa de Hyprland a swww)
sudo apt install hyprpaper
# wlsunset (luz nocturna)
sudo apt install wlsunset
```

Necesitas una **Nerd Font** instalada (los iconos de la barra son glifos
Nerd Font, ej. `JetBrainsMono Nerd Font`).

```bash
sudo apt install fonts-jetbrains-mono
# o instala manualmente una Nerd Font: https://www.nerdfonts.com/
```

## 2. Copiar los archivos

```bash
mkdir -p ~/.config/quickshell
cp -r shell.qml modules config services scripts ~/.config/quickshell/
chmod +x ~/.config/quickshell/scripts/*.sh
```

No olvides la carpeta `scripts/` — la captura de pantalla de área depende
de ella (ver sección 9).

## 3. Ajustar rutas y detalles personales

- `services/Wallpaper.qml` → cambia `directory` si tus wallpapers no están
  en `~/Pictures/Wallpapers`.
- `modules/PowerMenu.qml` → el botón "Salir" usa `hyprctl dispatch exit`;
  cámbialo por el comando de logout de tu compositor si no usas Hyprland.
- `config/Theme.qml` → colores de la paleta clara/oscura y el color de
  acento (`accent`). Cambia a gusto o intégralo con `matugen`/`wallust` para
  generar acento desde el wallpaper.

## 4. Ejecutar

```bash
quickshell -c ~/.config/quickshell
```

Para que arranque solo con tu compositor, añade esa línea a tu autostart
(en Hyprland, `~/.config/hypr/hyprland.conf`):

```
exec-once = quickshell
```

## 5. Atajos de teclado recomendados (Hyprland)

Añade en `hyprland.conf`:

```
bind = SUPER, D, exec, qs ipc call launcher toggle
bind = SUPER, ESCAPE, exec, qs ipc call powermenu toggle
bind = SUPER, V, exec, qs ipc call clip toggle
bind = SUPER, T, exec, qs ipc call theme toggle
bind = SUPER, W, exec, qs ipc call wallpaper toggle
bind = SUPER, SHIFT, W, exec, qs ipc call wifi toggle
bind = SUPER, TAB, exec, qs ipc call windowswitcher toggle
bind = SUPER, COMMA, exec, qs ipc call barsettings toggle
```

(`qs` es el CLI de Quickshell; si tu binario se llama distinto ajusta el
comando.)

## 6. Otros compositores (Sway, River, etc.)

Los módulos atados a Hyprland son:

- `modules/Workspaces.qml` (usa `Quickshell.Hyprland.workspaces.values`)
- `modules/ActiveWindow.qml` (usa `Hyprland.activeToplevel`)
- `modules/WindowSwitcherPanel.qml` (usa `hyprctl clients -j`)
- `modules/PowerMenu.qml` (el botón "Salir" llama `hyprctl dispatch hl.dsp.exit()`)
- `services/Wallpaper.qml` (backends `hyprpaper` / `swww` / `swaybg`)
- `scripts/apply-colors.sh` (aplica `colors.lua` a Hyprland y el tema GTK)

Todo lo demás (audio, red, bluetooth, brillo, notificaciones, tray, launcher,
clip, calendario, idle inhibitor, luz nocturna, tema, apariencia/Caelestia) es
agnóstico del compositor. Para Sway, sustituye esos archivos por los de la
variante en `~/.config/quickshell/sway/` — la estructura visual no cambia,
solo el origen de datos.

## 7. Apariencia: Clásico vs Caelestia

El panel de configuración (icono 󰢻 de la barra, o
`qs ipc call barsettings toggle`) tiene una pestaña **Apariencia** con:

- **Tema**: Claro / Oscuro (equivalente al IPC `theme toggle`).
- **Estilo**: Clásico (tarjetas flotantes separadas de la barra) o
  **Caelestia** (marco redondeado alrededor de toda la pantalla y tarjetas
  unidas a la barra, con las esquinas del lado unido a escuadra).
- **Paneles integrados a la barra**: Wi-Fi, Bluetooth, portapapeles, fondo
  de pantalla, ventanas abiertas, calendario, ajustes rápidos y el propio
  panel de ajustes se pegan al borde de la barra.
- **Borde redondeado de pantalla**: línea fina alrededor de todo el borde,
  unida a la barra. Es decorativa: deja pasar todos los clics.

Elegir "Caelestia" activa las dos opciones de arriba; se pueden ajustar por
separado. Todo se guarda en `~/.local/state/quickshell-bar-config.json`.

La capa de la barra es `Overlay` y el marco (`ScreenFrame`) va en `Top`:
Overlay > Top por protocolo, así que los iconos de la barra quedan siempre
por encima de la banda opaca del marco, con independencia del orden de
creación de las superficies.

## 8. Workspaces fijos (1..5)

`modules/Workspaces.qml` muestra **siempre** los workspaces 1..5, estén
creados o no: los no creados se pintan atenuados y al hacer clic se crean y
se salta a ellos (`hyprctl dispatch hl.dsp.focus({workspace=N})`). El
estado (activo/ocupado) se lee de `Hyprland.workspaces.values` (reactivo).

- Para cambiar la cantidad, edita `property int count: 5` en
  `modules/Workspaces.qml`.
- Para volver al comportamiento dinámico (solo los workspaces que existan),
  pon `count: 0`.

> Si además quieres que los workspaces 1-5 sean **persistentes** (que sigan
> existiendo tras reiniciar la sesión), añade reglas de workspace
> `persistent = true` en `~/.config/hypr/hyprland.lua`. Eso es configuración
> del compositor, independiente del shell.

## 9. Estructura del proyecto

```
shell.qml                      punto de entrada
config/
  Theme.qml                     colores, radios, modo claro/oscuro (singleton)
  BarConfig.qml                 posición/escala/módulos/apariencia (singleton)
  DockConfig.qml / WidgetsConfig.qml
services/
  Audio.qml                     Pipewire (volumen/mute)
  Network.qml                   nmcli (wifi/ethernet)
  Bluetooth.qml                 bluetoothctl
  Brightness.qml                brightnessctl
  NightLight.qml                wlsunset
  IdleInhibitor.qml             systemd-inhibit
  Wallpaper.qml                 hyprpaper / swww / swaybg
  Notifs.qml                    NotificationServer
  Apps.qml                      DesktopEntries (.desktop)
  RunningApps.qml               ventanas abiertas (dock)
  ClipHistory.qml               cliphist
  Wallhaven.qml                 wallhaven.cc
  SystemStats.qml               CPU/RAM
modules/
  Bar.qml                       barra principal (junta todo), capa Overlay
  ScreenFrame.qml               marco de pantalla (Caelestia), capa Top
  PanelSurface.qml              silueta con fillets de unión a la barra
  Workspaces.qml                workspaces fijos 1..count (Quickshell.Hyprland)
  ActiveWindow.qml              ventana activa (Hyprland.activeToplevel)
  Clock.qml / Calendar.qml / Tray.qml / MediaControls.qml
  QuickSettings.qml             panel wifi/nightlight/idle/tema/volumen/brillo
  Launcher.qml                  lanzador de apps
  PowerMenu.qml                 apagar/reiniciar/suspender/bloquear/salir
  WindowSwitcherPanel.qml       visor de ventanas abiertas (hyprctl clients)
  WallpaperPanel.qml            selector de wallpapers + wallhaven
  WiFiPanel.qml / BluetoothPanel.qml
  ClipHistoryPanel.qml          panel visual del portapapeles
  BarSettingsPanel.qml          panel de configuración (Barra/Dock/Widgets/Apariencia)
  NotificationPopups.qml        popups de notificaciones entrantes
  VolumeOSD.qml                 OSD de volumen
  Screenshot.qml                captura completa y de área en la barra
scripts/
  screenshot-full.sh            grim + wl-copy + notify-send
  screenshot-area.sh            slurp + grim + wl-copy + notify-send
  apply-colors.sh               matugen -> colors.lua + colors.ini + GTK
  apply-gtk-theme.sh            tema GTK según modo claro/oscuro
matugen-templates/
  hyprland-colors.lua.template     plantilla de bordes de Hyprland
  fuzzel-colors.ini.template       plantilla de colores de fuzzel
  accent-color.txt.template        acento del shell
```

> La variante Sway del mismo proyecto vive en `~/.config/quickshell/sway/`
> (mismos módulos visuales, backends `swaymsg`/`swaybg`). Esta es la
> variante Hyprland: no la mezcles con la de Sway.

## 10. Sobre la captura de pantalla (por qué usa scripts externos)

`Screenshot.qml` **no** lanza `grim`/`slurp` directamente como hijo de
Quickshell. En Hyprland con scripting Lua (0.55+), un proceso spawneado
directamente por Quickshell no logra que `slurp` obtenga el grab de
teclado/mouse que necesita para dibujar su superficie de selección: se
queda colgado sin mostrar nada y sin ningún error (confirmado probando en
vivo). En cambio, lanzarlo a través del propio mecanismo de ejecución de
Hyprland (`hyprctl dispatch "hl.dsp.exec_cmd(...)"`) sí funciona, así que
la captura de área delega el trabajo real a `scripts/screenshot-area.sh` y
lo invoca por ahí.

Si en tu sistema esto tampoco funciona, o prefieres una herramienta con más
funciones (anotar, recortar, subir a imgur, etc.), puedes reemplazar el
contenido de los scripts por una herramienta externa con GUI propia, por
ejemplo:

- **hyprshot** (script hecho específicamente para Hyprland, envuelve
  grim+slurp+hyprctl él mismo): `sudo apt install hyprshot` si está
  disponible, o instálalo desde su repo. Reemplaza el contenido de
  `screenshot-area.sh` por `hyprshot -m region`.
- **flameshot** (GUI completa con editor de anotaciones, buen soporte
  Wayland/wlroots reciente): `sudo apt install flameshot`. Reemplaza por
  `flameshot gui`.

En ambos casos, como ya se invocan a través de `hyprctl dispatch
hl.dsp.exec_cmd(...)`, deberían heredar el mismo tratamiento de sesión que
ya confirmamos que funciona, sin tener que tocar nada más de `Screenshot.qml`.

## 11. Theming automático desde el wallpaper (matugen → Hyprland + fuzzel)

Cada vez que eliges un wallpaper desde el panel del shell, se genera y
aplica automáticamente una paleta de color extraída de esa imagen:

- **Bordes de ventana de Hyprland** (`col.active_border` / `col.inactive_border`):
  aplicados en caliente al instante, y persistidos para que sigan así tras
  reiniciar.
- **Colores de fuzzel** (fondo, selección, borde, texto): persistidos, se
  ven la próxima vez que abras fuzzel.

Herramienta usada: **matugen** (no está en los repos de Debian):

```bash
sudo apt install cargo
cargo install matugen
# el binario queda en ~/.cargo/bin/matugen — asegúrate de que esté en tu PATH
```

### Configuración (una sola vez)

1. Copia la config y las plantillas:
   ```bash
   mkdir -p ~/.config/matugen
   cp matugen-config.toml ~/.config/matugen/config.toml
   cp -r matugen-templates ~/.config/quickshell/
   ```
2. En `~/.config/hypr/hyprland.lua`, agrega esta línea cerca del principio
   (después de que exista `hl`, típicamente al final del archivo, antes de
   cualquier `hl.config({...})` tuyo si quieres que tus propios ajustes de
   `col.active_border`/`col.inactive_border` tengan prioridad — o al final
   si prefieres que el theming generado gane):
   ```lua
   pcall(dofile, os.getenv("HOME") .. "/.config/hypr/colors.lua")
   ```
   (`pcall` evita que Hyprland falle al arrancar si `colors.lua` todavía no
   existe la primera vez, antes de elegir un wallpaper por primera vez).
3. En `~/.config/fuzzel/fuzzel.ini`, agrega esta línea en la sección
   principal (antes de cualquier `[sección]`, o dentro de `[main]` si ya la
   tienes):
   ```ini
   include=~/.config/fuzzel/colors.ini
   ```

### Probarlo manualmente

```bash
~/.config/quickshell/scripts/apply-colors.sh ~/Pictures/Wallpapers/tu-imagen.png dark
```

Si todo está bien conectado, deberías ver cambiar los bordes de las
ventanas activas/inactivas al instante.

### Si algo no aplica

- El shell registra todo con el prefijo `[Wallpaper] apply-colors:` en la
  terminal donde corres `quickshell -c ~/.config/quickshell` — revisa ahí
  primero.
- Los nombres exactos de los "roles" de color que usan las plantillas
  (`colors.primary.default.hex_stripped`, `colors.outline...`, etc.) sí
  pueden cambiar entre versiones de matugen — si las plantillas no
  renderizan, corre `matugen image tu-imagen.png -m dark --dump-json` (o el
  flag equivalente de tu versión) para ver los nombres reales disponibles
  y ajusta `matugen-templates/*.template` en consecuencia.
- Puedes desactivar el theming automático sin desinstalar nada: en
  `services/Wallpaper.qml`, pon `colorThemingEnabled: false`.

Puedes reemplazar por completo este mecanismo por `pywal`, `wallust`, o
cualquier otra herramienta de theming: solo tendrías que cambiar
`scripts/apply-colors.sh` para que llame a esa herramienta en vez de
matugen, y ajustar cómo se genera `colors.lua`/`colors.ini`.

## 12. Depuración

Corre en una terminal con el compositor activo:

```bash
quickshell -c ~/.config/quickshell 2>&1 | tee /tmp/quickshell.log
```

Los errores de QML (imports rotos, propiedades mal escritas) aparecen ahí
con archivo y línea exacta — es la forma más rápida de iterar.

## 13. Personalización rápida

- Cambia `Theme.radiusLarge/Medium/Small` para más o menos redondeo.
- Cambia `Theme.accent` para el color de acento global.
- `Theme.barHeight` controla el alto de la barra.
