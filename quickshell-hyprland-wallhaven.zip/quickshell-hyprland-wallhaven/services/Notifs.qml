pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Services.Notifications

/*
  Servicio de notificaciones. El popup (NotificationPopup.qml) se encarga
  de mostrarse un tiempo y luego llamar a dismiss(id).
*/
Singleton {
    id: notifs

    property var list: []

    NotificationServer {
        id: server
        keepOnReload: false
        onNotification: notification => {
            notification.tracked = true
            var entry = {
                id: notification.id,
                appName: notification.appName,
                summary: notification.summary,
                body: notification.body,
                icon: notification.appIcon,
                urgent: notification.urgency === NotificationUrgency.Critical,
                time: new Date()
            }
            notifs.list = [entry].concat(notifs.list).slice(0, 30)
        }
    }

    function dismiss(id) {
        notifs.list = notifs.list.filter(n => n.id !== id)
    }

    function clearAll() {
        notifs.list = []
    }
}
