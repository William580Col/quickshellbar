pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Wayland
import "../config"

/*
  Puente entre el dock y el compositor: ventanas abiertas (vía
  wlr-foreign-toplevel, sirve en hypr/sway/umbriel si el compositor lo
  implementa), cruce con los .desktop instalados y modelo combinado
  fijadas + abiertas para el dock.
*/
Singleton {
    id: running

    // Refresco periódico: las señales del modelo no siempre llegan a los
    // bindings, así el dock y la ocultación inteligente van al día.
    property var items: []
    property bool smartHidden: false

    function norm(s) {
        if (!s) return ""
        s = String(s).toLowerCase()
        if (s.endsWith(".desktop")) s = s.slice(0, -8)
        return s
    }

    function entryId(entry) {
        if (!entry) return ""
        if (entry.id !== undefined && entry.id) return norm(entry.id)
        return norm(entry.name)
    }

    // Busca el .desktop que corresponde a un appId de ventana.
    function matchEntry(appId) {
        var a = norm(appId)
        if (!a) return null
        var list = Apps.entries
        var fallback = null
        for (var i = 0; i < list.length; i++) {
            var e = list[i]
            var id = entryId(e)
            if (id === a) return e
            if (fallback === null && (id.endsWith("." + a) || a.endsWith("." + id)))
                fallback = e
        }
        return fallback
    }

    function entryById(id) {
        var n = norm(id)
        var list = Apps.entries
        for (var i = 0; i < list.length; i++) {
            if (entryId(list[i]) === n) return list[i]
        }
        return null
    }

    function toplevelsFor(id) {
        var n = norm(id)
        var out = []
        var vals = ToplevelManager.toplevels.values
        for (var i = 0; i < vals.length; i++) {
            var t = vals[i]
            if (!t || t.minimized) continue
            var e = matchEntry(t.appId)
            var tid = e ? entryId(e) : norm(t.appId)
            if (tid === n) out.push(t)
        }
        return out
    }

    function activateEntry(id) {
        var tops = toplevelsFor(id)
        if (tops.length === 0) {
            var e = entryById(id)
            if (e) Apps.launch(e)
            return
        }
        var top = tops[tops.length - 1]
        if (top.activated) top.minimized = true
        else {
            top.minimized = false
            top.activate()
        }
    }

    function refresh() {
        var seen = {}
        var model = []
        // 1) Fijadas (solo las instaladas).
        var pins = DockConfig.pinned
        for (var i = 0; i < pins.length; i++) {
            var e = entryById(pins[i])
            if (!e) continue
            var id = entryId(e)
            seen[id] = true
            var tops = toplevelsFor(id)
            model.push({
                entryId: id, name: e.name, icon: e.icon ? e.icon : "",
                pinned: true, running: tops.length > 0,
                active: tops.some(t => t.activated),
                sepBefore: false
            })
        }
        // 2) Abiertas no fijadas.
        var vals = ToplevelManager.toplevels.values
        for (var j = 0; j < vals.length; j++) {
            var t = vals[j]
            if (!t || t.minimized) continue
            var me = matchEntry(t.appId)
            var mid = me ? entryId(me) : norm(t.appId)
            if (!mid || seen[mid]) continue
            seen[mid] = true
            var mtops = toplevelsFor(mid)
            model.push({
                entryId: mid,
                name: me ? me.name : (t.title ? t.title : mid),
                icon: me && me.icon ? me.icon : "application-x-executable",
                pinned: false, running: true,
                active: mtops.some(x => x.activated),
                sepBefore: model.length > 0
            })
        }
        running.items = model
        // 3) Ocultación inteligente: hay alguna ventana activa
        // (enfocada); sin ventana activa el dock queda visible.
        var at = ToplevelManager.activeToplevel
        running.smartHidden = !!at
    }

    function togglePin(id) { DockConfig.togglePin(id); refresh() }

    Timer {
        interval: 800
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: running.refresh()
    }
}
