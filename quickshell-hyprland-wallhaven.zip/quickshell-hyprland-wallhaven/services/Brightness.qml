pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Control de brillo via brightnessctl.
  Instalar: sudo apt install brightnessctl  (y añadir el usuario al grupo video)
*/
Singleton {
    id: brightness

    property real value: 1.0 // 0..1
    property int max: 100
    property int current: 100

    function refresh() { getProc.running = true }

    function set(v) {
        var pct = Math.round(Math.max(1, Math.min(100, v * 100)))
        setProc.command = ["brightnessctl", "set", pct + "%"]
        setProc.running = true
        value = pct / 100
    }

    function increase(step) { set(value + (step || 0.05)) }
    function decrease(step) { set(value - (step || 0.05)) }

    Component.onCompleted: refresh()

    Process {
        id: getProc
        command: ["sh", "-c", "brightnessctl g; brightnessctl m"]
        stdout: SplitParser {
            onRead: data => {
                var n = parseInt(data.trim())
                if (!isNaN(n) && n > 0) {
                    if (n > brightness.max) brightness.max = n
                    brightness.current = n
                    brightness.value = brightness.current / brightness.max
                }
            }
        }
    }

    Process { id: setProc; command: ["true"] }
}
