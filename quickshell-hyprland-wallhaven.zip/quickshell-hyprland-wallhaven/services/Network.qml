pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Servicio de red envolviendo nmcli. Requiere NetworkManager instalado.
*/
Singleton {
    id: net

    property string status: "disconnected" // disconnected | ethernet | wifi
    property string ssid: ""
    property int strength: 0
    property bool wifiEnabled: true
    property var wifiList: []
    property bool scanning: false

    // Estado de conexión en curso, para dar feedback en la UI
    property string connecting: "" // ssid al que se está intentando conectar, "" si ninguno
    property string lastError: ""

    function refresh() {
        statusProc.running = true
        wifiEnabledProc.running = true
    }

    function scan() {
        scanning = true
        net._scanBuf = []
        listProc.running = true
    }

    property var _scanBuf: []

    function connectTo(ssid, password) {
        net.connecting = ssid
        net.lastError = ""
        var cmd = password && password.length > 0
            ? ["nmcli", "device", "wifi", "connect", ssid, "password", password]
            : ["nmcli", "device", "wifi", "connect", ssid]
        connectProc.command = cmd
        connectProc.running = true
    }

    function disconnect(ssid) {
        disconnectProc.command = ["nmcli", "connection", "down", "id", ssid]
        disconnectProc.running = true
    }

    function toggleWifi() {
        toggleProc.command = ["nmcli", "radio", "wifi", wifiEnabled ? "off" : "on"]
        toggleProc.running = true
    }

    Timer {
        interval: 8000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: net.refresh()
    }

    Process {
        id: statusProc
        command: ["sh", "-c", "nmcli -t -f TYPE,STATE,CONNECTION device status | grep -E '^(wifi|ethernet):connected' | head -1"]
        stdout: SplitParser {
            onRead: data => {
                if (data.indexOf("ethernet") === 0) {
                    net.status = "ethernet"
                    net.ssid = ""
                } else if (data.indexOf("wifi") === 0) {
                    net.status = "wifi"
                    var parts = data.split(":")
                    net.ssid = parts[2] || ""
                } else {
                    net.status = "disconnected"
                    net.ssid = ""
                }
            }
        }
    }

    Process {
        id: wifiEnabledProc
        command: ["nmcli", "radio", "wifi"]
        stdout: SplitParser {
            onRead: data => { net.wifiEnabled = data.trim() === "enabled" }
        }
    }

    Process {
        id: listProc
        command: ["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "device", "wifi", "list"]
        stdout: SplitParser {
            onRead: line => {
                if (line.trim().length > 0) net._scanBuf.push(line.trim())
            }
        }
        onExited: {
            var seen = {}
            var out = []
            for (var i = 0; i < net._scanBuf.length; i++) {
                var parts = net._scanBuf[i].split(":")
                var s = parts[0]
                if (!s || seen[s]) continue
                seen[s] = true
                out.push({ ssid: s, signal: parseInt(parts[1] || "0"), secure: (parts[2] || "") !== "" })
            }
            out.sort((a, b) => b.signal - a.signal)
            net.wifiList = out
            net.scanning = false
        }
    }

    Process {
        id: connectProc
        property string buf: ""
        stdout: SplitParser { onRead: line => connectProc.buf += line + " " }
        stderr: SplitParser { onRead: line => connectProc.buf += line + " " }
        onExited: (code, status) => {
            if (code !== 0) {
                net.lastError = connectProc.buf.trim() || "No se pudo conectar"
            } else {
                net.lastError = ""
            }
            connectProc.buf = ""
            net.connecting = ""
            net.refresh()
            net.scan()
        }
    }

    Process {
        id: disconnectProc
        onExited: {
            net.refresh()
            net.scan()
        }
    }

    Process { id: toggleProc; command: ["true"] }
}
