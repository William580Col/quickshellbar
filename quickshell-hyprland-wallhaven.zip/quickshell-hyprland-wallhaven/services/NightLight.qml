pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Luz nocturna via wlsunset.
  Instalar: sudo apt install wlsunset

  IMPORTANTE: wlsunset necesita SABER cuándo es de noche. Tiene dos modos:
    1) Coordenadas geográficas: -l LATITUD -L LONGITUD (calcula amanecer/atardecer real)
    2) Horas fijas: -S HH:MM (amanecer) -s HH:MM (atardecer)
  Sin ninguna de las dos, wlsunset falla al arrancar SIN avisar en el log de
  quickshell (por eso parecía que "no hacía nada"). Aquí capturamos su
  stderr para que el error se vea, y usamos horas fijas por defecto que
  puedes cambiar por tus coordenadas reales abajo.
*/
Singleton {
    id: nightlight

    property bool active: false
    property int tempLow: 4000
    property int tempHigh: 6500

    // --- Opción A (recomendada): tus coordenadas reales ---
    // Ejemplo Ibagué, Colombia: lat 4.44, lon -75.23
    property real latitude: 4.44
    property real longitude: -75.23
    property bool useCoordinates: true

    // --- Opción B: horas fijas (se usan si useCoordinates = false) ---
    property string sunrise: "06:30"
    property string sunset: "18:00"

    property string lastError: ""

    function toggle() { active ? stop() : start() }

    function start() {
        var args = ["wlsunset", "-t", tempLow.toString(), "-T", tempHigh.toString()]
        if (useCoordinates) {
            args = args.concat(["-l", latitude.toString(), "-L", longitude.toString()])
        } else {
            args = args.concat(["-S", sunrise, "-s", sunset])
        }
        nightlight.lastError = ""
        proc.command = args
        proc.running = true
        active = true
    }

    function stop() {
        killProc.running = true
        active = false
    }

    Process {
        id: proc
        stderr: SplitParser {
            onRead: line => {
                nightlight.lastError = line
                console.warn("[NightLight] wlsunset:", line)
            }
        }
        onExited: (code, status) => {
            if (code !== 0 && nightlight.active) {
                console.warn("[NightLight] wlsunset terminó con código", code, "-", nightlight.lastError)
                nightlight.active = false
            }
        }
    }

    Process {
        id: killProc
        command: ["pkill", "-x", "wlsunset"]
    }
}
