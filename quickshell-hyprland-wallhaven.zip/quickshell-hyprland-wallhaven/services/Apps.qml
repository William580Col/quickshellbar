pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Lista de aplicaciones instaladas, leyendo los .desktop del sistema
  con el propio DesktopEntries de Quickshell.
*/
Singleton {
    id: apps

    property var entries: {
        var list = []
        for (var i = 0; i < DesktopEntries.applications.values.length; i++) {
            var e = DesktopEntries.applications.values[i]
            if (e.noDisplay) continue
            list.push(e)
        }
        list.sort((a, b) => a.name.localeCompare(b.name))
        return list
    }

    function search(query) {
        if (!query || query.length === 0) return entries
        var q = query.toLowerCase()
        return entries.filter(e =>
            (e.name && e.name.toLowerCase().indexOf(q) !== -1) ||
            (e.genericName && e.genericName.toLowerCase().indexOf(q) !== -1)
        )
    }

    function launch(entry) {
        entry.execute()
    }
}
