pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Búsqueda de wallpapers en Wallhaven (https://wallhaven.cc). Usa la API
  pública (no requiere API key para búsquedas SFW). Las miniaturas se
  cargan directamente por red (QtQuick.Image soporta http/https nativo);
  solo se descarga la imagen completa cuando el usuario elige aplicarla.

  Purity fijo en "100" (solo contenido SFW) — no expuesto como opción.
*/
Singleton {
    id: wallhaven

    property string query: "landscape"
    property var categories: { "general": true, "anime": true, "people": true }
    property int page: 1
    property int lastPage: 1
    property int total: 0
    property var results: []
    property bool loading: false
    property bool downloading: false
    property string lastError: ""

    property string cacheDir: Quickshell.env("HOME") + "/Pictures/Wallpapers/wallhaven"

    function categoryMask() {
        return (categories.general ? "1" : "0") +
               (categories.anime ? "1" : "0") +
               (categories.people ? "1" : "0")
    }

    function toggleCategory(name) {
        var c = Object.assign({}, categories)
        c[name] = !c[name]
        // que no queden las 3 apagadas a la vez, o la API no devuelve nada
        if (!c.general && !c.anime && !c.people) c[name] = true
        categories = c
        wallhaven.page = 1
        search()
    }

    function setQuery(q) {
        wallhaven.query = q
        wallhaven.page = 1
        search()
    }

    function nextPage() {
        if (wallhaven.page < wallhaven.lastPage) {
            wallhaven.page += 1
            search()
        }
    }
    function prevPage() {
        if (wallhaven.page > 1) {
            wallhaven.page -= 1
            search()
        }
    }

    function search() {
        wallhaven.loading = true
        wallhaven.lastError = ""
        var q = encodeURIComponent(wallhaven.query)
        var url = "https://wallhaven.cc/api/v1/search?q=" + q +
                   "&categories=" + wallhaven.categoryMask() +
                   "&purity=100&page=" + wallhaven.page
        searchProc.command = ["curl", "-s", "-A", "quickshell-wallpaper-panel", url]
        searchProc.running = true
    }

    Process {
        id: searchProc
        property string buf: ""
        stdout: SplitParser { onRead: line => searchProc.buf += line }
        stderr: SplitParser { onRead: line => console.warn("[Wallhaven] curl:", line) }
        onExited: (code, status) => {
            wallhaven.loading = false
            if (code !== 0) {
                wallhaven.lastError = "No se pudo conectar con Wallhaven"
                searchProc.buf = ""
                return
            }
            try {
                var data = JSON.parse(searchProc.buf)
                if (data.error) {
                    wallhaven.lastError = data.error
                    wallhaven.results = []
                } else {
                    wallhaven.results = data.data || []
                    wallhaven.lastPage = (data.meta && data.meta.last_page) || 1
                    wallhaven.total = (data.meta && data.meta.total) || 0
                }
            } catch (e) {
                wallhaven.lastError = "Respuesta inesperada de Wallhaven"
                console.warn("[Wallhaven] Error parseando JSON:", e)
            }
            searchProc.buf = ""
        }
    }

    // Descarga la imagen completa y la deja en la carpeta de wallpapers
    // (así también queda disponible luego en la pestaña "Local", con su
    // miniatura cacheada igual que cualquier otro wallpaper).
    function downloadAndApply(item) {
        var fullUrl = item.path
        if (!fullUrl) return
        var ext = fullUrl.split(".").pop().split("?")[0]
        var fileName = "wallhaven-" + item.id + "." + ext
        var dest = wallhaven.cacheDir + "/" + fileName

        wallhaven.downloading = true
        downloadProc.destPath = dest
        downloadProc.command = ["sh", "-c",
            "mkdir -p '" + wallhaven.cacheDir + "' && " +
            "curl -sL -A 'quickshell-wallpaper-panel' '" + fullUrl + "' -o '" + dest + "'"]
        downloadProc.running = true
    }

    Process {
        id: downloadProc
        property string destPath: ""
        stderr: SplitParser { onRead: line => console.warn("[Wallhaven] descarga:", line) }
        onExited: (code, status) => {
            wallhaven.downloading = false
            if (code === 0) {
                wallhaven.downloadFinished(downloadProc.destPath)
            } else {
                wallhaven.lastError = "No se pudo descargar la imagen"
            }
        }
    }

    // Señal simple para que el panel reaccione (aplicar como wallpaper,
    // refrescar la lista local, etc.)
    signal downloadFinished(string path)
}
