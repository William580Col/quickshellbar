pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import "../config"

/*
  Manejo de wallpapers para Hyprland. Prioridad de backends detectados
  automáticamente al arrancar:
    1) swww      - transiciones bonitas (no está en Debian, instalar aparte)
    2) hyprpaper - nativo de Hyprland, controlado por hyprctl IPC
    3) swaybg    - universal, sin transición (fallback final)

  hyprpaper: sudo apt install hyprpaper
  swaybg:    sudo apt install swaybg
  swww:      https://github.com/LGFae/swww (binario/cargo/AUR)

  NOTA sobre hyprpaper 0.8.4+: la solicitud "preload" ya no existe (fue
  eliminada). Confirmado con "hyprctl hyprpaper --help": el único request
  es "wallpaper", formato [mon],[path],[fit_mode]. Tampoco existe un "todos
  los monitores" fiable con monitor vacío, así que consultamos
  "hyprctl monitors -j" y aplicamos el wallpaper a cada monitor por nombre.
*/
Singleton {
    id: wallpaper

    property string directory: Quickshell.env("HOME") + "/Pictures/Wallpapers"
    property string statePath: Quickshell.env("HOME") + "/.local/state/quickshell-wallpaper"
    property string thumbDir: Quickshell.env("HOME") + "/.cache/quickshell/wallpaper-thumbs"
    property string current: ""
    property var list: []
    property string backend: "swaybg" // "swww" | "hyprpaper" | "swaybg"
    property bool backendChecked: false

    // Si tienes matugen instalado, cada wallpaper nuevo también genera y
    // aplica una paleta de color a los bordes de Hyprland y a fuzzel.
    // Pon esto en 'false' si no quieres theming automático o no tienes
    // matugen instalado (ver README, sección de theming con matugen).
    property bool colorThemingEnabled: true

    // Modo de ajuste ("center" | "fill" | "stretch"). Solo tiene efecto
    // real con el backend swaybg (bandera -m). hyprpaper SÍ tiene un
    // tercer parámetro opcional "fit_mode" en su formato
    // [mon],[path],[fit_mode] (ver comentario de arriba), pero no se pudo
    // confirmar en vivo qué valores exactos acepta esa versión — si
    // quieres cablearlo, revisa "hyprctl hyprpaper --help" y ajusta
    // applyToMonitors(). swww no tiene una bandera equivalente en su CLI.
    property string fitMode: "fill"

    function setFitMode(mode) {
        wallpaper.fitMode = mode
        if (wallpaper.current.length > 0) wallpaper.set(wallpaper.current)
    }

    Component.onCompleted: {
        checkProc.running = true
        refresh()
    }

    function refresh() {
        wallpaper.list = []
        listProc.command = ["sh", "-c", "find '" + directory + "' -maxdepth 1 -type f \\( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o -iname '*.webp' \\) 2>/dev/null | sort"]
        listProc.running = true
    }

    function set(path) {
        current = path
        wallpaper.saveState(path)
        if (colorThemingEnabled) wallpaper.applyColorTheme(path)
        var escaped = path.replace(/'/g, "'\\''")

        if (backend === "swww") {
            setSwwwProc.command = ["swww", "img", path, "--transition-type", "wipe", "--transition-duration", "1"]
            setSwwwProc.running = true

        } else if (backend === "hyprpaper") {
            // hyprpaper 0.8+ eliminó el request "preload": ahora "wallpaper"
            // es el único request y basta con [mon],[path],[fit_mode].
            // Consultamos los monitores reales y aplicamos a cada uno.
            hyprpaperPendingPath = escaped
            monitorsProc.running = true

        } else {
            // swaybg no permite "cambiar" en caliente: matar y relanzar,
            // desacoplado con setsid (no 'disown', que no existe en sh/dash).
            setSwaybgProc.command = ["sh", "-c",
                "pkill -x swaybg 2>/dev/null; sleep 0.2; " +
                "setsid swaybg -i '" + escaped + "' -m " + wallpaper.fitMode + " " +
                ">/tmp/swaybg.log 2>&1 < /dev/null &"]
            setSwaybgProc.running = true
        }
    }

    property string hyprpaperPendingPath: ""

    function random() {
        if (list.length === 0) return
        set(list[Math.floor(Math.random() * list.length)])
    }

    // Ruta de la miniatura cacheada para una imagen dada. Se usa el path
    // completo (con "/" -> "_") como nombre, así nunca hay colisiones y no
    // hace falta ninguna herramienta de hash externa.
    function thumbPathFor(path) {
        return thumbDir + "/" + path.replace(/\//g, "_") + ".jpg"
    }

    // Genera (una sola vez, cacheado en disco) una miniatura pequeña por
    // cada wallpaper con ImageMagick, para que abrir el panel sea rápido
    // incluso con muchas imágenes de alta resolución. Si no tienes
    // ImageMagick instalado, esto no hace nada y el panel simplemente usa
    // las imágenes originales (más lento, pero sigue funcionando).
    function generateThumbnails() {
        if (wallpaper.list.length === 0) return
        var script = "mkdir -p '" + thumbDir + "'; "
        script += "command -v convert >/dev/null 2>&1 || exit 0; "
        for (var i = 0; i < wallpaper.list.length; i++) {
            var src = wallpaper.list[i]
            var thumb = wallpaper.thumbPathFor(src)
            var escSrc = src.replace(/'/g, "'\\''")
            var escThumb = thumb.replace(/'/g, "'\\''")
            script += "[ -f '" + escThumb + "' ] || convert '" + escSrc + "[0]' -auto-orient -thumbnail '320x180^' -gravity center -extent 320x180 '" + escThumb + "' 2>/dev/null; "
        }
        thumbProc.command = ["sh", "-c", script]
        thumbProc.running = true
    }

    Process {
        id: thumbProc
        stderr: SplitParser { onRead: line => console.warn("[Wallpaper] miniatura:", line) }
    }

    // Detecta el mejor backend disponible, en orden de preferencia
    Process {
        id: checkProc
        command: ["sh", "-c",
            "if command -v swww >/dev/null 2>&1; then echo swww; " +
            "elif command -v hyprpaper >/dev/null 2>&1; then echo hyprpaper; " +
            "else echo swaybg; fi"]
        stdout: SplitParser {
            onRead: line => {
                wallpaper.backend = line.trim()
                wallpaper.backendChecked = true
                if (wallpaper.backend === "swww") {
                    daemonProc.command = ["sh", "-c", "pgrep -x swww-daemon >/dev/null || setsid swww-daemon >/tmp/swww-daemon.log 2>&1 < /dev/null &"]
                    daemonProc.running = true
                } else if (wallpaper.backend === "hyprpaper") {
                    daemonProc.command = ["sh", "-c", "pgrep -x hyprpaper >/dev/null || setsid hyprpaper >/tmp/hyprpaper.log 2>&1 < /dev/null &"]
                    daemonProc.running = true
                } else {
                    console.warn("[Wallpaper] Ni 'swww' ni 'hyprpaper' encontrados, usando 'swaybg'. Revisa /tmp/swaybg.log si no cambia la imagen.")
                }
                startupTimer.restart()
            }
        }
    }

    // Al arrancar (nueva sesión), reaplica el último wallpaper guardado.
    // El delay le da tiempo al daemon (hyprpaper/swww-daemon/swaybg) y a
    // que Hyprland tenga los monitores listos antes de aplicar.
    Timer {
        id: startupTimer
        interval: 1500
        repeat: false
        onTriggered: wallpaper.loadSavedWallpaper()
    }

    function loadSavedWallpaper() {
        loadStateProc.running = true
    }

    function saveState(path) {
        saveStateProc.command = ["sh", "-c",
            "mkdir -p \"$(dirname '" + wallpaper.statePath + "')\" && printf '%s' '" +
            path.replace(/'/g, "'\\''") + "' > '" + wallpaper.statePath + "'"]
        saveStateProc.running = true
    }

    Process {
        id: loadStateProc
        command: ["sh", "-c", "cat '" + wallpaper.statePath + "' 2>/dev/null || true"]
        stdout: SplitParser {
            onRead: line => {
                var p = line.trim()
                if (p.length > 0) wallpaper.set(p)
            }
        }
    }

    Process { id: saveStateProc }

    // Genera la paleta con matugen (a partir del wallpaper) y la aplica a
    // Hyprland (en caliente + persistente) y a fuzzel (persistente).
    // Ver scripts/apply-colors.sh para el detalle. Modo claro/oscuro sigue
    // al toggle de tema del propio shell (config/Theme.qml).
    function applyColorTheme(path) {
        var mode = Theme.dark ? "dark" : "light"
        var script = Quickshell.env("HOME") + "/.config/quickshell/scripts/apply-colors.sh"
        colorThemeProc.command = ["sh", "-c", "'" + script + "' '" + path.replace(/'/g, "'\\''") + "' '" + mode + "'"]
        colorThemeProc.running = true
    }

    Process {
        id: colorThemeProc
        stdout: SplitParser { onRead: line => console.log("[Wallpaper] apply-colors:", line) }
        stderr: SplitParser { onRead: line => console.warn("[Wallpaper] apply-colors:", line) }
        onExited: (code, status) => {
            if (code !== 0) {
                console.warn("[Wallpaper] apply-colors.sh salió con código", code, "(¿tienes matugen instalado?)")
            } else {
                Theme.reloadAccent()
            }
        }
    }

    Process { id: daemonProc }

    Process {
        id: listProc
        stdout: SplitParser {
            onRead: line => {
                if (line.trim().length > 0) wallpaper.list.push(line.trim())
                wallpaper.listChanged()
            }
        }
        onExited: wallpaper.generateThumbnails()
    }

    Process {
        id: setSwwwProc
        stderr: SplitParser { onRead: line => console.warn("[Wallpaper] swww:", line) }
    }

    // Paso 1: consultar monitores reales
    Process {
        id: monitorsProc
        command: ["hyprctl", "monitors", "-j"]
        property string buf: ""
        stdout: SplitParser { onRead: line => monitorsProc.buf += line }
        onExited: {
            try {
                var monitors = JSON.parse(monitorsProc.buf)
                var names = monitors.map(m => m.name)
                wallpaper.applyToMonitors(names)
            } catch (e) {
                console.warn("[Wallpaper] Error parseando monitores:", e)
            }
            monitorsProc.buf = ""
        }
    }

    // Paso 2: aplicar el wallpaper a cada monitor por nombre (formato
    // confirmado con "hyprctl hyprpaper --help": [mon],[path],[fit_mode])
    function applyToMonitors(names) {
        if (names.length === 0) {
            console.warn("[Wallpaper] No se encontraron monitores")
            return
        }
        var cmds = names.map(n => "hyprctl hyprpaper wallpaper '" + n + "," + hyprpaperPendingPath + "'")
        applyProc.command = ["sh", "-c", cmds.join(" && ")]
        applyProc.running = true
    }

    Process {
        id: applyProc
        stdout: SplitParser { onRead: line => console.log("[Wallpaper] hyprpaper wallpaper:", line) }
        stderr: SplitParser { onRead: line => console.warn("[Wallpaper] hyprpaper wallpaper:", line) }
    }

    Process {
        id: setSwaybgProc
        stderr: SplitParser { onRead: line => console.warn("[Wallpaper] swaybg (lanzador):", line) }
    }
}
