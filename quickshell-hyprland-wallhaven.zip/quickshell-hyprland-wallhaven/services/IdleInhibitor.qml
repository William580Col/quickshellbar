pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Idle inhibitor: mantiene el sistema despierto mientras 'active' es true.
  Usa systemd-inhibit sosteniendo un proceso 'sleep infinity'.
*/
Singleton {
    id: idle

    property bool active: false

    function toggle() { active = !active }

    onActiveChanged: {
        if (active) {
            proc.command = ["systemd-inhibit", "--what=idle:sleep:handle-lid-switch",
                             "--who=quickshell", "--why=Idle inhibitor activado por el usuario",
                             "sleep", "infinity"]
            proc.running = true
        } else {
            proc.running = false
        }
    }

    Process { id: proc }
}
