pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Historial de portapapeles via cliphist (requiere wl-clipboard + cliphist).
  Instalar: sudo apt install wl-clipboard ; cliphist -> https://github.com/sentriz/cliphist
*/
Singleton {
    id: clip

    property var items: [] // { raw, preview }

    Component.onCompleted: {
        watcherProc.running = true
        refresh()
    }

    function refresh() {
        clip._buf = []
        listProc.running = true
    }

    property var _buf: []

    function copy(rawLine) {
        var idx = rawLine.split("\t")[0]
        // No usar <<< aquí: /bin/sh (dash en muchas distros) no soporta
        // "here strings". Pasamos la entrada como $1 para que las comillas,
        // espacios y caracteres especiales no rompan el comando.
        copyProc.command = [
            "sh", "-c",
            "printf '%s\\n' \"$1\" | cliphist decode | wl-copy",
            "clip-copy", rawLine
        ]
        copyProc.running = true
    }

    function clearAll() {
        clearProc.running = true
        refresh()
    }

    function deleteEntry(rawLine) {
        delProc.command = [
            "sh", "-c",
            "printf '%s\\n' \"$1\" | cliphist delete",
            "clip-delete", rawLine
        ]
        delProc.running = true
        refresh()
    }

    Process {
        id: listProc
        command: ["cliphist", "list"]
        stdout: SplitParser {
            onRead: line => {
                if (line.trim().length === 0) return
                var tabIdx = line.indexOf("\t")
                clip._buf.push({ raw: line, preview: tabIdx >= 0 ? line.substring(tabIdx + 1) : line })
            }
        }
        onExited: clip.items = clip._buf.slice(0, 60)
    }

    // relanza cada 5s para mantener sincronía (cliphist no emite eventos)
    Timer { interval: 5000; running: true; repeat: true; onTriggered: clip.refresh() }

    // Mantener el proceso watcher vivo dentro de Quickshell.
    // (Hyprland puede tener además sus propios watchers; cliphist tolera
    // que se alimente desde el portapapeles.)
    Process {
        id: watcherProc
        command: ["wl-paste", "--type", "text", "--watch", "cliphist", "store"]
    }
    Process { id: copyProc }
    Process { id: clearProc; command: ["cliphist", "wipe"] }
    Process { id: delProc }
}
