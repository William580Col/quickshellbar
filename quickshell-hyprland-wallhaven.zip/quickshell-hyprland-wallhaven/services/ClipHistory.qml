pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Historial de portapapeles via cliphist (requiere wl-clipboard + cliphist).
  Soporta texto e imágenes. Instalar: sudo apt install wl-clipboard ; cliphist -> https://github.com/sentriz/cliphist
*/
Singleton {
    id: clip

    property var items: [] // { raw, preview, isImage, kind, id }
    property var _buf: []

    Component.onCompleted: {
        watcherTextProc.running = true
        watcherImageProc.running = true
        refresh()
    }

    function refresh() {
        clip._buf = []
        listProc.running = true
    }

    function copy(rawLine) {
        var idx = rawLine.split("\t")[0]
        // Mismo pipe para texto e imágenes: cliphist decode restaura el MIME original.
        // No usar <<< aquí: /bin/sh (dash en muchas distros) no soporta
        // "here strings". Pasamos la entrada como $1 para que las comillas,
        // espacios y caracteres especiales no rompan el comando.
        copyProc.command = [
            "sh", "-c",
            "printf '%s\\n' \"$1\" | cliphist decode | wl-copy",
            "clip-copy", rawLine
        ]
        copyProc.running = true
    }

    function clearAll() {
        clearProc.running = true
        refresh()
    }

    function deleteEntry(rawLine) {
        delProc.command = [
            "sh", "-c",
            "printf '%s\\n' \"$1\" | cliphist delete",
            "clip-delete", rawLine
        ]
        delProc.running = true
        refresh()
    }

    Process {
        id: listProc
        command: ["cliphist", "list"]
        stdout: SplitParser {
            onRead: line => {
                if (line.trim().length === 0) return
                var tabIdx = line.indexOf("\t")
                var idStr = tabIdx >= 0 ? line.substring(0, tabIdx) : ""
                var preview = tabIdx >= 0 ? line.substring(tabIdx + 1) : line
                var lower = preview.toLowerCase()
                var hasBinaryTag = lower.indexOf("[[ binary data") >= 0
                var hasImageMime = lower.indexOf("image/") >= 0
                var hasImageExt = lower.indexOf(".png") >= 0 || lower.indexOf(".jpg") >= 0 || lower.indexOf(".jpeg") >= 0 || lower.indexOf("webp") >= 0 || lower.indexOf("gif") >= 0 || lower.indexOf("bmp") >= 0
                var isImage = hasBinaryTag || hasImageMime || hasImageExt
                var kind = "Texto"
                var displayPreview = preview
                if (isImage) {
                    var sizeMatch = preview.match(/(\d+(?:\.\d+)?\s*(?:KiB|MiB|GiB|KB|MB|GB|B|bytes?))/i)
                    var sizeStr = sizeMatch ? sizeMatch[1].trim() : ""
                    var typeMatch = preview.match(/image\/([a-zA-Z0-9+.\-]+)/)
                    var extMatch = preview.match(/\.(png|jpe?g|webp|gif|bmp)\b/i)
                    var imgType = ""
                    if (typeMatch)
                        imgType = typeMatch[1].toUpperCase().replace("JPEG", "JPEG").replace("JPG", "JPG")
                    else if (extMatch)
                        imgType = extMatch[1].toUpperCase().replace("JPG", "JPG").replace("JPEG", "JPEG")
                    kind = "Imagen"
                    if (imgType.length > 0)
                        kind += " " + imgType
                    if (sizeStr.length > 0)
                        kind += " \u00B7 " + sizeStr
                    displayPreview = preview
                }
                var idNum = parseInt(idStr, 10)
                clip._buf.push({ raw: line, preview: displayPreview, isImage: isImage, kind: kind, id: isNaN(idNum) ? idStr : idNum })
            }
        }
        onExited: clip.items = clip._buf.slice(0, 60)
    }

    // relanza cada 5s para mantener sincronía (cliphist no emite eventos)
    Timer { interval: 5000; running: true; repeat: true; onTriggered: clip.refresh() }

    // Dos watchers vivos: texto e imágenes.
    Process {
        id: watcherTextProc
        command: ["wl-paste", "--type", "text", "--watch", "cliphist", "store"]
    }
    Process {
        id: watcherImageProc
        command: ["wl-paste", "--type", "image", "--watch", "cliphist", "store"]
    }
    Process { id: copyProc }
    Process { id: clearProc; command: ["cliphist", "wipe"] }
    Process { id: delProc }
}
