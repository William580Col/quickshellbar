import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import "../config"
import "../services" as Services

PanelWindow {
    id: root
    property bool open: false
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    function show() {
        open = true
        searchField.forceActiveFocus()
        searchField.text = ""
        root.refreshResults() // por si el texto ya estaba vacío y no dispara onTextChanged
    }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    // ¿el texto empieza con ">"? -> modo comando (ejecuta en shell en vez de buscar apps)
    property bool commandMode: searchField.text.startsWith(">")
    property string commandText: commandMode ? searchField.text.substring(1).trim() : ""

    property var results: []

    // Debounce: en vez de reemplazar el modelo de la lista en CADA tecla
    // (lo cual puede chocar con la incubación asíncrona de QML y hacer
    // crashear quickshell — bug real observado con escritura rápida),
    // esperamos un breve instante tras la última tecla antes de refrescar.
    Timer {
        id: searchDebounce
        interval: 120
        repeat: false
        onTriggered: root.refreshResults()
    }

    function refreshResults() {
        results = Services.Apps.search(searchField.text)
    }

    function runCommand(cmd) {
        cmdProc.command = ["sh", "-c", "setsid " + cmd + " >/dev/null 2>&1 < /dev/null &"]
        cmdProc.running = true
        root.hide()
    }
    Process { id: cmdProc }

    // fondo, clic fuera cierra
    MouseArea {
        anchors.fill: parent
        onClicked: root.hide()
    }

    Rectangle {
        id: box
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.16
        width: 560
        height: Math.min(460, 76 + (root.commandMode ? 1 : list.count) * 58 + 34)
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.bg)
        border.color: Theme.border
        border.width: 1
        clip: true

        Behavior on height { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }

        MouseArea { anchors.fill: parent } // evita que el clic se propague al fondo

        ColumnLayout {
            anchors.fill: parent
            spacing: 0

            // ---- Barra de búsqueda ----
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 54
                color: "transparent"
                border.color: Theme.border
                border.width: 0

                Rectangle {
                    anchors.bottom: parent.bottom
                    width: parent.width
                    height: 1
                    color: Theme.border
                }

                TextInput {
                    id: searchField
                    anchors.fill: parent
                    anchors.leftMargin: 18
                    anchors.rightMargin: 18
                    verticalAlignment: TextInput.AlignVCenter
                    color: Theme.text
                    font.pixelSize: 15
                    clip: true
                    onTextChanged: searchDebounce.restart()
                    Keys.onEscapePressed: root.hide()
                    Keys.onReturnPressed: {
                        searchDebounce.stop()
                        root.refreshResults() // asegura resultados al día antes de lanzar
                        if (root.commandMode) {
                            if (root.commandText.length > 0) root.runCommand(root.commandText)
                        } else if (list.model.length > 0) {
                            Services.Apps.launch(list.model[0])
                            root.hide()
                        }
                    }
                    Text {
                        visible: searchField.text.length === 0
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Buscar aplicaciones… o usa > para comandos"
                        color: Theme.subtext
                        font.pixelSize: 15
                    }
                }
            }

            // ---- Modo comando ----
            Rectangle {
                visible: root.commandMode
                Layout.fillWidth: true
                Layout.preferredHeight: 58
                color: "transparent"

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 10
                    Text { text: "❯"; color: Theme.accent; font.pixelSize: 16; font.bold: true }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 0
                        Text {
                            text: root.commandText.length > 0 ? root.commandText : "Escribe un comando…"
                            color: root.commandText.length > 0 ? Theme.text : Theme.subtext
                            font.pixelSize: 13
                            elide: Text.ElideRight
                        }
                        Text { text: "Enter para ejecutar"; color: Theme.subtext; font.pixelSize: 10 }
                    }
                }
            }

            // ---- Lista de aplicaciones ----
            ListView {
                id: list
                visible: !root.commandMode
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.margins: 8
                clip: true
                spacing: 2
                reuseItems: true
                model: root.results

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    width: list.width
                    height: 54
                    radius: Theme.radiusSmall
                    color: hovered ? Theme.bgAlt : "transparent"
                    property bool hovered: false

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 8
                        spacing: 12

                        Rectangle {
                            width: 34; height: 34; radius: Theme.radiusSmall
                            color: Theme.bgAlt
                            Image {
                                anchors.fill: parent
                                anchors.margins: 5
                                source: row.modelData.icon ? "image://icon/" + row.modelData.icon : ""
                                fillMode: Image.PreserveAspectFit
                            }
                        }

                        ColumnLayout {
                            spacing: 1
                            Layout.fillWidth: true
                            Text { text: row.modelData.name; color: Theme.text; font.pixelSize: 13; font.bold: true }
                            Text {
                                text: row.modelData.genericName || row.modelData.comment || ""
                                visible: text.length > 0
                                color: Theme.subtext
                                font.pixelSize: 11
                                elide: Text.ElideRight
                                Layout.fillWidth: true
                            }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        hoverEnabled: true
                        onEntered: row.hovered = true
                        onExited: row.hovered = false
                        onClicked: { Services.Apps.launch(row.modelData); root.hide() }
                    }
                }
            }

            // ---- Footer: contador de resultados ----
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 34
                color: "transparent"
                Rectangle { anchors.top: parent.top; width: parent.width; height: 1; color: Theme.border }
                Text {
                    anchors.left: parent.left
                    anchors.leftMargin: 16
                    anchors.verticalCenter: parent.verticalCenter
                    text: root.commandMode ? "Modo comando" : (root.results.length + " resultados")
                    color: Theme.subtext
                    font.pixelSize: 11
                }
            }
        }
    }
}
