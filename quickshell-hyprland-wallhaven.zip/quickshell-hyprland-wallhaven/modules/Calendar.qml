import QtQuick
import QtQuick.Layouts
import "../config"

Rectangle {
    id: root
    width: 260
    height: 300
    radius: Theme.radiusLarge
    color: BarConfig.surfaceColor(Theme.surface)
    border.color: Theme.border
    border.width: 1

    property date viewDate: new Date()
    property date today: new Date()

    function monthDays(y, m) { return new Date(y, m + 1, 0).getDate() }
    function firstWeekday(y, m) { var d = new Date(y, m, 1).getDay(); return (d + 6) % 7 } // lunes=0

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 16
        spacing: 10

        RowLayout {
            Layout.fillWidth: true
            Text {
                text: "‹"
                color: Theme.subtext
                font.pixelSize: 18
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                    onClicked: root.viewDate = new Date(root.viewDate.getFullYear(), root.viewDate.getMonth() - 1, 1) }
            }
            Text {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
                text: Qt.formatDate(root.viewDate, "MMMM yyyy")
                color: Theme.text
                font.pixelSize: 14
                font.bold: true
            }
            Text {
                text: "›"
                color: Theme.subtext
                font.pixelSize: 18
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                    onClicked: root.viewDate = new Date(root.viewDate.getFullYear(), root.viewDate.getMonth() + 1, 1) }
            }
        }

        GridLayout {
            columns: 7
            Layout.fillWidth: true
            rowSpacing: 6
            columnSpacing: 4

            Repeater {
                model: ["L", "M", "X", "J", "V", "S", "D"]
                delegate: Text {
                    Layout.preferredWidth: 30
                    horizontalAlignment: Text.AlignHCenter
                    text: modelData
                    color: Theme.subtext
                    font.pixelSize: 11
                }
            }

            Repeater {
                model: root.firstWeekday(root.viewDate.getFullYear(), root.viewDate.getMonth())
                delegate: Item { Layout.preferredWidth: 30; Layout.preferredHeight: 30 }
            }

            Repeater {
                model: root.monthDays(root.viewDate.getFullYear(), root.viewDate.getMonth())
                delegate: Rectangle {
                    Layout.preferredWidth: 30
                    Layout.preferredHeight: 30
                    radius: 15
                    property int dayNum: index + 1
                    property bool isToday: dayNum === root.today.getDate()
                        && root.viewDate.getMonth() === root.today.getMonth()
                        && root.viewDate.getFullYear() === root.today.getFullYear()
                    color: isToday ? Theme.accent : "transparent"

                    Text {
                        anchors.centerIn: parent
                        text: parent.dayNum
                        color: parent.isToday ? Theme.bg : Theme.text
                        font.pixelSize: 12
                        font.bold: parent.isToday
                    }
                }
            }
        }
    }
}
