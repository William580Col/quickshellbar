import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import "../config"

/*
  Indicador de workspaces con números. Lee el estado desde Quickshell.Hyprland,
  y el cambio de workspace se hace invocando "hyprctl dispatch" por proceso
  (sintaxis Lua confirmada para Hyprland 0.55+: hl.dsp.focus({workspace=N})).
*/
Row {
    id: root
    spacing: 6
    height: 26

    Repeater {
        model: Hyprland.workspaces

        delegate: Item {
            id: cell
            required property var modelData
            property bool active: modelData.active
            property bool hasWindows: modelData.toplevels && modelData.toplevels.count > 0

            width: pill.width
            height: 26

            Rectangle {
                id: pill
                anchors.centerIn: parent
                width: Math.max(26, label.implicitWidth + 16)
                height: 22
                radius: 11
                color: cell.active ? Theme.accent
                       : (cell.hasWindows ? Theme.bgAlt : "transparent")
                border.width: cell.active ? 0 : 1
                border.color: cell.hasWindows ? Theme.border : Qt.rgba(Theme.border.r, Theme.border.g, Theme.border.b, 0.5)

                Behavior on width { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                Behavior on color { ColorAnimation { duration: 160 } }

                Text {
                    id: label
                    anchors.centerIn: parent
                    text: cell.modelData.id
                    font.pixelSize: 11
                    font.bold: cell.active
                    color: cell.active ? Theme.bg : (cell.hasWindows ? Theme.text : Theme.subtext)
                }
            }

            MouseArea {
                anchors.fill: parent
                anchors.margins: -4
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    // Hyprland 0.55+ (config Lua) ya no acepta "hyprctl dispatch workspace N".
                    switchProc.command = ["hyprctl", "dispatch", "hl.dsp.focus({workspace = " + cell.modelData.id + "})"]
                    switchProc.running = true
                }
            }
        }
    }

    Process {
        id: switchProc
        stderr: SplitParser { onRead: line => console.warn("[Workspaces] hyprctl:", line) }
    }
}
