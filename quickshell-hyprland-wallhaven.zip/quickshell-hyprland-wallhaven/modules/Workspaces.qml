import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import "../config"

/*
  Indicador de workspaces con números para Hyprland.

  Muestra SIEMPRE los workspaces 1..count (por defecto 5), estén creados o
  no: los no creados se pintan atenuados y al hacer clic se crean y se salta
  a ellos. El estado (activo/ocupado) se lee de Quickshell.Hyprland, y el
  cambio de workspace se hace invocando "hyprctl dispatch" por proceso
  (sintaxis Lua confirmada para Hyprland 0.55+: hl.dsp.focus({workspace=N})).

  Si prefieres ver solo los workspaces que existan (sin fijar cantidad),
  pon count a 0 y el Repeater se alimenta de Hyprland.workspaces directamente.
*/
Row {
    id: root
    spacing: 6
    height: 26

    // Cuántos workspaces fijos mostrar (1..count). 0 = dinámico (todos los
    // que existan, como la variante Sway).
    property int count: 5

    // Lista fija 1..count con el estado leído de Hyprland. Se reevalúa sola
    // cuando cambia Hyprland.workspaces (values es reactivo).
    readonly property var fixedWorkspaces: {
        var out = []
        var ws = Hyprland.workspaces.values
        for (var i = 1; i <= root.count; i++) {
            var found = null
            for (var j = 0; j < ws.length; j++) {
                if (ws[j].id === i) { found = ws[j]; break }
            }
            out.push({
                id: i,
                active: found ? found.active : false,
                hasWindows: found ? (found.toplevels && found.toplevels.count > 0) : false
            })
        }
        return out
    }

    // Modelo elegido: fijo (count > 0) o dinámico (count == 0).
    readonly property var workspaceModel: root.count > 0 ? root.fixedWorkspaces : Hyprland.workspaces.values

    Repeater {
        model: root.workspaceModel

        delegate: Item {
            id: cell
            required property var modelData
            property bool active: cell.modelData.active
            property bool hasWindows: cell.modelData.hasWindows !== undefined
                ? cell.modelData.hasWindows
                : (cell.modelData.toplevels && cell.modelData.toplevels.count > 0)

            width: pill.width
            height: 26

            Rectangle {
                id: pill
                anchors.centerIn: parent
                width: Math.max(26, label.implicitWidth + 16)
                height: 22
                radius: 11
                color: cell.active ? Theme.accent
                       : (cell.hasWindows ? Theme.bgAlt : "transparent")
                border.width: cell.active ? 0 : 1
                border.color: cell.hasWindows ? Theme.border : Qt.rgba(Theme.border.r, Theme.border.g, Theme.border.b, 0.5)

                Behavior on width { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                Behavior on color { ColorAnimation { duration: 160 } }

                Text {
                    id: label
                    anchors.centerIn: parent
                    text: cell.modelData.id
                    font.pixelSize: 11
                    font.bold: cell.active
                    color: cell.active ? Theme.bg : (cell.hasWindows ? Theme.text : Theme.subtext)
                }
            }

            MouseArea {
                anchors.fill: parent
                anchors.margins: -4
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    // Hyprland 0.55+ (config Lua) ya no acepta "hyprctl dispatch workspace N".
                    switchProc.command = ["hyprctl", "dispatch", "hl.dsp.focus({workspace = " + cell.modelData.id + "})"]
                    switchProc.running = true
                }
            }
        }
    }

    Process {
        id: switchProc
        stderr: SplitParser { onRead: line => console.warn("[Workspaces] hyprctl:", line) }
    }
}
