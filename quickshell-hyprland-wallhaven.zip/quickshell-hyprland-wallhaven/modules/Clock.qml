import QtQuick
import "../config"

Text {
    id: clock
    signal clicked()

    color: Theme.text
    font.pixelSize: 13
    font.bold: true
    text: Qt.formatDateTime(now, "ddd d MMM  hh:mm")

    property date now: new Date()

    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: clock.now = new Date()
    }

    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        onClicked: clock.clicked()
    }
}
