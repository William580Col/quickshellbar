import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"

PanelWindow {
    id: root
    property bool open: false
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    function show() { open = true }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.08
        width: 480
        height: Math.min(parent.height * 0.86, layout.implicitHeight + 32)
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            id: layout
            anchors.fill: parent
            anchors.margins: 16
            spacing: 14

            Text {
                Layout.fillWidth: true
                text: "Configuración de la barra"
                color: Theme.text
                font.pixelSize: 16
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            // ---- Posición ----
            RowLayout {
                Layout.fillWidth: true
                Text { text: "Posición"; color: Theme.text; font.pixelSize: 12; Layout.fillWidth: true }
                SegButton { label: "Arriba"; active: BarConfig.position === "top"; onClicked: BarConfig.setPosition("top") }
                SegButton { label: "Abajo"; active: BarConfig.position === "bottom"; onClicked: BarConfig.setPosition("bottom") }
            }

            // ---- Auto-ocultar ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 10
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 1
                    Text { text: "Auto-ocultar"; color: Theme.text; font.pixelSize: 12 }
                    Text {
                        text: "La barra se oculta sola tras un momento sin uso y reaparece al acercar el mouse al borde."
                        color: Theme.subtext
                        font.pixelSize: 10
                        wrapMode: Text.WordWrap
                        Layout.fillWidth: true
                    }
                }
                CheckBox { checked: BarConfig.autoHide; onToggled: BarConfig.setAutoHide(!BarConfig.autoHide) }
            }

            // ---- Efecto cristal ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 10
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 1
                    Text { text: "Efecto cristal"; color: Theme.text; font.pixelSize: 12 }
                    Text {
                        text: "Fondo translúcido en la barra y los menús. Para blur real (no solo transparencia) agrega la regla de Hyprland indicada en el README."
                        color: Theme.subtext
                        font.pixelSize: 10
                        wrapMode: Text.WordWrap
                        Layout.fillWidth: true
                    }
                }
                CheckBox { checked: BarConfig.glassEffect; onToggled: BarConfig.setGlassEffect(!BarConfig.glassEffect) }
            }

            // ---- Escala ----
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 4
                Text { text: "Escala: " + Math.round(BarConfig.scale * 100) + "%"; color: Theme.text; font.pixelSize: 12 }
                SliderBar {
                    Layout.fillWidth: true
                    value: (BarConfig.scale - 0.8) / (1.3 - 0.8)
                    onMoved: v => BarConfig.setScale(0.8 + v * (1.3 - 0.8))
                }
            }

            Text {
                Layout.fillWidth: true
                text: "Módulos: ←/→ ordena dentro de su zona; el botón de zona rota Izq. → Centro → Der."
                color: Theme.subtext
                font.pixelSize: 10
                wrapMode: Text.WordWrap
            }

            // ---- Lista de módulos ----
            ListView {
                Layout.fillWidth: true
                Layout.preferredHeight: Math.min(300, contentHeight)
                clip: true
                spacing: 4
                model: BarConfig.modules
                interactive: contentHeight > height

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    required property int index
                    width: ListView.view.width
                    height: 44
                    radius: Theme.radiusSmall
                    color: Theme.bgAlt

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 8
                        spacing: 8

                        CheckBox {
                            checked: row.modelData.enabled
                            onToggled: BarConfig.setEnabled(row.modelData.id, !row.modelData.enabled)
                        }

                        Text {
                            text: row.modelData.label
                            color: Theme.text
                            font.pixelSize: 12
                            Layout.fillWidth: true
                        }

                        SmallIconButton { text: "←"; onClicked: BarConfig.moveModule(row.modelData.id, -1) }
                        SmallIconButton { text: "→"; onClicked: BarConfig.moveModule(row.modelData.id, 1) }

                        SegButton {
                            label: row.modelData.zone === "left" ? "Izq." : (row.modelData.zone === "center" ? "Centro" : "Der.")
                            active: true
                            onClicked: BarConfig.cycleZone(row.modelData.id)
                        }
                    }
                }
            }

            // ---- Pie: restaurar / cerrar ----
            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 4
                TextButton { label: "Restaurar"; danger: true; onClicked: BarConfig.restoreDefaults() }
                Item { Layout.fillWidth: true }
                TextButton { label: "Cerrar"; onClicked: root.hide() }
            }
        }
    }

    // ================= Componentes reutilizables =================

    component SegButton: Rectangle {
        id: seg
        property string label: ""
        property bool active: false
        signal clicked()

        Layout.preferredWidth: label.length > 5 ? 64 : 56
        Layout.preferredHeight: 30
        radius: Theme.radiusSmall
        color: active ? Theme.accent : Theme.bgAlt
        border.width: active ? 0 : 1
        border.color: Theme.border

        Text {
            anchors.centerIn: parent
            text: seg.label
            color: seg.active ? Theme.bg : Theme.subtext
            font.pixelSize: 11
            font.bold: seg.active
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: seg.clicked()
        }
    }

    component SmallIconButton: Rectangle {
        id: sib
        property string text: ""
        signal clicked()

        Layout.preferredWidth: 28
        Layout.preferredHeight: 28
        radius: Theme.radiusSmall
        color: area.containsMouse ? Theme.accent : Theme.bg
        border.width: 1
        border.color: area.containsMouse ? Theme.accent : Theme.border

        Text {
            anchors.centerIn: parent
            text: sib.text
            color: area.containsMouse ? Theme.bg : Theme.subtext
            font.pixelSize: 12
            font.bold: true
        }
        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: sib.clicked()
        }
    }

    component TextButton: Rectangle {
        id: tb
        property string label: ""
        property bool danger: false
        signal clicked()

        Layout.preferredWidth: labelText.implicitWidth + 28
        Layout.preferredHeight: 34
        radius: Theme.radiusSmall
        color: area.containsMouse ? (tb.danger ? Qt.rgba(Theme.danger.r, Theme.danger.g, Theme.danger.b, 0.15) : Theme.accent) : "transparent"
        border.width: 1
        border.color: tb.danger ? Theme.danger : Theme.accent

        Text {
            id: labelText
            anchors.centerIn: parent
            text: tb.label
            color: tb.danger ? Theme.danger : (area.containsMouse ? Theme.bg : Theme.accent)
            font.pixelSize: 12
            font.bold: true
        }
        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: tb.clicked()
        }
    }

    component CheckBox: Rectangle {
        id: cb
        property bool checked: false
        signal toggled()

        Layout.preferredWidth: 22
        Layout.preferredHeight: 22
        radius: Theme.radiusSmall
        color: cb.checked ? Theme.accent : "transparent"
        border.width: 1
        border.color: cb.checked ? Theme.accent : Theme.border

        Text {
            anchors.centerIn: parent
            visible: cb.checked
            text: "✓"
            color: Theme.bg
            font.pixelSize: 13
            font.bold: true
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: cb.toggled()
        }
    }

    component SliderBar: Item {
        id: slider
        implicitHeight: 18
        property real value: 0
        signal moved(real v)

        Rectangle {
            width: parent.width; height: 6; radius: 3
            anchors.verticalCenter: parent.verticalCenter
            color: Theme.bgAlt
            Rectangle {
                width: parent.width * Math.max(0, Math.min(1, slider.value))
                height: parent.height
                radius: 3
                color: Theme.accent
            }
        }
        MouseArea {
            anchors.fill: parent
            onPressed: mouse => slider.moved(Math.max(0, Math.min(1, mouse.x / width)))
            onPositionChanged: mouse => { if (pressed) slider.moved(Math.max(0, Math.min(1, mouse.x / width))) }
        }
    }
}
