import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"
import "../services" as Services

PanelWindow {
    id: root
    property bool open: false
    property string tab: "bar" // "bar" | "dock"
    // Fijadas con datos para la lista (se filtra lo desinstalado).
    property var dockPinnedModel: {
        var out = []
        var pins = DockConfig.pinned
        for (var i = 0; i < pins.length; i++) {
            var e = Services.RunningApps.entryById(pins[i])
            if (!e) continue
            out.push({ id: Services.RunningApps.entryId(e), name: e.name, icon: e.icon ? e.icon : "" })
        }
        return out
    }
    // Instaladas no fijadas, para añadir (depende de pinned para refrescar).
    property var dockAddModel: {
        var _dep = DockConfig.pinned.length
        var out = []
        var list = Services.Apps.entries
        for (var j = 0; j < list.length; j++) {
            var a = list[j]
            var id = Services.RunningApps.entryId(a)
            if (!id || DockConfig.isPinned(id)) continue
            out.push({ id: id, name: a.name, icon: a.icon ? a.icon : "" })
        }
        return out
    }
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    function show() { open = true }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.08
        width: 480
        height: Math.min(parent.height * 0.86, layout.implicitHeight + 32)
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1
        clip: true

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            id: layout
            anchors.fill: parent
            anchors.margins: 16
            spacing: 14

            Text {
                Layout.fillWidth: true
                text: root.tab === "dock" ? "Configuración del dock" : "Configuración de la barra"
                color: Theme.text
                font.pixelSize: 16
                font.bold: true
                horizontalAlignment: Text.AlignHCenter
            }

            // ---- Pestañas Barra | Dock ----
            RowLayout {
                Layout.fillWidth: true
                Layout.leftMargin: 60
                Layout.rightMargin: 60
                spacing: 8
                SegButton { label: "Barra"; active: root.tab === "bar"; onClicked: root.tab = "bar"; Layout.fillWidth: true }
                SegButton { label: "Dock"; active: root.tab === "dock"; onClicked: root.tab = "dock"; Layout.fillWidth: true }
            }

            // ---- Contenido con scroll (el pie queda fijo abajo) ----
            Flickable {
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumHeight: 120
                implicitHeight: central.implicitHeight
                contentHeight: central.implicitHeight
                clip: true
                interactive: contentHeight > height

                ColumnLayout {
                    id: central
                    width: parent.width
                    spacing: 14

                    // ---- Sección Barra ----
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 14
                        visible: root.tab === "bar"

                    // ---- Posición ----
                    RowLayout {
                        Layout.fillWidth: true
                        Text { text: "Posición"; color: Theme.text; font.pixelSize: 12; Layout.fillWidth: true }
                        SegButton { label: "Arriba"; active: BarConfig.position === "top"; onClicked: BarConfig.setPosition("top") }
                        SegButton { label: "Abajo"; active: BarConfig.position === "bottom"; onClicked: BarConfig.setPosition("bottom") }
                    }

                    // ---- Auto-ocultar ----
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 10
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 1
                            Text { text: "Auto-ocultar"; color: Theme.text; font.pixelSize: 12 }
                            Text {
                                text: "La barra se oculta sola tras un momento sin uso y reaparece al acercar el mouse al borde."
                                color: Theme.subtext
                                font.pixelSize: 10
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                        }
                        CheckBox { checked: BarConfig.autoHide; onToggled: BarConfig.setAutoHide(!BarConfig.autoHide) }
                    }

                    // ---- Efecto cristal ----
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 10
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 1
                            Text { text: "Efecto cristal"; color: Theme.text; font.pixelSize: 12 }
                            Text {
                                text: "Fondo translúcido en la barra y los menús. Para blur real (no solo transparencia) agrega la regla de Hyprland indicada en el README."
                                color: Theme.subtext
                                font.pixelSize: 10
                                wrapMode: Text.WordWrap
                                Layout.fillWidth: true
                            }
                        }
                        CheckBox { checked: BarConfig.glassEffect; onToggled: BarConfig.setGlassEffect(!BarConfig.glassEffect) }
                    }

                    // ---- Opacidad cristal ----
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 4
                        enabled: BarConfig.glassEffect
                        opacity: enabled ? 1.0 : 0.4
                        Text { text: "Opacidad: " + Math.round(BarConfig.glassAlpha * 100) + "%"; color: Theme.text; font.pixelSize: 12 }
                        SliderBar {
                            Layout.fillWidth: true
                            value: (BarConfig.glassAlpha - 0.2) / (1.0 - 0.2)
                            onMoved: v => BarConfig.setGlassAlpha(0.2 + v * (1.0 - 0.2))
                        }
                        Text { text: "20% muy transparente, 100% opaco."; color: Theme.subtext; font.pixelSize: 10; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                    }

                    // ---- Escala ----
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 4
                        Text { text: "Escala: " + Math.round(BarConfig.scale * 100) + "%"; color: Theme.text; font.pixelSize: 12 }
                        SliderBar {
                            Layout.fillWidth: true
                            value: (BarConfig.scale - 0.8) / (1.3 - 0.8)
                            onMoved: v => BarConfig.setScale(0.8 + v * (1.3 - 0.8))
                        }
                    }

                    Text {
                        Layout.fillWidth: true
                        text: "Módulos: ←/→ ordena dentro de su zona; el botón de zona rota Izq. → Centro → Der."
                        color: Theme.subtext
                        font.pixelSize: 10
                        wrapMode: Text.WordWrap
                    }

                    // ---- Lista de módulos ----
                    ListView {
                        Layout.fillWidth: true
                        Layout.preferredHeight: Math.min(220, contentHeight)
                        clip: true
                        spacing: 4
                        model: BarConfig.modules
                        interactive: contentHeight > height

                        delegate: Rectangle {
                            id: row
                            required property var modelData
                            required property int index
                            width: ListView.view.width - 8
                            height: 44
                            radius: Theme.radiusSmall
                            color: Theme.bgAlt
                            clip: true

                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: 6
                                spacing: 6

                                CheckBox {
                                    checked: row.modelData.enabled
                                    onToggled: BarConfig.setEnabled(row.modelData.id, !row.modelData.enabled)
                                    Layout.fillWidth: false
                                }

                                Text {
                                    text: row.modelData.label
                                    color: Theme.text
                                    font.pixelSize: 12
                                    Layout.fillWidth: true
                                    Layout.minimumWidth: 0
                                    Layout.preferredWidth: 0
                                    elide: Text.ElideRight
                                    clip: true
                                }

                                SmallIconButton { text: "←"; Layout.fillWidth: false; onClicked: BarConfig.moveModule(row.modelData.id, -1) }
                                SmallIconButton { text: "→"; Layout.fillWidth: false; onClicked: BarConfig.moveModule(row.modelData.id, 1) }

                                SegButton {
                                    label: row.modelData.zone === "left" ? "Izq." : (row.modelData.zone === "center" ? "Centro" : "Der.")
                                    active: true
                                    Layout.fillWidth: false
                                    Layout.preferredWidth: row.modelData.zone === "center" ? 58 : 52
                                    onClicked: BarConfig.cycleZone(row.modelData.id)
                                }
                            }
                        }
                    }
                    } // fin sección Barra

                    // ---- Sección Dock ----
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 14
                        visible: root.tab === "dock"

                        // Activar
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 10
                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 1
                                Text { text: "Mostrar dock"; color: Theme.text; font.pixelSize: 12 }
                                Text {
                                    text: "Pastilla flotante estilo Mac con tus apps fijadas y las abiertas."
                                    color: Theme.subtext
                                    font.pixelSize: 10
                                    wrapMode: Text.WordWrap
                                    Layout.fillWidth: true
                                }
                            }
                            CheckBox { checked: DockConfig.enabled; onToggled: DockConfig.setEnabled(!DockConfig.enabled) }
                        }

                        // Posición
                        RowLayout {
                            Layout.fillWidth: true
                            Text { text: "Posición"; color: Theme.text; font.pixelSize: 12; Layout.fillWidth: true }
                            SegButton { label: "Abajo"; active: DockConfig.position === "bottom"; onClicked: DockConfig.setPosition("bottom") }
                            SegButton { label: "Izq."; active: DockConfig.position === "left"; onClicked: DockConfig.setPosition("left") }
                            SegButton { label: "Der."; active: DockConfig.position === "right"; onClicked: DockConfig.setPosition("right") }
                        }

                        // Ocultación
                        RowLayout {
                            Layout.fillWidth: true
                            Text { text: "Ocultación"; color: Theme.text; font.pixelSize: 12; Layout.fillWidth: true }
                            SegButton { label: "Siempre"; active: DockConfig.hideMode === "always"; onClicked: DockConfig.setHideMode("always") }
                            SegButton { label: "Auto"; active: DockConfig.hideMode === "auto"; onClicked: DockConfig.setHideMode("auto") }
                            SegButton { label: "Intel."; active: DockConfig.hideMode === "smart"; onClicked: DockConfig.setHideMode("smart") }
                        }
                        Text {
                            Layout.fillWidth: true
                            text: "Siempre: visible. Auto: se oculta solo y vuelve al acercar el mouse al borde. Inteligente: se oculta si hay una ventana maximizada o a pantalla completa."
                            color: Theme.subtext
                            font.pixelSize: 10
                            wrapMode: Text.WordWrap
                        }

                        // Tamaño
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 4
                            Text { text: "Tamaño de iconos: " + Math.round(DockConfig.iconSize) + "px"; color: Theme.text; font.pixelSize: 12 }
                            SliderBar {
                                Layout.fillWidth: true
                                value: (DockConfig.iconSize - 32) / (64 - 32)
                                onMoved: v => DockConfig.setIconSize(32 + v * (64 - 32))
                            }
                        }

                        // Opacidad
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 4
                            Text { text: "Opacidad: " + Math.round(DockConfig.dockAlpha * 100) + "%"; color: Theme.text; font.pixelSize: 12 }
                            SliderBar {
                                Layout.fillWidth: true
                                value: (DockConfig.dockAlpha - 0.2) / (1.0 - 0.2)
                                onMoved: v => DockConfig.setDockAlpha(0.2 + v * (1.0 - 0.2))
                            }
                            Text { text: "20% muy transparente, 100% opaco."; color: Theme.subtext; font.pixelSize: 10; wrapMode: Text.WordWrap; Layout.fillWidth: true }
                        }

                        // Lupa
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 10
                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 1
                                Text { text: "Efecto lupa"; color: Theme.text; font.pixelSize: 12 }
                                Text {
                                    text: "Los iconos crecen al pasar el mouse, como en macOS."
                                    color: Theme.subtext
                                    font.pixelSize: 10
                                    wrapMode: Text.WordWrap
                                    Layout.fillWidth: true
                                }
                            }
                            CheckBox { checked: DockConfig.zoomEnabled; onToggled: DockConfig.setZoomEnabled(!DockConfig.zoomEnabled) }
                        }
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 4
                            enabled: DockConfig.zoomEnabled
                            opacity: enabled ? 1.0 : 0.4
                            Text { text: "Ampliación: x" + DockConfig.zoomScale.toFixed(1); color: Theme.text; font.pixelSize: 12 }
                            SliderBar {
                                Layout.fillWidth: true
                                value: (DockConfig.zoomScale - 1.2) / (2.0 - 1.2)
                                onMoved: v => DockConfig.setZoomScale(1.2 + v * (2.0 - 1.2))
                            }
                        }

                        // Fijadas
                        Text {
                            Layout.fillWidth: true
                            text: "Fijadas (clic derecho sobre un icono del dock también fija/suelta)"
                            color: Theme.subtext
                            font.pixelSize: 10
                            wrapMode: Text.WordWrap
                        }
                        ListView {
                            Layout.fillWidth: true
                            Layout.preferredHeight: Math.min(140, contentHeight)
                            clip: true
                            spacing: 4
                            model: root.dockPinnedModel
                            interactive: contentHeight > height
                            delegate: Rectangle {
                                id: pinRow
                                required property var modelData
                                width: ListView.view.width - 8
                                height: 36
                                radius: Theme.radiusSmall
                                color: Theme.bgAlt
                                clip: true
                                RowLayout {
                                    anchors.fill: parent
                                    anchors.margins: 6
                                    spacing: 8
                                    Image {
                                        source: pinRow.modelData.icon ? "image://icon/" + pinRow.modelData.icon : ""
                                        Layout.preferredWidth: 22
                                        Layout.preferredHeight: 22
                                        fillMode: Image.PreserveAspectFit
                                        Layout.fillWidth: false
                                    }
                                    Text {
                                        text: pinRow.modelData.name
                                        color: Theme.text
                                        font.pixelSize: 12
                                        Layout.fillWidth: true
                                        Layout.minimumWidth: 0
                                        Layout.preferredWidth: 0
                                        elide: Text.ElideRight
                                        clip: true
                                    }
                                    SmallIconButton { text: "✕"; Layout.fillWidth: false; onClicked: DockConfig.unpin(pinRow.modelData.id) }
                                }
                            }
                        }

                        // Añadir
                        Text {
                            Layout.fillWidth: true
                            text: "Añadir aplicaciones"
                            color: Theme.subtext
                            font.pixelSize: 10
                            wrapMode: Text.WordWrap
                        }
                        ListView {
                            Layout.fillWidth: true
                            Layout.preferredHeight: Math.min(140, contentHeight)
                            clip: true
                            spacing: 4
                            model: root.dockAddModel
                            interactive: contentHeight > height
                            delegate: Rectangle {
                                id: addRow
                                required property var modelData
                                width: ListView.view.width - 8
                                height: 36
                                radius: Theme.radiusSmall
                                color: Theme.bgAlt
                                clip: true
                                RowLayout {
                                    anchors.fill: parent
                                    anchors.margins: 6
                                    spacing: 8
                                    Image {
                                        source: addRow.modelData.icon ? "image://icon/" + addRow.modelData.icon : ""
                                        Layout.preferredWidth: 22
                                        Layout.preferredHeight: 22
                                        fillMode: Image.PreserveAspectFit
                                        Layout.fillWidth: false
                                    }
                                    Text {
                                        text: addRow.modelData.name
                                        color: Theme.text
                                        font.pixelSize: 12
                                        Layout.fillWidth: true
                                        Layout.minimumWidth: 0
                                        Layout.preferredWidth: 0
                                        elide: Text.ElideRight
                                        clip: true
                                    }
                                    SmallIconButton { text: "+"; Layout.fillWidth: false; onClicked: DockConfig.togglePin(addRow.modelData.id) }
                                }
                            }
                        }
                    } // fin sección Dock
                }
            }

            // ---- Pie: restaurar / cerrar ----
            RowLayout {
                Layout.fillWidth: true
                Layout.topMargin: 4
                TextButton { label: "Restaurar"; danger: true; onClicked: { BarConfig.restoreDefaults(); DockConfig.restoreDefaults() } }
                Item { Layout.fillWidth: true }
                TextButton { label: "Cerrar"; onClicked: root.hide() }
            }
        }
    }

    // ================= Componentes reutilizables =================

    component SegButton: Rectangle {
        id: seg
        property string label: ""
        property bool active: false
        signal clicked()

        Layout.preferredWidth: label.length > 5 ? 64 : 56
        Layout.preferredHeight: 30
        radius: Theme.radiusSmall
        color: active ? Theme.accent : Theme.bgAlt
        border.width: active ? 0 : 1
        border.color: Theme.border

        Text {
            anchors.centerIn: parent
            text: seg.label
            color: seg.active ? Theme.bg : Theme.subtext
            font.pixelSize: 11
            font.bold: seg.active
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: seg.clicked()
        }
    }

    component SmallIconButton: Rectangle {
        id: sib
        property string text: ""
        signal clicked()

        Layout.preferredWidth: 28
        Layout.preferredHeight: 28
        radius: Theme.radiusSmall
        color: area.containsMouse ? Theme.accent : Theme.bg
        border.width: 1
        border.color: area.containsMouse ? Theme.accent : Theme.border

        Text {
            anchors.centerIn: parent
            text: sib.text
            color: area.containsMouse ? Theme.bg : Theme.subtext
            font.pixelSize: 12
            font.bold: true
        }
        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: sib.clicked()
        }
    }

    component TextButton: Rectangle {
        id: tb
        property string label: ""
        property bool danger: false
        signal clicked()

        Layout.preferredWidth: labelText.implicitWidth + 28
        Layout.preferredHeight: 34
        radius: Theme.radiusSmall
        color: area.containsMouse ? (tb.danger ? Qt.rgba(Theme.danger.r, Theme.danger.g, Theme.danger.b, 0.15) : Theme.accent) : "transparent"
        border.width: 1
        border.color: tb.danger ? Theme.danger : Theme.accent

        Text {
            id: labelText
            anchors.centerIn: parent
            text: tb.label
            color: tb.danger ? Theme.danger : (area.containsMouse ? Theme.bg : Theme.accent)
            font.pixelSize: 12
            font.bold: true
        }
        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: tb.clicked()
        }
    }

    component CheckBox: Rectangle {
        id: cb
        property bool checked: false
        signal toggled()

        Layout.preferredWidth: 22
        Layout.preferredHeight: 22
        radius: Theme.radiusSmall
        color: cb.checked ? Theme.accent : "transparent"
        border.width: 1
        border.color: cb.checked ? Theme.accent : Theme.border

        Text {
            anchors.centerIn: parent
            visible: cb.checked
            text: "✓"
            color: Theme.bg
            font.pixelSize: 13
            font.bold: true
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: cb.toggled()
        }
    }

    component SliderBar: Item {
        id: slider
        implicitHeight: 18
        property real value: 0
        signal moved(real v)

        Rectangle {
            width: parent.width; height: 6; radius: 3
            anchors.verticalCenter: parent.verticalCenter
            color: Theme.bgAlt
            Rectangle {
                width: parent.width * Math.max(0, Math.min(1, slider.value))
                height: parent.height
                radius: 3
                color: Theme.accent
            }
        }
        MouseArea {
            anchors.fill: parent
            onPressed: mouse => slider.moved(Math.max(0, Math.min(1, mouse.x / width)))
            onPositionChanged: mouse => { if (pressed) slider.moved(Math.max(0, Math.min(1, mouse.x / width))) }
        }
    }
}
