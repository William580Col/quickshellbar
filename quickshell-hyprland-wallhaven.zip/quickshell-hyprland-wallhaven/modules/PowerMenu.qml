import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import "../config"

PanelWindow {
    id: root
    property bool open: false
    // La ventana no se oculta con open: si lo hiciera, la animación de salida
    // se cortaría al instante. Se oculta al terminar el deslizamiento.
    property bool active: false
    readonly property int slideDuration: 250
    readonly property int edgeGap: 12 // hueco respecto al borde: deja ver el marco de 6px

    visible: active
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    function show() {
        hideDelay.stop()
        active = true
        open = true
    }
    function hide() {
        if (!open) return
        open = false
        hideDelay.restart() // oculta la ventana al terminar el deslizamiento
    }
    function toggle() { open ? hide() : show() }

    Timer {
        id: hideDelay
        interval: root.slideDuration
        onTriggered: if (!root.open) root.active = false
    }

    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        id: panel
        anchors.verticalCenter: parent.verticalCenter
        // x explícito: el eje se anima, no puede convivir con anchors.right
        x: root.open ? root.width - width - root.edgeGap : root.width
        width: layout.implicitWidth + 40
        height: layout.implicitHeight + 40
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1

        Behavior on x {
            NumberAnimation {
                duration: root.slideDuration
                easing.type: root.open ? Easing.OutCubic : Easing.InCubic
            }
        }

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            id: layout
            anchors.centerIn: parent
            spacing: 18

            PowerButton { icon: "󰌾"; label: "Bloquear"; onClicked: run("loginctl lock-session") }
            PowerButton { icon: "󰍃"; label: "Salir"; onClicked: run("command -v uwsm >/dev/null 2>&1 && uwsm stop || hyprctl dispatch 'hl.dsp.exit()'") }
            PowerButton { icon: "󰑐"; label: "Reiniciar"; onClicked: run("systemctl reboot") }
            PowerButton { icon: "󰐥"; label: "Apagar"; color: Theme.danger; onClicked: run("systemctl poweroff") }
            PowerButton { icon: "󰤄"; label: "Suspender"; onClicked: run("systemctl suspend") }
        }
    }

    function run(cmd) {
        runner.command = ["sh", "-c", cmd]
        runner.running = true
        hide()
    }
    Process { id: runner }

    component PowerButton: ColumnLayout {
        id: btn
        property string icon: ""
        property string label: ""
        property color color: Theme.accent
        signal clicked()
        spacing: 8

        Rectangle {
            Layout.preferredWidth: 64
            Layout.preferredHeight: 64
            radius: Theme.radiusMedium
            color: area.containsMouse ? Theme.bgAlt : "transparent"
            border.color: area.containsMouse ? btn.color : Theme.border
            border.width: 1
            Text {
                anchors.centerIn: parent
                text: btn.icon
                font.pixelSize: 26
                color: btn.color
            }
            MouseArea {
                id: area
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: btn.clicked()
            }
        }
        Text {
            Layout.alignment: Qt.AlignHCenter
            text: btn.label
            color: btn.color
            font.pixelSize: 11
        }
    }
}
