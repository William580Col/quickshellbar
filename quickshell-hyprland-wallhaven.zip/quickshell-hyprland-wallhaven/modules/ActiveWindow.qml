import QtQuick
import Quickshell
import Quickshell.Hyprland
import "../config"

Row {
    id: root
    spacing: 8
    visible: Hyprland.activeToplevel !== null

    property var win: Hyprland.activeToplevel

    Text {
        anchors.verticalCenter: parent.verticalCenter
        text: root.win ? (root.win.title || "") : ""
        color: Theme.text
        font.pixelSize: 13
        elide: Text.ElideRight
        maximumLineCount: 1
        width: Math.min(implicitWidth, 380)
    }
}
