import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"
import "../services" as Services

PanelWindow {
    id: root
    property bool open: false
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    // ssid actualmente expandido para pedir contraseña ("" = ninguno)
    property string expandedSsid: ""
    property string passwordDraft: ""

    function show() {
        open = true
        expandedSsid = ""
        passwordDraft = ""
        Services.Network.scan()
    }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    function iconFor(signal) {
        if (signal >= 75) return "󰤨"
        if (signal >= 50) return "󰤥"
        if (signal >= 25) return "󰤢"
        return "󰤟"
    }

    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.15
        width: 380
        height: 460
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 12

            // ---- Encabezado: título + toggle on/off + refrescar ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Text { text: "Redes Wi-Fi"; color: Theme.text; font.pixelSize: 15; font.bold: true; Layout.fillWidth: true }

                // Icono refrescar
                Text {
                    text: Services.Network.scanning ? "󰑐" : "󰑓"
                    color: Theme.subtext
                    font.pixelSize: 15
                    MouseArea {
                        anchors.fill: parent
                        anchors.margins: -6
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Services.Network.scan()
                    }
                }

                // Interruptor Wi-Fi on/off
                Rectangle {
                    Layout.preferredWidth: 42
                    Layout.preferredHeight: 22
                    radius: 11
                    color: Services.Network.wifiEnabled ? Theme.accent : Theme.bgAlt
                    border.color: Theme.border
                    border.width: Services.Network.wifiEnabled ? 0 : 1

                    Rectangle {
                        width: 16; height: 16; radius: 8
                        color: Theme.bg
                        anchors.verticalCenter: parent.verticalCenter
                        x: Services.Network.wifiEnabled ? parent.width - width - 3 : 3
                        Behavior on x { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Services.Network.toggleWifi()
                    }
                }
            }

            // ---- Error de conexión, si lo hay ----
            Rectangle {
                visible: Services.Network.lastError.length > 0
                Layout.fillWidth: true
                Layout.preferredHeight: errText.implicitHeight + 16
                radius: Theme.radiusSmall
                color: Qt.rgba(Theme.danger.r, Theme.danger.g, Theme.danger.b, 0.15)
                border.color: Theme.danger
                border.width: 1
                Text {
                    id: errText
                    anchors.fill: parent
                    anchors.margins: 8
                    text: "No se pudo conectar: " + Services.Network.lastError
                    color: Theme.danger
                    font.pixelSize: 11
                    wrapMode: Text.WordWrap
                }
            }

            // ---- Lista de redes ----
            ListView {
                id: list
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 4
                model: Services.Network.wifiList
                enabled: Services.Network.wifiEnabled
                opacity: Services.Network.wifiEnabled ? 1 : 0.4

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    property bool isCurrent: modelData.ssid === Services.Network.ssid && Services.Network.status === "wifi"
                    property bool isExpanded: root.expandedSsid === modelData.ssid
                    property bool isConnecting: Services.Network.connecting === modelData.ssid

                    width: list.width
                    height: isExpanded ? 130 : 52
                    radius: Theme.radiusSmall
                    color: isCurrent ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.15) : Theme.bgAlt
                    border.color: isCurrent ? Theme.accent : Theme.border
                    border.width: isCurrent ? 1 : 0
                    clip: true

                    Behavior on height { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }

                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 10
                        spacing: 10

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 10

                            Text { text: root.iconFor(row.modelData.signal); color: Theme.text; font.pixelSize: 15 }

                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 0
                                Text { text: row.modelData.ssid; color: Theme.text; font.pixelSize: 13; font.bold: true; elide: Text.ElideRight }
                                Text {
                                    text: row.isConnecting ? "Conectando…" : (row.isCurrent ? "Conectada" : (row.modelData.secure ? "Protegida" : "Abierta"))
                                    color: row.isCurrent ? Theme.accent : Theme.subtext
                                    font.pixelSize: 10
                                }
                            }

                            Text { visible: row.modelData.secure; text: "󰌾"; color: Theme.subtext; font.pixelSize: 12 }
                        }

                        // ---- Campo de contraseña (solo si está expandida) ----
                        RowLayout {
                            visible: row.isExpanded
                            Layout.fillWidth: true
                            spacing: 8

                            Rectangle {
                                Layout.fillWidth: true
                                Layout.preferredHeight: 34
                                radius: Theme.radiusSmall
                                color: Theme.bg
                                border.color: Theme.border
                                border.width: 1

                                TextInput {
                                    id: pwField
                                    anchors.fill: parent
                                    anchors.leftMargin: 10
                                    anchors.rightMargin: 10
                                    verticalAlignment: TextInput.AlignVCenter
                                    color: Theme.text
                                    font.pixelSize: 12
                                    echoMode: TextInput.Password
                                    clip: true
                                    onTextChanged: root.passwordDraft = text
                                    Keys.onReturnPressed: {
                                        Services.Network.connectTo(row.modelData.ssid, root.passwordDraft)
                                    }
                                    Text {
                                        visible: pwField.text.length === 0
                                        anchors.verticalCenter: parent.verticalCenter
                                        text: "Contraseña"
                                        color: Theme.subtext
                                        font.pixelSize: 12
                                    }
                                }
                            }

                            Rectangle {
                                Layout.preferredWidth: 70
                                Layout.preferredHeight: 34
                                radius: Theme.radiusSmall
                                color: Theme.accent
                                Text { anchors.centerIn: parent; text: "Conectar"; color: Theme.bg; font.pixelSize: 11; font.bold: true }
                                MouseArea {
                                    anchors.fill: parent
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: Services.Network.connectTo(row.modelData.ssid, root.passwordDraft)
                                }
                            }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            if (row.isCurrent) {
                                Services.Network.disconnect(row.modelData.ssid)
                            } else if (row.modelData.secure) {
                                root.expandedSsid = row.isExpanded ? "" : row.modelData.ssid
                                root.passwordDraft = ""
                            } else {
                                Services.Network.connectTo(row.modelData.ssid, "")
                            }
                        }
                        // evita que el clic en el campo de contraseña/botón "Conectar" también dispare esto
                        z: -1
                    }
                }
            }

            Text {
                Layout.fillWidth: true
                visible: !Services.Network.scanning && Services.Network.wifiList.length === 0
                text: "No se encontraron redes. Toca el icono de refrescar."
                color: Theme.subtext
                font.pixelSize: 11
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
            }
        }
    }
}
