import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import Quickshell.Services.SystemTray
import "../config"

/*
  Bandeja del sistema (tray icons).
  Clic izquierdo -> activate() (acción principal del icono)
  Clic derecho   -> abre el menú contextual del icono, si tiene uno
*/
Row {
    id: root
    spacing: 10

    Repeater {
        model: SystemTray.items

        delegate: Item {
            id: trayItem
            required property var modelData
            width: 18
            height: 18
            anchors.verticalCenter: parent.verticalCenter

            Image {
                anchors.fill: parent
                source: modelData.icon
                sourceSize: Qt.size(18, 18)
                fillMode: Image.PreserveAspectFit
            }

            // Ancla para desplegar el QsMenu del icono (right click)
            QsMenuAnchor {
                id: menuAnchor
                menu: trayItem.modelData.menu
                anchor.item: trayItem
            }

            MouseArea {
                anchors.fill: parent
                anchors.margins: -4
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                cursorShape: Qt.PointingHandCursor
                onClicked: mouse => {
                    if (mouse.button === Qt.RightButton) {
                        if (trayItem.modelData.hasMenu) {
                            menuAnchor.open()
                        }
                    } else {
                        trayItem.modelData.activate()
                    }
                }
            }
        }
    }
}
