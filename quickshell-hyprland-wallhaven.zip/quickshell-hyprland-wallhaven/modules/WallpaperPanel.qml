import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"
import "../services" as Services

/*
  Panel de fondo de pantalla con selector tipo "rockola": una cinta
  horizontal de portadas apiladas donde la del centro es la activa y las
  laterales se encogen y giran hacia adentro (estilo carátulas de disco).

  Navegación:
    · Ratón: arrastra, clic en una portada lateral la trae al centro,
      clic en la central (o el botón "Aplicar") la pone como fondo,
      rueda del ratón para pasar.
    · Teclado: ← / → (y ↑ / ↓) para navegar, Enter / Espacio para
      aplicar, Esc para cerrar.

  Se conserva el módulo de Wallhaven (buscar, categorías y paginación),
  solo cambia la presentación de los resultados.
*/
PanelWindow {
    id: root
    property bool open: false
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    property string activeTab: "local" // "local" | "wallhaven"
    property real coverW: 200          // ancho de la portada frontal
    property real step: 140            // paso entre centros de portadas consecutivas

    // Índice de la ficha cuyo CENTRO coincide con el centro del visor. El
    // "currentIndex" interno del ListView NO se alinea con el centro (se
    // queda en el borde izquierdo), por eso todo (borde, nombre, Aplicar)
    // se deriva de este índice visual para que coincida con lo mostrado.
    property int visualIndex: {
        if (carouselData.count === 0) return -1
        var v = (carouselView.contentX + (carouselView.width - root.coverW) / 2) / root.step
        return Math.max(realFirst(), Math.min(realLast(), Math.round(v)))
    }

    function show() {
        open = true
        Services.Wallpaper.refresh()
        if (activeTab === "wallhaven" && Services.Wallhaven.results.length === 0) Services.Wallhaven.search()
        carouselView.forceActiveFocus()
    }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    // Cambia de pestaña y reconstruye la cinta conservando la selección.
    function setTab(tab, triggerSearch) {
        activeTab = tab
        rebuildModel()
        if (triggerSearch && Services.Wallhaven.results.length === 0) Services.Wallhaven.search()
        carouselView.forceActiveFocus()
    }

    // Aplica la ficha que está en el CENTRO del visor (lo que ve el usuario).
    function applyCurrent() {
        if (carouselData.count === 0) return
        var sel = root.visualIndex
        if (sel < 0) return
        var row = carouselData.get(sel)
        if (!row || row.type === "spacer" || Services.Wallhaven.downloading) return
        if (row.type === "local") {
            Services.Wallpaper.set(row.key)
            root.hide()
        } else if (row.full) {
            Services.Wallhaven.downloadAndApply({ path: row.full, id: row.id })
        }
    }

    // Con 2 filas espaciadoras a cada lado, los extremos de la cinta quedan
    // dentro de la zona centrable del ListView (el 1º/2º ya se pueden
    // seleccionar). "realFirst"/"realLast" delimitan las fichas reales.
    function realFirst() {
        if (carouselData.count > 0 && carouselData.get(0).type === "spacer") return 2
        return 0
    }
    function realLast() {
        if (carouselData.count === 0) return 0
        var t = carouselData.count - 1
        if (carouselData.get(t).type === "spacer") t -= 2
        return Math.max(realFirst(), t)
    }

    // Lleva la ficha "idx" al centro del visor. El ListView por sí solo no
    // centra su "current" (lo deja en el borde), así que se posiciona el
    // contentX explícitamente para que centro visual == selección.
    function navTo(idx) {
        if (carouselData.count === 0) return
        idx = Math.max(realFirst(), Math.min(realLast(), idx))
        carouselView.currentIndex = idx
        carouselView.contentX = idx * root.step - (carouselView.width - root.coverW) / 2
        carouselView.forceActiveFocus()
    }

    // Navegación con teclado / rueda. Al llegar al borde de la página en la
    // pestaña de Wallhaven, salta automáticamente a la página siguiente.
    function navBy(dir) {
        if (carouselData.count === 0) return
        var sel = root.visualIndex
        if (sel < 0) return
        var ni = sel + dir
        if (ni < realFirst()) {
            if (activeTab === "wallhaven" && Services.Wallhaven.page > 1) {
                Services.Wallhaven.prevPage()
            } else {
                root.navTo(realFirst())
            }
        } else if (ni > realLast()) {
            if (activeTab === "wallhaven" && Services.Wallhaven.page < Services.Wallhaven.lastPage) {
                Services.Wallhaven.nextPage()
            } else {
                root.navTo(realLast())
            }
        } else {
            root.navTo(ni)
        }
    }

    // Roles de tipo fijo (solo strings). Al mezclar cadenas y objetos de la
    // API de Wallhaven en un mismo role, QML ListModel lanza:
    //   "Can't assign to existing role 'data' of different type [VariantMap -> String]"
    // lo que impide que las miniaturas se asignen. Todo se almacena como
    // string; los objetos de Wallhaven se consultan por id bajo demanda.
    ListModel { id: carouselData }

    function rebuildModel() {
        var keepKey = ""
        var sel = root.visualIndex
        if (carouselData.count > 0 && sel >= 0 && sel < carouselData.count) {
            var prevRow = carouselData.get(sel)
            keepKey = prevRow.type === "spacer" ? "" : prevRow.key
        }

        carouselData.clear()

        var hasContent = false
        if (activeTab === "local") {
            hasContent = Services.Wallpaper.list.length > 0
        } else {
            hasContent = Services.Wallhaven.results.length > 0
        }

        // 2 filas espaciadoras a cada lado para que los extremos queden
        // dentro de la zona centrable del carrusel.
        for (var s = 0; s < (hasContent ? 2 : 0); s++) {
            carouselData.append({ "type": "spacer", "key": "", "thumb": "", "id": "", "full": "", "res": "" })
        }

        if (activeTab === "local") {
            var list = Services.Wallpaper.list
            for (var i = 0; i < list.length; i++) {
                carouselData.append({ "type": "local",
                                      "key": list[i],
                                      "thumb": "file://" + Services.Wallpaper.thumbPathFor(list[i]) })
            }
        } else {
            var results = Services.Wallhaven.results
            for (var j = 0; j < results.length; j++) {
                var r = results[j]
                carouselData.append({ "type": "wallhaven",
                                      "id": r.id || "",
                                      "key": "W:" + (r.id || ""),
                                      "thumb": r.thumbs && (r.thumbs.large || r.thumbs.small)
                                                 ? (r.thumbs.large || r.thumbs.small) : "",
                                      "full": r.path || "",
                                      "res": r.resolution || "" })
            }
        }

        for (var e = 0; e < (hasContent ? 2 : 0); e++) {
            carouselData.append({ "type": "spacer", "key": "", "thumb": "", "id": "", "full": "", "res": "" })
        }

        if (carouselData.count === 0) return

        var target = -1
        for (var k = realFirst(); k <= realLast(); k++) {
            if (carouselData.get(k).key === keepKey) { target = k; break }
        }
        if (target < 0 && activeTab === "local") {
            for (var m = realFirst(); m <= realLast(); m++) {
                if (carouselData.get(m).key === Services.Wallpaper.current) { target = m; break }
            }
        }
        root.navTo(target >= realFirst() ? target : realFirst())
    }

    // Fondo, clic fuera cierra.
    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        id: panel
        anchors.centerIn: parent
        width: 760
        height: activeTab === "wallhaven" ? 480 : 402
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1

        Behavior on height { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 12

            // ---- Encabezado: título + modo de ajuste ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Text {
                    text: "Fondo de pantalla"
                    color: Theme.text
                    font.pixelSize: 16
                    font.bold: true
                }

                Item { Layout.fillWidth: true }

                Text { text: "Ajuste:"; color: Theme.subtext; font.pixelSize: 11 }
                TabPill {
                    label: "Centrada"
                    active: Services.Wallpaper.fitMode === "center"
                    onClicked: Services.Wallpaper.setFitMode("center")
                }
                TabPill {
                    label: "Full"
                    active: Services.Wallpaper.fitMode === "fill"
                    onClicked: Services.Wallpaper.setFitMode("fill")
                }
                TabPill {
                    label: "Estirada"
                    active: Services.Wallpaper.fitMode === "stretch"
                    onClicked: Services.Wallpaper.setFitMode("stretch")
                }
            }

            // ---- Pestañas Local / Wallhaven ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TabPill {
                    label: "Local"
                    active: activeTab === "local"
                    onClicked: root.setTab("local", false)
                }
                TabPill {
                    label: "Wallhaven"
                    active: activeTab === "wallhaven"
                    onClicked: root.setTab("wallhaven", true)
                }
                Item { Layout.fillWidth: true }

                Text {
                    visible: activeTab === "local"
                    text: "  Aleatorio 🔀"
                    color: Theme.accent
                    font.pixelSize: 12
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Services.Wallpaper.random()
                    }
                }
                Text {
                    visible: activeTab === "wallhaven"
                    text: "  ←  →   |   Enter: aplicar"
                    color: Theme.subtext
                    font.pixelSize: 10
                }
            }

            // ---- Buscador + categorías (solo Wallhaven) ----
            RowLayout {
                Layout.fillWidth: true
                visible: activeTab === "wallhaven"
                spacing: 8

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 36
                    radius: Theme.radiusMedium
                    color: Theme.bgAlt
                    border.color: whSearchField.activeFocus ? Theme.accent : Theme.border
                    border.width: 1

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 8
                        spacing: 6
                        Text { text: "󰍉"; color: Theme.subtext; font.pixelSize: 12 }
                        TextInput {
                            id: whSearchField
                            Layout.fillWidth: true
                            text: Services.Wallhaven.query
                            color: Theme.text
                            font.pixelSize: 12
                            clip: true
                            onAccepted: Services.Wallhaven.setQuery(text)
                            Keys.onReturnPressed: Services.Wallhaven.setQuery(text)
                        }
                    }
                }

                Text { text: "Categoría:"; color: Theme.subtext; font.pixelSize: 11 }
                TabPill {
                    label: "General"
                    active: Services.Wallhaven.categories.general
                    onClicked: Services.Wallhaven.toggleCategory("general")
                }
                TabPill {
                    label: "Anime"
                    active: Services.Wallhaven.categories.anime
                    onClicked: Services.Wallhaven.toggleCategory("anime")
                }
                TabPill {
                    label: "Personas"
                    active: Services.Wallhaven.categories.people
                    onClicked: Services.Wallhaven.toggleCategory("people")
                }
            }

            Text {
                visible: activeTab === "wallhaven" && Services.Wallhaven.lastError.length > 0
                text: Services.Wallhaven.lastError
                color: Theme.danger
                font.pixelSize: 11
            }

            // ==================== CINTA / CARRUSEL (rockola) ====================
            Rectangle {
                id: stage
                Layout.fillWidth: true
                Layout.preferredHeight: 210
                radius: Theme.radiusMedium
                color: Theme.bgAlt
                border.color: Theme.border
                border.width: 1
                clip: true

                ListView {
                    id: carouselView
                    anchors.fill: parent
                    orientation: ListView.Horizontal
                    spacing: -(root.coverW - root.step) // paso entre centros = step → portadas superpuestas
                    snapMode: ListView.SnapOneItem
                    // Sin rango de highlight: si se deja el rango, el ListView
                    // reposiciona la vista al cambiar currentIndex y anula el
                    // centro calculado. El centrado lo hace root.navTo().
                    highlightRangeMode: ListView.NoHighlightRange
                    model: carouselData
                    focus: true
                    clip: false
                    reuseItems: true
                    cacheBuffer: 700
                    boundsBehavior: Flickable.StopAtBounds

                    // Al terminar un arrastre manual se re-centra la ficha
                    // que haya quedado más cerca del centro del visor.
                    onMovementEnded: {
                        if (carouselData.count > 0) root.navTo(root.visualIndex)
                    }
                    onWidthChanged: {
                        if (carouselData.count > 0 && root.visualIndex >= 0) root.navTo(root.visualIndex)
                    }

                    Keys.onLeftPressed: root.navBy(-1)
                    Keys.onRightPressed: root.navBy(1)
                    Keys.onUpPressed: root.navBy(-1)
                    Keys.onDownPressed: root.navBy(1)
                    Keys.onReturnPressed: root.applyCurrent()
                    Keys.onEnterPressed: root.applyCurrent()
                    Keys.onSpacePressed: root.applyCurrent()
                    Keys.onEscapePressed: root.hide()

                    delegate: Item {
                        id: cell
                        required property int index
                        required property var modelData

                        width: root.coverW
                        height: carouselView.height

                        // Distancia (en px) del centro de la portada al centro del visor.
                        property real dist: {
                            var viewCenter = carouselView.contentX + carouselView.width / 2
                            return (cell.x + cell.width / 2) - viewCenter
                        }
                        // Lejos del centro: más pequeña, más girada y más tenue.
                        property real dynScale: Math.max(0.32, 1 - Math.min(Math.abs(dist), 360) / 360 * 0.68)
                        property real dynRot: Math.max(-55, Math.min(55, -dist * 0.14))
                        property bool current_: cell.index === root.visualIndex
                        property bool realItem: modelData.type !== "spacer"

                        z: Math.round(4000 - Math.abs(dist))
                        opacity: realItem ? Math.max(0.12, 1 - Math.min(Math.abs(dist), 460) / 460 * 0.9) : 0

                        transform: [
                            Scale {
                                origin.x: root.coverW / 2
                                origin.y: cell.height / 2
                                xScale: cell.dynScale
                                yScale: cell.dynScale
                            },
                            Rotation {
                                origin.x: root.coverW / 2
                                origin.y: cell.height / 2
                                axis { x: 0; y: 1; z: 0 }
                                angle: cell.dynRot
                            }
                        ]

                        // Portada (marco + imagen) — oculto en filas espaciadoras
                        Rectangle {
                            id: frame
                            visible: cell.realItem
                            anchors.centerIn: parent
                            width: root.coverW
                            height: 120
                            radius: Theme.radiusMedium
                            color: Theme.bgAlt
                            border.width: cell.current_ ? 2 : 1
                            border.color: cell.current_ ? Theme.accent : Theme.border
                            clip: true

                            Image {
                                id: frameImg
                                anchors.fill: parent
                                anchors.margins: 3
                                source: modelData.thumb
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                cache: true
                                sourceSize: Qt.size(480, 288)
                                onStatusChanged: {
                                    if (status === Image.Error && modelData.type === "local"
                                            && source.toString().indexOf("wallpaper-thumbs") !== -1) {
                                        source = "file://" + modelData.key
                                    }
                                }
                            }

                            // Marca del wallpaper actualmente en uso (pestaña local)
                            Rectangle {
                                anchors.left: parent.left
                                anchors.top: parent.top
                                anchors.margins: 5
                                visible: modelData.type === "local" && modelData.key === Services.Wallpaper.current
                                width: badgeText.implicitWidth + 10
                                height: 16
                                radius: 8
                                color: Qt.rgba(0, 0, 0, 0.55)
                                Text {
                                    id: badgeText
                                    anchors.centerIn: parent
                                    text: "✓ actual"
                                    color: "#ffffff"
                                    font.pixelSize: 9
                                    font.bold: true
                                }
                            }

                            // Etiqueta de resolución (Wallhaven)
                            Rectangle {
                                anchors.right: parent.right
                                anchors.bottom: parent.bottom
                                anchors.margins: 4
                                visible: modelData.type === "wallhaven" && modelData.res.length > 0
                                width: resLabel.implicitWidth + 8
                                height: resLabel.implicitHeight + 4
                                radius: 4
                                color: Qt.rgba(0, 0, 0, 0.55)
                                Text {
                                    id: resLabel
                                    anchors.centerIn: parent
                                    text: modelData.res
                                    color: "#ffffff"
                                    font.pixelSize: 9
                                }
                            }
                        }

                        MouseArea {
                            id: coverArea
                            enabled: cell.realItem
                            anchors.centerIn: parent
                            width: root.coverW
                            height: 120
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                carouselView.forceActiveFocus()
                                if (cell.index === root.visualIndex) root.applyCurrent()
                                else root.navTo(cell.index)
                            }
                            onWheel: (wheel) => root.navBy(wheel.angleDelta.y < 0 ? 1 : -1)
                        }
                    }
                }

                // Mensaje cuando no hay nada que mostrar / se está cargando
                Text {
                    visible: carouselData.count === 0
                    anchors.centerIn: parent
                    text: {
                        if (activeTab === "local") {
                            return Services.Wallpaper.list.length === 0
                                ? "No se encontraron imágenes en la carpeta configurada.\nEdita 'directory' en services/Wallpaper.qml o coloca fotos en ~/Pictures/Wallpapers"
                                : "Cargando…"
                        }
                        if (Services.Wallhaven.loading) return "Buscando en Wallhaven…"
                        if (Services.Wallhaven.lastError.length > 0) return Services.Wallhaven.lastError
                        return "Sin resultados"
                    }
                    color: Theme.subtext
                    font.pixelSize: 12
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    wrapMode: Text.WordWrap
                    width: parent.width - 40
                }
            }

            // ---- Pie: ayuda + descripción + aplicar ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Text {
                    text: "Clic, rueda o ←  →  para navegar"
                    color: Theme.subtext
                    font.pixelSize: 10
                }

                Item { Layout.fillWidth: true }

                Text {
                    id: currentInfo
                    Layout.maximumWidth: 280
                    elide: Text.ElideRight
                    property var currentRow: root.visualIndex >= 0 ? carouselData.get(root.visualIndex) : null
                    text: {
                        var r = currentRow
                        if (!r || r.type === "spacer") return ""
                        return r.type === "local"
                                ? r.key.split("/").pop()
                                : (r.res ? r.res + "  •  " : "") + "wallhaven-" + r.id
                    }
                    color: Theme.subtext
                    font.pixelSize: 11
                }

                Text {
                    visible: activeTab === "wallhaven" && Services.Wallhaven.downloading
                    text: "Descargando…"
                    color: Theme.warning
                    font.pixelSize: 11
                }

                Rectangle {
                    id: applyBtn
                    implicitWidth: applyText.implicitWidth + 26
                    implicitHeight: 30
                    radius: 15
                    color: Theme.accent
                    Behavior on color { ColorAnimation { duration: 120 } }

                    Text {
                        id: applyText
                        anchors.centerIn: parent
                        text: Services.Wallhaven.downloading ? "…" : "Aplicar"
                        color: Theme.bg
                        font.pixelSize: 11
                        font.bold: true
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.applyCurrent()
                    }
                }
            }

            // ---- Paginación (solo Wallhaven) ----
            RowLayout {
                visible: activeTab === "wallhaven"
                Layout.fillWidth: true
                Text {
                    text: "‹ Anterior"
                    color: Services.Wallhaven.page > 1 ? Theme.accent : Theme.subtext
                    font.pixelSize: 11
                    MouseArea {
                        anchors.fill: parent
                        anchors.margins: -4
                        cursorShape: Qt.PointingHandCursor
                        enabled: Services.Wallhaven.page > 1
                        onClicked: Services.Wallhaven.prevPage()
                    }
                }
                Item { Layout.fillWidth: true }
                Text {
                    text: Services.Wallhaven.loading ? "Buscando…" : ("Página " + Services.Wallhaven.page + " de " + Services.Wallhaven.lastPage)
                    color: Theme.subtext
                    font.pixelSize: 11
                }
                Item { Layout.fillWidth: true }
                Text {
                    text: "Siguiente ›"
                    color: Services.Wallhaven.page < Services.Wallhaven.lastPage ? Theme.accent : Theme.subtext
                    font.pixelSize: 11
                    MouseArea {
                        anchors.fill: parent
                        anchors.margins: -4
                        cursorShape: Qt.PointingHandCursor
                        enabled: Services.Wallhaven.page < Services.Wallhaven.lastPage
                        onClicked: Services.Wallhaven.nextPage()
                    }
                }
            }
        }

        // Oscurece todo mientras se descarga y aplica un wallpaper de Wallhaven
        Rectangle {
            anchors.fill: parent
            radius: Theme.radiusLarge
            color: Qt.rgba(0, 0, 0, 0.45)
            visible: activeTab === "wallhaven" && Services.Wallhaven.downloading
            z: 50
            Text {
                anchors.centerIn: parent
                text: "Descargando y aplicando…"
                color: "#ffffff"
                font.pixelSize: 14
                font.bold: true
            }
            MouseArea { anchors.fill: parent }
        }
    }

    // Al terminar de descargar una imagen de Wallhaven, la aplicamos y
    // refrescamos la lista local (para que quede disponible ahí también).
    Connections {
        target: Services.Wallhaven
        function onDownloadFinished(path) {
            Services.Wallpaper.set(path)
            Services.Wallpaper.refresh()
            root.hide()
        }
    }

    // Reconstruye la cinta a medida que se carga la lista local.
    Connections {
        target: Services.Wallpaper
        enabled: activeTab === "local"
        function onListChanged() {
            if (carouselView) rebuildModel()
        }
    }

    // Reconstruye la cinta cuando llegan resultados de Wallhaven.
    Connections {
        target: Services.Wallhaven
        enabled: activeTab === "wallhaven"
        function onResultsChanged() {
            if (carouselView) rebuildModel()
        }
    }

    // ================= Componente reutilizable: pestaña/pill =================
    component TabPill: Rectangle {
        id: pill
        property string label: ""
        property bool active: false
        signal clicked()

        implicitWidth: labelText.implicitWidth + 20
        implicitHeight: 26
        radius: 13
        color: pill.active ? Theme.accent : Theme.bgAlt
        border.width: pill.active ? 0 : 1
        border.color: Theme.border

        Text {
            id: labelText
            anchors.centerIn: parent
            text: pill.label
            color: pill.active ? Theme.bg : Theme.subtext
            font.pixelSize: 11
            font.bold: pill.active
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }
}