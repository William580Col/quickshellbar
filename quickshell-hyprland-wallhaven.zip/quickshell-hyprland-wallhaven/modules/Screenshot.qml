import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import "../config"

/*
  Captura de pantalla para Hyprland.

  IMPORTANTE: no lanzamos grim/slurp directamente como hijo de Quickshell.
  En este Hyprland (build con scripting Lua, 0.55+), un proceso spawneado
  directamente por Quickshell no logra que 'slurp' obtenga el grab de
  teclado/mouse que necesita para su superficie de selección: se queda
  colgado sin mostrar el overlay y sin ningún error. Confirmado en vivo que
  "hyprctl dispatch hl.dsp.exec_cmd(...)" SÍ funciona (usa el mecanismo de
  ejecución del propio compositor), así que enrutamos la captura de área
  por ahí, delegando la lógica real a scripts externos en scripts/ (más
  simple que anidar comillas de Lua+shell en una sola línea).

  Instalar: sudo apt install grim slurp wl-clipboard libnotify-bin
  Los scripts deben quedar en ~/.config/quickshell/scripts/ (se copian
  junto con el resto del proyecto).
*/
Row {
    id: root
    spacing: 14

    property string scriptsDir: Quickshell.env("HOME") + "/.config/quickshell/scripts"

    function runViaHyprland(scriptName) {
        // Lanza el script A TRAVÉS de Hyprland (hl.dsp.exec_cmd), no como
        // hijo directo de Quickshell — es la parte que marca la diferencia.
        var cmd = "sh " + root.scriptsDir + "/" + scriptName
        launchProc.command = ["hyprctl", "dispatch", "hl.dsp.exec_cmd('" + cmd + "')"]
        launchProc.running = true
    }

    // Captura completa (todos los monitores) -> archivo + portapapeles
    Item {
        width: 18; height: 18
        anchors.verticalCenter: parent.verticalCenter
        Text { anchors.centerIn: parent; text: "󰄀"; color: Theme.text; font.pixelSize: 15 }
        MouseArea {
            anchors.fill: parent
            anchors.margins: -8
            cursorShape: Qt.PointingHandCursor
            onClicked: root.runViaHyprland("screenshot-full.sh")
        }
    }

    // Captura de área seleccionada -> archivo + portapapeles
    Item {
        width: 18; height: 18
        anchors.verticalCenter: parent.verticalCenter
        Text { anchors.centerIn: parent; text: "󰆞"; color: Theme.text; font.pixelSize: 15 }
        MouseArea {
            anchors.fill: parent
            anchors.margins: -8
            cursorShape: Qt.PointingHandCursor
            onClicked: root.runViaHyprland("screenshot-area.sh")
        }
    }

    Process {
        id: launchProc
        stdout: SplitParser { onRead: line => console.log("[Screenshot] hyprctl:", line) }
        stderr: SplitParser { onRead: line => console.warn("[Screenshot] hyprctl:", line) }
        onExited: (code, status) => console.log("[Screenshot] hyprctl dispatch salió con código", code)
    }
}
