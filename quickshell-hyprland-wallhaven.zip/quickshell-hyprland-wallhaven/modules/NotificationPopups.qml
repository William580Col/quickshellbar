import QtQuick
import QtQuick.Layouts
import Quickshell
import "../config"
import "../services" as Services

PanelWindow {
    id: root
    visible: Services.Notifs.list.length > 0
    color: "transparent"
    exclusiveZone: 0

    anchors {
        top: true
        right: true
    }
    margins { top: 50; right: 12 }
    implicitWidth: 340
    implicitHeight: col.implicitHeight

    ColumnLayout {
        id: col
        width: parent.width
        spacing: 8

        Repeater {
            model: Services.Notifs.list

            delegate: Rectangle {
                id: card
                required property var modelData
                Layout.fillWidth: true
                implicitHeight: content.implicitHeight + 24
                radius: Theme.radiusMedium
                color: BarConfig.surfaceColor(Theme.surface)
                border.color: modelData.urgent ? Theme.danger : Theme.border
                border.width: 1

                opacity: 0
                Component.onCompleted: opacity = 1
                Behavior on opacity { NumberAnimation { duration: 180 } }

                Timer {
                    interval: card.modelData.urgent ? 15000 : 6000
                    running: true
                    onTriggered: Services.Notifs.dismiss(card.modelData.id)
                }

                RowLayout {
                    id: content
                    anchors.fill: parent
                    anchors.margins: 12
                    spacing: 10

                    Rectangle {
                        width: 34; height: 34; radius: Theme.radiusSmall
                        color: Theme.bgAlt
                        Image {
                            anchors.fill: parent
                            anchors.margins: 4
                            source: card.modelData.icon
                            fillMode: Image.PreserveAspectFit
                        }
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 2
                        Text {
                            text: card.modelData.appName + " · " + card.modelData.summary
                            color: Theme.text
                            font.pixelSize: 12
                            font.bold: true
                            Layout.fillWidth: true
                            elide: Text.ElideRight
                        }
                        Text {
                            text: card.modelData.body
                            color: Theme.subtext
                            font.pixelSize: 11
                            wrapMode: Text.WordWrap
                            Layout.fillWidth: true
                            maximumLineCount: 3
                            elide: Text.ElideRight
                        }
                    }

                    Text {
                        text: "×"
                        color: Theme.subtext
                        font.pixelSize: 16
                        MouseArea {
                            anchors.fill: parent
                            anchors.margins: -6
                            cursorShape: Qt.PointingHandCursor
                            onClicked: Services.Notifs.dismiss(card.modelData.id)
                        }
                    }
                }
            }
        }
    }
}
