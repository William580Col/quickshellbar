import QtQuick
import QtQuick.Layouts
import Quickshell
import "../config"
import "../services" as Services

PanelWindow {
    id: root
    color: "transparent"
    exclusiveZone: 0
    anchors { top: true }
    margins { top: Theme.barHeight + 16 }
    implicitWidth: 240
    implicitHeight: card.height

    // Mantenemos la lógica de estado en la raíz
    property real shownOpacity: 0
    visible: shownOpacity > 0

    Connections {
        target: Services.Audio
        function onVolumeChanged() { root.pulse() }
        function onMutedChanged() { root.pulse() }
    }

    function pulse() {
        root.shownOpacity = 1
        hideTimer.restart()
    }

    Timer {
        id: hideTimer
        interval: 1300
        onTriggered: root.shownOpacity = 0
    }

    Rectangle {
        id: card
        anchors.horizontalCenter: parent.horizontalCenter
        width: 240
        height: 56
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.bg)
        border.color: Theme.border
        border.width: 1

        // Aplicamos la opacidad y la animación al Rectangle
        opacity: root.shownOpacity
        Behavior on opacity { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }

        RowLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 12

            Text {
                text: Services.Audio.muted ? "據"
                      : (Services.Audio.volume > 0.66 ? "弊"
                      : (Services.Audio.volume > 0.33 ? "摩"
                      : (Services.Audio.volume > 0 ? "柄" : "據")))
                color: Theme.text
                font.pixelSize: 17
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 8
                radius: 4
                color: Theme.bgAlt

                Rectangle {
                    width: parent.width * (Services.Audio.muted ? 0 : Services.Audio.volume)
                    height: parent.height
                    radius: 4
                    color: Theme.accent
                    Behavior on width { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
                }
            }

            Text {
                text: Services.Audio.muted ? "Mute" : (Math.round(Services.Audio.volume * 100) + "%")
                color: Theme.subtext
                font.pixelSize: 11
                Layout.preferredWidth: 36
                horizontalAlignment: Text.AlignRight
            }
        }
    }
}
