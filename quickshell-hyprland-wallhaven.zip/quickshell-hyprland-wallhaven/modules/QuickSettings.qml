import QtQuick
import QtQuick.Layouts
import Quickshell
import "../config"
import "../services" as Services

Rectangle {
    id: root
    width: 320
    implicitHeight: layout.implicitHeight + 32
    radius: Theme.radiusLarge
    color: BarConfig.surfaceColor(Theme.surface)
    border.color: Theme.border
    border.width: 1

    signal wifiRequested()

    ColumnLayout {
        id: layout
        anchors.fill: parent
        anchors.margins: 16
        spacing: 14

        // --- Fila de toggles rápidos ---
        GridLayout {
            columns: 2
            columnSpacing: 10
            rowSpacing: 10
            Layout.fillWidth: true

            ToggleTile {
                label: "Wi-Fi"
                icon: Services.Network.status === "wifi" ? "󰤨" : (Services.Network.wifiEnabled ? "󰤭" : "󰤮")
                sub: Services.Network.status === "wifi" ? Services.Network.ssid : (Services.Network.status === "ethernet" ? "Cable" : "Desconectado")
                active: Services.Network.status !== "disconnected"
                onClicked: root.wifiRequested()
            }

            ToggleTile {
                label: "Luz nocturna"
                icon: "󰛨"
                sub: Services.NightLight.active ? "Activada" : "Desactivada"
                active: Services.NightLight.active
                onClicked: Services.NightLight.toggle()
            }

            ToggleTile {
                label: "No suspender"
                icon: "󰅶"
                sub: Services.IdleInhibitor.active ? "Activo" : "Inactivo"
                active: Services.IdleInhibitor.active
                onClicked: Services.IdleInhibitor.toggle()
            }

            ToggleTile {
                label: "Tema"
                icon: Theme.dark ? "󰖔" : "󰖙"
                sub: Theme.dark ? "Oscuro" : "Claro"
                active: !Theme.dark
                onClicked: Theme.toggle()
            }
        }

        // --- Volumen ---
        ColumnLayout {
            Layout.fillWidth: true
            spacing: 4
            RowLayout {
                Layout.fillWidth: true
                Text { text: Services.Audio.muted ? "󰝟" : "󰕾"; color: Theme.text; font.pixelSize: 15
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: Services.Audio.toggleMute() } }
                Text { text: "Volumen"; color: Theme.subtext; font.pixelSize: 12 }
                Item { Layout.fillWidth: true }
                Text { text: Math.round(Services.Audio.volume * 100) + "%"; color: Theme.subtext; font.pixelSize: 12 }
            }
            SliderBar {
                Layout.fillWidth: true
                value: Services.Audio.volume
                onMoved: v => Services.Audio.setVolume(v)
            }
        }

        // --- Brillo ---
        ColumnLayout {
            Layout.fillWidth: true
            spacing: 4
            RowLayout {
                Layout.fillWidth: true
                Text { text: "󰃟"; color: Theme.text; font.pixelSize: 15 }
                Text { text: "Brillo"; color: Theme.subtext; font.pixelSize: 12 }
                Item { Layout.fillWidth: true }
                Text { text: Math.round(Services.Brightness.value * 100) + "%"; color: Theme.subtext; font.pixelSize: 12 }
            }
            SliderBar {
                Layout.fillWidth: true
                value: Services.Brightness.value
                onMoved: v => Services.Brightness.set(v)
            }
        }
    }

    // --- Componentes locales reutilizables ---
    component ToggleTile: Rectangle {
        id: tile
        property string label: ""
        property string icon: ""
        property string sub: ""
        property bool active: false
        signal clicked()

        Layout.fillWidth: true
        Layout.preferredHeight: 58
        radius: Theme.radiusMedium
        color: active ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.18) : Theme.bgAlt
        border.width: active ? 1 : 0
        border.color: Theme.accent

        RowLayout {
            anchors.fill: parent
            anchors.margins: 10
            spacing: 8
            Text { text: tile.icon; color: tile.active ? Theme.accent : Theme.text; font.pixelSize: 17 }
            ColumnLayout {
                spacing: 0
                Text { text: tile.label; color: Theme.text; font.pixelSize: 12; font.bold: true }
                Text { text: tile.sub; color: Theme.subtext; font.pixelSize: 10; elide: Text.ElideRight }
            }
        }
        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: tile.clicked() }
    }

    component SliderBar: Item {
        id: slider
        implicitHeight: 18
        property real value: 0
        signal moved(real v)

        Rectangle {
            width: parent.width; height: 6; radius: 3
            anchors.verticalCenter: parent.verticalCenter
            color: Theme.bgAlt
            Rectangle {
                width: parent.width * slider.value
                height: parent.height
                radius: 3
                color: Theme.accent
            }
        }
        MouseArea {
            anchors.fill: parent
            onPressed: mouse => slider.moved(Math.max(0, Math.min(1, mouse.x / width)))
            onPositionChanged: mouse => { if (pressed) slider.moved(Math.max(0, Math.min(1, mouse.x / width))) }
        }
    }
}
