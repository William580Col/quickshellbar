import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"
import "../services" as Services

PanelWindow {
    id: root
    property bool open: false
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    function show() { open = true; Services.ClipHistory.refresh() }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        id: card
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.12
        width: 460
        height: 560
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1

        MouseArea { anchors.fill: parent }

        // Banda superior de acento
        Rectangle {
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.topMargin: 1
            anchors.leftMargin: 12
            anchors.rightMargin: 12
            height: 3
            radius: 2
            gradient: Gradient {
                orientation: Gradient.Horizontal
                GradientStop { position: 0.0; color: Theme.accent }
                GradientStop { position: 1.0; color: Theme.accentAlt }
            }
        }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            anchors.topMargin: 20
            spacing: 12

            // ---- Header ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Rectangle {
                    width: 40; height: 40
                    radius: 20
                    color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.18)
                    border.color: Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.4)
                    border.width: 1
                    Text {
                        anchors.centerIn: parent
                        text: "󰅍"
                        color: Theme.accent
                        font.pixelSize: 18
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    Text { text: "Portapapeles"; color: Theme.text; font.pixelSize: 16; font.bold: true }
                    Text {
                        text: Services.ClipHistory.items.length + " elementos"
                        color: Theme.subtext
                        font.pixelSize: 12
                    }
                }

                Rectangle {
                    id: clearBtn
                    property bool hovered: false
                    Layout.preferredWidth: 96
                    Layout.preferredHeight: 32
                    radius: 16
                    color: hovered ? Theme.danger : "transparent"
                    border.color: Theme.danger
                    border.width: 1
                    RowLayout {
                        anchors.centerIn: parent
                        spacing: 6
                        Text {
                            text: "󰩹"
                            color: clearBtn.hovered ? BarConfig.surfaceColor(Theme.surface) : Theme.danger
                            font.pixelSize: 13
                        }
                        Text {
                            text: "Limpiar"
                            color: clearBtn.hovered ? BarConfig.surfaceColor(Theme.surface) : Theme.danger
                            font.pixelSize: 12
                            font.bold: true
                        }
                    }
                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onEntered: clearBtn.hovered = true
                        onExited: clearBtn.hovered = false
                        onClicked: Services.ClipHistory.clearAll()
                    }
                }
            }

            // ---- Estado vacío ----
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                visible: Services.ClipHistory.items.length === 0
                spacing: 8
                Item { Layout.fillHeight: true }
                Text {
                    text: "󰅍"
                    color: Theme.subtext
                    font.pixelSize: 44
                    opacity: 0.5
                    Layout.alignment: Qt.AlignHCenter
                }
                Text {
                    text: "Sin elementos"
                    color: Theme.text
                    font.pixelSize: 14
                    font.bold: true
                    Layout.alignment: Qt.AlignHCenter
                }
                Text {
                    text: "Copia texto o imágenes y aparecerán aquí"
                    color: Theme.subtext
                    font.pixelSize: 12
                    Layout.alignment: Qt.AlignHCenter
                }
                Item { Layout.fillHeight: true }
            }

            // ---- Lista ----
            ListView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                visible: Services.ClipHistory.items.length > 0
                clip: true
                spacing: 10
                model: Services.ClipHistory.items

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    property bool isImg: modelData.isImage === true
                    property string kindLabel: modelData.kind !== undefined && modelData.kind !== "" ? modelData.kind : (isImg ? "Imagen" : "Texto")
                    property bool hovered: rowArea.containsMouse
                    width: ListView.view.width
                    height: 78
                    radius: Theme.radiusMedium
                    color: hovered ? Qt.lighter(Theme.bgAlt, 1.08) : Theme.bgAlt
                    border.color: hovered ? Theme.accent : Theme.border
                    border.width: 1

                    MouseArea {
                        id: rowArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        acceptedButtons: Qt.LeftButton | Qt.RightButton
                        onClicked: mouse => {
                            if (mouse.button === Qt.LeftButton) {
                                Services.ClipHistory.copy(row.modelData.raw)
                                root.hide()
                            }
                        }
                        onPressed: mouse => {
                            if (mouse.button === Qt.RightButton) Services.ClipHistory.deleteEntry(row.modelData.raw)
                        }
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: 10
                        spacing: 10

                        // Badge circular
                        Rectangle {
                            width: 36; height: 36
                            radius: 18
                            color: row.isImg
                                ? Qt.rgba(Theme.accentAlt.r, Theme.accentAlt.g, Theme.accentAlt.b, 0.2)
                                : Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.16)
                            border.color: row.isImg
                                ? Qt.rgba(Theme.accentAlt.r, Theme.accentAlt.g, Theme.accentAlt.b, 0.45)
                                : Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.4)
                            border.width: 1
                            Layout.alignment: Qt.AlignVCenter
                            Text {
                                anchors.centerIn: parent
                                text: row.isImg ? "󰋫" : "󰈙"
                                color: row.isImg ? Theme.accentAlt : Theme.accent
                                font.pixelSize: 16
                            }
                        }

                        // Textos
                        ColumnLayout {
                            Layout.fillWidth: true
                            Layout.alignment: Qt.AlignVCenter
                            spacing: 5
                            Text {
                                Layout.fillWidth: true
                                text: row.isImg && row.modelData.kind ? (row.modelData.kind + " · " + row.modelData.preview) : row.modelData.preview
                                color: Theme.text
                                font.pixelSize: 12
                                elide: Text.ElideRight
                                wrapMode: Text.WordWrap
                                maximumLineCount: 2
                                lineHeight: 1.25
                            }
                            Rectangle {
                                Layout.preferredHeight: 20
                                Layout.preferredWidth: kindTxt.implicitWidth + 16
                                radius: 10
                                color: row.isImg
                                    ? Qt.rgba(Theme.accentAlt.r, Theme.accentAlt.g, Theme.accentAlt.b, 0.16)
                                    : Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.14)
                                Text {
                                    id: kindTxt
                                    anchors.centerIn: parent
                                    text: row.kindLabel
                                    color: Theme.subtext
                                    font.pixelSize: 10
                                    font.bold: true
                                }
                            }
                        }

                        // Botón copiar
                        Rectangle {
                            id: copyBtn
                            property bool hovered: false
                            width: 28; height: 28
                            radius: 14
                            color: hovered ? Theme.accent : "transparent"
                            Layout.alignment: Qt.AlignVCenter
                            Text {
                                anchors.centerIn: parent
                                text: "󰆒"
                                color: copyBtn.hovered ? BarConfig.surfaceColor(Theme.surface) : Theme.subtext
                                font.pixelSize: 14
                            }
                            MouseArea {
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onEntered: copyBtn.hovered = true
                                onExited: copyBtn.hovered = false
                                onClicked: mouse => {
                                    mouse.accepted = true
                                    Services.ClipHistory.copy(row.modelData.raw)
                                    root.hide()
                                }
                            }
                        }

                        // Botón borrar
                        Rectangle {
                            id: delBtn
                            property bool hovered: false
                            width: 28; height: 28
                            radius: 14
                            color: hovered ? Theme.danger : "transparent"
                            Layout.alignment: Qt.AlignVCenter
                            Text {
                                anchors.centerIn: parent
                                text: "󰩹"
                                color: delBtn.hovered ? BarConfig.surfaceColor(Theme.surface) : Theme.subtext
                                font.pixelSize: 14
                            }
                            MouseArea {
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onEntered: delBtn.hovered = true
                                onExited: delBtn.hovered = false
                                onClicked: mouse => {
                                    mouse.accepted = true
                                    Services.ClipHistory.deleteEntry(row.modelData.raw)
                                }
                            }
                        }
                    }
                }
            }

            // ---- Footer hint ----
            Text {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
                text: "Clic en tarjeta para copiar · 󰆒 copiar · 󰩹 borrar"
                color: Theme.subtext
                font.pixelSize: 11
            }
        }
    }
}
