import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"
import "../services" as Services

PanelWindow {
    id: root
    property bool open: false
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    function show() { open = true; Services.ClipHistory.refresh() }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.15
        width: 420
        height: 480
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 10

            RowLayout {
                Layout.fillWidth: true
                Text { text: "Portapapeles"; color: Theme.text; font.pixelSize: 15; font.bold: true; Layout.fillWidth: true }
                Text {
                    text: "Limpiar"
                    color: Theme.danger
                    font.pixelSize: 12
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: Services.ClipHistory.clearAll() }
                }
            }

            ListView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 4
                model: Services.ClipHistory.items

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    width: ListView.view.width
                    height: 44
                    radius: Theme.radiusSmall
                    color: hovered ? Theme.bgAlt : "transparent"
                    property bool hovered: false

                    Text {
                        anchors.fill: parent
                        anchors.margins: 10
                        verticalAlignment: Text.AlignVCenter
                        text: row.modelData.preview
                        color: Theme.text
                        font.pixelSize: 12
                        elide: Text.ElideRight
                    }

                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onEntered: row.hovered = true
                        onExited: row.hovered = false
                        onClicked: { Services.ClipHistory.copy(row.modelData.raw); root.hide() }
                        acceptedButtons: Qt.LeftButton | Qt.RightButton
                        onPressed: mouse => {
                            if (mouse.button === Qt.RightButton) Services.ClipHistory.deleteEntry(row.modelData.raw)
                        }
                    }
                }
            }
        }
    }
}
