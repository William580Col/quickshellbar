#!/usr/bin/env sh
# Recopila el estado del adaptador y de los dispositivos Bluetooth conocidos
# para services/Bluetooth.qml (módulo de la barra). Emite líneas separadas por "|":
#   ADAPTER|Powered|<yes|no>|Discovering|<yes|no>
#   DEVICE|<addr>|<name>
#   FACT|<addr>|<Paired|Trusted|Connected|Battery>|<valor>
#
# Cada llamada a bluetoothctl va envuelta en `timeout` para no colgarse si
# el demonio bluetoothd no está disponible.

BT() {
  timeout 4 bluetoothctl "$@"
}

show=$(BT show 2>/dev/null || true)
if [ -z "$show" ]; then
  echo "ADAPTER|Powered|no|Discovering|no"
  exit 0
fi

printf '%s\n' "$show" | awk -F': *' '
  /Powered:/ { p=$2 }
  /Discovering:/ { d=$2 }
  END {
    gsub(/[ \t]+$/, "", p)
    gsub(/[ \t]+$/, "", d)
    printf "ADAPTER|Powered|%s|Discovering|%s\n", p, d
  }
'

devices=$(BT devices 2>/dev/null || true)
[ -n "$devices" ] || exit 0

printf '%s\n' "$devices" | while read -r _ addr name; do
  [ -n "$addr" ] || continue
  printf 'DEVICE|%s|%s\n' "$addr" "$name"
  BT info "$addr" 2>/dev/null | awk -v a="$addr" -F': *' '
    /Paired:/ { print "FACT|" a "|Paired|" $2 }
    /Trusted:/ { print "FACT|" a "|Trusted|" $2 }
    /Connected:/ { print "FACT|" a "|Connected|" $2 }
    /Battery Percentage:/ {
      v=$2
      gsub(/^[ \t]+|[ \t]+$/, "", v)
      n=v
      if (match(v, /\([0-9]+\)/)) n=substr(v, RSTART+1, RLENGTH-2)
      print "FACT|" a "|Battery|" n
    }
  '
done