#!/bin/sh
# Genera la paleta de color a partir de una imagen (matugen) y la aplica:
#   - a Hyprland: en caliente + persistente (colors.lua, cargado por
#     hyprland.lua vía dofile() en cada arranque)
#   - a fuzzel: persistente (colors.ini, se ve la próxima vez que lo abras)
#
# Uso: apply-colors.sh /ruta/al/wallpaper.png [dark|light]

IMG="$1"
MODE="${2:-dark}"

[ -f "$IMG" ] || { echo "ERROR: no existe la imagen: $IMG" >&2; exit 1; }

if ! command -v matugen >/dev/null 2>&1; then
    echo "ERROR: 'matugen' no está instalado (cargo install matugen)" >&2
    exit 1
fi

# Genera una miniatura para acelerar matugen (decodificar imágenes grandes es lento).
THUMB="$(mktemp --suffix=.png "${TMPDIR:-/tmp}/matugen-thumb.XXXXXX")" || THUMB=""
[ -n "$THUMB" ] && trap 'rm -f "$THUMB"' EXIT INT TERM
MATUGEN_IMG="$IMG"
if [ -n "$THUMB" ]; then
    if command -v magick >/dev/null 2>&1; then
        magick "$IMG" -auto-orient -filter point -resize '256x256>' "$THUMB" 2>/dev/null && MATUGEN_IMG="$THUMB"
    elif command -v convert >/dev/null 2>&1; then
        convert "$IMG" -auto-orient -filter point -resize '256x256>' "$THUMB" 2>/dev/null && MATUGEN_IMG="$THUMB"
    fi
fi

matugen image "$MATUGEN_IMG" -m "$MODE" || { echo "ERROR: matugen falló" >&2; exit 1; }

# Asegura el CSS de usuario GTK4 (import de colors.css).
sh "$HOME/.config/matugen/scripts/ensure-gtk4-css.sh" 2>/dev/null || true

# Rota la variante de iconos Tela según el acento recién generado.
# Se hace aquí (y no como post_hook de matugen) para leer el accent ya actualizado.
sh "$HOME/.config/matugen/scripts/set-tela-variant.sh" "$MODE" || true

# Aplica colors.lua en caliente sin esperar a un reinicio de Hyprland
if [ -f "$HOME/.config/hypr/colors.lua" ]; then
    hyprctl eval "dofile('$HOME/.config/hypr/colors.lua')" || \
        echo "AVISO: hyprctl eval falló, revisa que hyprland.lua ya cargue colors.lua" >&2
fi

# Aplica el tema GTK y color-scheme según el modo actual de quickshell
sh "$HOME/.config/quickshell/scripts/apply-gtk-theme.sh" || true

echo "OK"
