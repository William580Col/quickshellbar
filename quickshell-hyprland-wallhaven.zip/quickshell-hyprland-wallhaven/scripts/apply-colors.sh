#!/bin/sh
# Genera la paleta de color a partir de una imagen (matugen) y la aplica:
#   - a Hyprland: en caliente + persistente (colors.lua, cargado por
#     hyprland.lua vía dofile() en cada arranque)
#   - a fuzzel: persistente (colors.ini, se ve la próxima vez que lo abras)
#
# Uso: apply-colors.sh /ruta/al/wallpaper.png [dark|light]

IMG="$1"
MODE="${2:-dark}"

[ -f "$IMG" ] || { echo "ERROR: no existe la imagen: $IMG" >&2; exit 1; }

if ! command -v matugen >/dev/null 2>&1; then
    echo "ERROR: 'matugen' no está instalado (cargo install matugen)" >&2
    exit 1
fi

matugen image "$IMG" -m "$MODE" || { echo "ERROR: matugen falló" >&2; exit 1; }

# Aplica colors.lua en caliente sin esperar a un reinicio de Hyprland
if [ -f "$HOME/.config/hypr/colors.lua" ]; then
    hyprctl eval "dofile('$HOME/.config/hypr/colors.lua')" || \
        echo "AVISO: hyprctl eval falló, revisa que hyprland.lua ya cargue colors.lua" >&2
fi

echo "OK"
