#!/bin/sh
dir="$HOME/Pictures/Screenshots"
mkdir -p "$dir"
f="$dir/$(date +%Y-%m-%d_%H-%M-%S).png"
grim "$f" && wl-copy < "$f" && notify-send "Captura de pantalla" "Guardada en $f"
