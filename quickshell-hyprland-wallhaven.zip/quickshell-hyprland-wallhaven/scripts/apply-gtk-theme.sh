#!/bin/sh
# apply-gtk-theme.sh
# Aplica el tema GTK y el color-scheme del sistema según el modo
# guardado en ~/.local/state/quickshell-theme (light | dark).
# Modo claro  -> tema adw-gtk3 + color-scheme prefer-light
# Modo oscuro -> tema Darkly   + color-scheme prefer-dark
#
# Se invoca desde quickshell Theme.qml al cambiar el modo y desde
# apply-colors.sh al cambiar el wallpaper.

MODE_FILE="$HOME/.local/state/quickshell-theme"
ACCENT_FILE="$HOME/.local/state/quickshell-accent"
ENV_CONF="$HOME/.config/environment.d/quickshell-sway.conf"

# Asegura el CSS de usuario GTK4 (import de colors.css).
sh "$HOME/.config/matugen/scripts/ensure-gtk4-css.sh" 2>/dev/null || true

MODE="$(cat "$MODE_FILE" 2>/dev/null | tr -d ' \n\r\t')"
[ "$MODE" = "light" ] || MODE="dark"

# --- settings.ini GTK3 y GTK4 ---
for F in "$HOME/.config/gtk-3.0/settings.ini" "$HOME/.config/gtk-4.0/settings.ini"; do
    [ -f "$F" ] || continue
    if [ "$MODE" = "light" ]; then
        sed -i "s/^gtk-theme-name=.*/gtk-theme-name=adw-gtk3/" "$F"
        sed -i "s/^gtk-application-prefer-dark-theme=.*/gtk-application-prefer-dark-theme=0/" "$F"
    else
        sed -i "s/^gtk-theme-name=.*/gtk-theme-name=Darkly/" "$F"
        sed -i "s/^gtk-application-prefer-dark-theme=.*/gtk-application-prefer-dark-theme=1/" "$F"
    fi
    if grep -q '^gtk-icon-theme-name=' "$F"; then
        : # los iconos los gestiona set-tela-variant.sh
    else
        printf 'gtk-icon-theme-name=Tela-circle-grey%s\n' \
            "$([ "$MODE" = "dark" ] && echo -dark || echo)" >> "$F"
    fi
done

# --- gsettings color-scheme y gtk-theme ---
if [ "$MODE" = "light" ]; then
    gsettings set org.gnome.desktop.interface color-scheme 'prefer-light' 2>/dev/null || true
    gsettings set org.gnome.desktop.interface gtk-theme 'adw-gtk3' 2>/dev/null || true
    ADW_SCHEME="prefer-light"
    QT_STYLE="adw-gtk3"
else
    gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark' 2>/dev/null || true
    gsettings set org.gnome.desktop.interface gtk-theme 'Darkly' 2>/dev/null || true
    ADW_SCHEME="prefer-dark"
    QT_STYLE="Darkly"
fi

# --- environment.variables que fuerzan el esquema de color ---
# ADW_DEBUG_COLOR_SCHEME fuerza libadwaita a dark/light sin importar gsettings.
# QT_STYLE_OVERRIDE fuerza Qt a un tema concreto.
if [ -f "$ENV_CONF" ]; then
    if [ "$MODE" = "light" ]; then
        sed -i 's/^ADW_DEBUG_COLOR_SCHEME=.*/ADW_DEBUG_COLOR_SCHEME=prefer-light/' "$ENV_CONF"
        sed -i 's/^QT_STYLE_OVERRIDE=.*/QT_STYLE_OVERRIDE=adw-gtk3/' "$ENV_CONF"
    else
        sed -i 's/^ADW_DEBUG_COLOR_SCHEME=.*/ADW_DEBUG_COLOR_SCHEME=prefer-dark/' "$ENV_CONF"
        sed -i 's/^QT_STYLE_OVERRIDE=.*/QT_STYLE_OVERRIDE=Darkly/' "$ENV_CONF"
    fi
fi

# --- Reiniciar portal GTK para que recoga el nuevo gsettings ---
# --no-block evita que un portal lento retrase el cambio de wallpaper.
if systemctl --user is-active --quiet xdg-desktop-portal-gtk 2>/dev/null; then
    systemctl --user restart --no-block xdg-desktop-portal-gtk 2>/dev/null || true
elif pgrep -x xdg-desktop-portal-gtk >/dev/null 2>&1; then
    pkill -x xdg-desktop-portal-gtk 2>/dev/null || true
fi

# --- Rota la variante de iconos Tela según el acento y el modo ---
sh "$HOME/.config/matugen/scripts/set-tela-variant.sh" "$MODE" 2>/dev/null || true

echo "gtk-theme -> $MODE (theme=$( [ "$MODE" = "light" ] && echo adw-gtk3 || echo Darkly ))"
