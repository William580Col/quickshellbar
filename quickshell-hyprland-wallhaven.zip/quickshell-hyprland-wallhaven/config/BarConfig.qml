pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Configuración persistente de la barra: posición, auto-ocultar, escala,
  módulos habilitados/orden/zona, efecto cristal (transparencia + blur
  real de Hyprland si lo activas también en hyprland.lua, ver README) y
  apariencia (estilo Clásico/Caelestia, paneles integrados y marco de
  pantalla).
*/
Singleton {
    id: barConfig

    property string statePath: Quickshell.env("HOME") + "/.local/state/quickshell-bar-config.json"

    property string position: "top"   // "top" | "bottom"
    property bool autoHide: false
    property real scale: 1.0          // 0.8 .. 1.3
    property bool glassEffect: true

    // Apariencia general: "classic" (tarjetas flotantes separadas de la
    // barra) o "caelestia" (marco redondeado de pantalla y tarjetas unidas
    // a la barra). Elegir "caelestia" activa las dos opciones de abajo.
    property string appearanceStyle: "classic"   // "classic" | "caelestia"
    property bool integratedPanels: false        // tarjetas pegadas a la barra
    property bool screenBorder: false            // marco redondeado de pantalla
    readonly property bool caelestia: appearanceStyle === "caelestia"

    // Estado de visibilidad en tiempo de ejecución (NO se guarda): cada
    // barra registra si está oculta o tapada por fullscreen para que
    // ScreenFrame (otra ventana de la misma pantalla) ajuste la banda del
    // marco. Sin esto, al ocultar la barra el marco seguía pintando la
    // banda superior vacía (sin iconos) en estilo Caelestia.
    property var hiddenScreens: ({})
    property var fullscreenScreens: ({})

    function setBarVisibility(screenName, isHidden, isFullscreen) {
        if (!screenName) return
        var hiddenMap = Object.assign({}, barConfig.hiddenScreens)
        var fullscreenMap = Object.assign({}, barConfig.fullscreenScreens)
        if (isHidden) hiddenMap[screenName] = true
        else delete hiddenMap[screenName]
        if (isFullscreen) fullscreenMap[screenName] = true
        else delete fullscreenMap[screenName]
        barConfig.hiddenScreens = hiddenMap
        barConfig.fullscreenScreens = fullscreenMap
    }

    function barIsHidden(screenName) {
        return !!(screenName && barConfig.hiddenScreens[screenName])
    }

    function barIsFullscreen(screenName) {
        return !!(screenName && barConfig.fullscreenScreens[screenName])
    }

    // Cada módulo: { id, label, enabled, zone }. El orden dentro del array
    // determina el orden visual dentro de su propia zona.
    property var modules: defaultModules()

    property bool loaded: false

    function defaultModules() {
        return [
            { id: "launcher",     label: "Menú",             enabled: true, zone: "left" },
            { id: "workspaces",   label: "Espacios",         enabled: true, zone: "left" },
            { id: "bluetooth",    label: "Bluetooth",        enabled: true, zone: "left" },
            { id: "activewindow", label: "Ventana activa",   enabled: true, zone: "left" },
            { id: "windowswitcher", label: "Ventanas abiertas", enabled: true, zone: "left" },
            { id: "clock",        label: "Reloj",            enabled: true, zone: "center" },
            { id: "mediacontrols", label: "Control de medios", enabled: true, zone: "center" },
            { id: "tray",         label: "Bandeja",          enabled: true, zone: "right" },
            { id: "screenshot",   label: "Captura",          enabled: true, zone: "right" },
            { id: "wifi",         label: "Red",              enabled: true, zone: "right" },
            { id: "volume",       label: "Volumen",          enabled: true, zone: "right" },
            { id: "quicksettings", label: "Ajustes rápidos", enabled: true, zone: "right" },
            { id: "wallpaper",    label: "Wallpaper",        enabled: true, zone: "right" },
            { id: "clipboard",    label: "Portapapeles",     enabled: true, zone: "right" },
            { id: "barsettings",  label: "Configurar barra", enabled: true, zone: "right" },
            { id: "hidebar",      label: "Ocultar",          enabled: true, zone: "right" },
            { id: "power",        label: "Apagar",           enabled: true, zone: "right" },
        ]
    }

    function modulesForZone(zone) {
        return barConfig.modules.filter(m => m.zone === zone && m.enabled)
    }

    function setEnabled(id, enabled) {
        var arr = barConfig.modules.map(m => m.id === id ? Object.assign({}, m, { enabled: enabled }) : m)
        barConfig.modules = arr
        save()
    }

    function cycleZone(id) {
        var order = ["left", "center", "right"]
        var arr = barConfig.modules.map(m => {
            if (m.id !== id) return m
            var next = order[(order.indexOf(m.zone) + 1) % order.length]
            return Object.assign({}, m, { zone: next })
        })
        barConfig.modules = arr
        save()
    }

    function moveModule(id, direction) {
        var arr = barConfig.modules.slice()
        var idx = arr.findIndex(m => m.id === id)
        if (idx === -1) return
        var newIdx = idx + direction
        if (newIdx < 0 || newIdx >= arr.length) return
        var tmp = arr[idx]
        arr[idx] = arr[newIdx]
        arr[newIdx] = tmp
        barConfig.modules = arr
        save()
    }

    function setPosition(p) { barConfig.position = p; save() }
    function setAutoHide(v) { barConfig.autoHide = v; save() }
    function setScale(v) { barConfig.scale = v; save() }
    function setGlassEffect(v) { barConfig.glassEffect = v; save() }
    function setGlassAlpha(v) { barConfig.glassAlpha = Math.max(0.2, Math.min(1.0, v)); save() }

    // Cambia de estilo: Caelestia trae marco de pantalla y paneles
    // integrados; Clásico los desactiva (se pueden reajustar a mano
    // con los dos interruptores de la pestaña Apariencia).
    function setAppearanceStyle(style) {
        barConfig.appearanceStyle = style === "caelestia" ? "caelestia" : "classic"
        barConfig.integratedPanels = barConfig.caelestia
        barConfig.screenBorder = barConfig.caelestia
        save()
    }
    function setIntegratedPanels(v) { barConfig.integratedPanels = v; save() }
    function setScreenBorder(v) { barConfig.screenBorder = v; save() }

    // Alto total de la ventana de la barra (fondo + márgenes del marco) y
    // coordenada del borde visible del fondo de la barra (los6px de aire
    // inferiores de la ventana no se pintan: la superficie llega hasta
    // surfaceBottom en Bar.qml, igual que la pastilla clásica).
    // Redondeo a píxel entero en tiempo de lectura (el scale guardado puede
    // ser fraccionario, p. ej. 0.85022): con un valor entre píxeles la unión
    // superior del marco caería descentrada y saldría escalonada, mientras
    // las esquinas inferiores (enteras) se ven nítidas.
    readonly property real barSurfaceEdge: Math.round(Theme.barHeight * barConfig.scale + 6)
    // Se deriva de la anterior para mantener la relación exacta ventana = borde + 6.
    readonly property real barWindowHeight: barSurfaceEdge + 6

    // Franja superior/inferior que el mask de los paneles deja pasar para
    // que la barra siga siendo clicable con una tarjeta abierta. Llega
    // justo hasta el borde de la tarjeta para no recortar su unión.
    readonly property real barMaskHeight: barSurfaceEdge - 1

    // Coordenada y de una tarjeta integrada a la barra: queda metida2px
    // bajo el borde de la barra (solape) para que no se vea ninguna línea
    // entre las dos y la unión sea continua. parentHeight = alto de la
    // ventana del panel, cardHeight = alto de la tarjeta. Con la barra
    // abajo, cuelga hacia arriba en espejo.
    function integratedY(parentHeight, cardHeight) {
        var edge = barConfig.barSurfaceEdge   // borde del fondo de la barra
        return barConfig.position === "top"
            ? edge - 2
            : parentHeight - edge + 2 - cardHeight
    }

    // Aplica transparencia "cristal" a un color de fondo si la opción está
    // activa. Se usa en la barra y en todos los menús/paneles.
    // NOTA Hyprland: la transparencia es propia (alpha 0.82). El blur real
    // se controla con la layer_rule de hyprland.lua (namespace "quickshell"),
    // que en esta máquina va en blur=false por rendimiento (i915).
    property real glassAlpha: 0.82
    function surfaceColor(base) {
        return barConfig.glassEffect ? Qt.rgba(base.r, base.g, base.b, barConfig.glassAlpha) : base
    }

    function restoreDefaults() {
        barConfig.position = "top"
        barConfig.autoHide = false
        barConfig.scale = 1.0
        barConfig.glassEffect = true
        barConfig.glassAlpha = 0.82
        barConfig.appearanceStyle = "classic"
        barConfig.integratedPanels = false
        barConfig.screenBorder = false
        barConfig.modules = defaultModules()
        save()
    }

    function save() {
        var data = {
            position: barConfig.position,
            autoHide: barConfig.autoHide,
            scale: barConfig.scale,
            glassEffect: barConfig.glassEffect,
            glassAlpha: barConfig.glassAlpha,
            appearanceStyle: barConfig.appearanceStyle,
            integratedPanels: barConfig.integratedPanels,
            screenBorder: barConfig.screenBorder,
            modules: barConfig.modules
        }
        var json = JSON.stringify(data)
        saveProc.command = ["sh", "-c",
            "mkdir -p \"$(dirname '" + barConfig.statePath + "')\" && cat > '" + barConfig.statePath + "' << 'QSBARCONFEOF'\n" +
            json + "\nQSBARCONFEOF"]
        saveProc.running = true
    }

    Process { id: saveProc }

    Component.onCompleted: {
        loadProc.running = true
    }

    Process {
        id: loadProc
        command: ["sh", "-c", "cat '" + barConfig.statePath + "' 2>/dev/null || true"]
        property string buf: ""
        stdout: SplitParser { onRead: line => loadProc.buf += line }
        onExited: {
            if (loadProc.buf.trim().length > 0) {
                try {
                    var data = JSON.parse(loadProc.buf)
                    if (data.position) barConfig.position = data.position
                    if (typeof data.autoHide === "boolean") barConfig.autoHide = data.autoHide
                    if (typeof data.scale === "number") barConfig.scale = data.scale
                    if (typeof data.glassEffect === "boolean") barConfig.glassEffect = data.glassEffect
                    if (typeof data.glassAlpha === "number") barConfig.glassAlpha = Math.max(0.2, Math.min(1.0, data.glassAlpha))
                    if (data.appearanceStyle === "classic" || data.appearanceStyle === "caelestia")
                        barConfig.appearanceStyle = data.appearanceStyle
                    if (typeof data.integratedPanels === "boolean") barConfig.integratedPanels = data.integratedPanels
                    if (typeof data.screenBorder === "boolean") barConfig.screenBorder = data.screenBorder
                    if (Array.isArray(data.modules) && data.modules.length > 0) {
                        var mods = data.modules
                        // Migración: inserta "hidebar" a la izquierda de "power"
                        // en configs guardadas antes de que existiera el módulo.
                        if (!mods.some(m => m.id === "hidebar")) {
                            var powIdx = mods.findIndex(m => m.id === "power")
                            var hideEntry = { id: "hidebar", label: "Ocultar", enabled: true, zone: "right" }
                            if (powIdx === -1) mods.push(hideEntry)
                            else mods.splice(powIdx, 0, hideEntry)
                        }
                        barConfig.modules = mods
                    }
                } catch (e) {
                    console.warn("[BarConfig] Error leyendo config guardada:", e)
                }
            }
            barConfig.loaded = true
            loadProc.buf = ""
        }
    }
}
