pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Configuración persistente de la barra: posición, auto-ocultar, escala,
  módulos habilitados/orden/zona, y efecto cristal (transparencia + blur
  real de Hyprland si lo activas también en hyprland.lua, ver README).
*/
Singleton {
    id: barConfig

    property string statePath: Quickshell.env("HOME") + "/.local/state/quickshell-bar-config.json"

    property string position: "top"   // "top" | "bottom"
    property bool autoHide: false
    property real scale: 1.0          // 0.8 .. 1.3
    property bool glassEffect: false

    // Cada módulo: { id, label, enabled, zone }. El orden dentro del array
    // determina el orden visual dentro de su propia zona.
    property var modules: defaultModules()

    property bool loaded: false

    function defaultModules() {
        return [
            { id: "launcher",     label: "Menú",             enabled: true, zone: "left" },
            { id: "workspaces",   label: "Espacios",         enabled: true, zone: "left" },
            { id: "activewindow", label: "Ventana activa",   enabled: true, zone: "left" },
            { id: "clock",        label: "Reloj",            enabled: true, zone: "center" },
            { id: "tray",         label: "Bandeja",          enabled: true, zone: "right" },
            { id: "screenshot",   label: "Captura",          enabled: true, zone: "right" },
            { id: "wifi",         label: "Red",              enabled: true, zone: "right" },
            { id: "volume",       label: "Volumen",          enabled: true, zone: "right" },
            { id: "quicksettings", label: "Ajustes rápidos", enabled: true, zone: "right" },
            { id: "wallpaper",    label: "Wallpaper",        enabled: true, zone: "right" },
            { id: "clipboard",    label: "Portapapeles",     enabled: true, zone: "right" },
            { id: "barsettings",  label: "Configurar barra", enabled: true, zone: "right" },
            { id: "power",        label: "Apagar",           enabled: true, zone: "right" },
        ]
    }

    function modulesForZone(zone) {
        return barConfig.modules.filter(m => m.zone === zone && m.enabled)
    }

    function setEnabled(id, enabled) {
        var arr = barConfig.modules.map(m => m.id === id ? Object.assign({}, m, { enabled: enabled }) : m)
        barConfig.modules = arr
        save()
    }

    function cycleZone(id) {
        var order = ["left", "center", "right"]
        var arr = barConfig.modules.map(m => {
            if (m.id !== id) return m
            var next = order[(order.indexOf(m.zone) + 1) % order.length]
            return Object.assign({}, m, { zone: next })
        })
        barConfig.modules = arr
        save()
    }

    function moveModule(id, direction) {
        var arr = barConfig.modules.slice()
        var idx = arr.findIndex(m => m.id === id)
        if (idx === -1) return
        var newIdx = idx + direction
        if (newIdx < 0 || newIdx >= arr.length) return
        var tmp = arr[idx]
        arr[idx] = arr[newIdx]
        arr[newIdx] = tmp
        barConfig.modules = arr
        save()
    }

    function setPosition(p) { barConfig.position = p; save() }
    function setAutoHide(v) { barConfig.autoHide = v; save() }
    function setScale(v) { barConfig.scale = v; save() }
    function setGlassEffect(v) { barConfig.glassEffect = v; save() }

    // Aplica transparencia "cristal" a un color de fondo si la opción está
    // activa. Se usa en la barra y en todos los menús/paneles. Para blur
    // real (no solo transparencia) hace falta además la regla de Hyprland
    // documentada en el README (hl.layer_rule con namespace "quickshell").
    property real glassAlpha: 0.82
    function surfaceColor(base) {
        return barConfig.glassEffect ? Qt.rgba(base.r, base.g, base.b, barConfig.glassAlpha) : base
    }

    function restoreDefaults() {
        barConfig.position = "top"
        barConfig.autoHide = false
        barConfig.scale = 1.0
        barConfig.glassEffect = false
        barConfig.modules = defaultModules()
        save()
    }

    function save() {
        var data = {
            position: barConfig.position,
            autoHide: barConfig.autoHide,
            scale: barConfig.scale,
            glassEffect: barConfig.glassEffect,
            modules: barConfig.modules
        }
        var json = JSON.stringify(data)
        saveProc.command = ["sh", "-c",
            "mkdir -p \"$(dirname '" + barConfig.statePath + "')\" && cat > '" + barConfig.statePath + "' << 'QSBARCONFEOF'\n" +
            json + "\nQSBARCONFEOF"]
        saveProc.running = true
    }

    Process { id: saveProc }

    Component.onCompleted: {
        loadProc.running = true
    }

    Process {
        id: loadProc
        command: ["sh", "-c", "cat '" + barConfig.statePath + "' 2>/dev/null || true"]
        property string buf: ""
        stdout: SplitParser { onRead: line => loadProc.buf += line }
        onExited: {
            if (loadProc.buf.trim().length > 0) {
                try {
                    var data = JSON.parse(loadProc.buf)
                    if (data.position) barConfig.position = data.position
                    if (typeof data.autoHide === "boolean") barConfig.autoHide = data.autoHide
                    if (typeof data.scale === "number") barConfig.scale = data.scale
                    if (typeof data.glassEffect === "boolean") barConfig.glassEffect = data.glassEffect
                    if (Array.isArray(data.modules) && data.modules.length > 0) barConfig.modules = data.modules
                } catch (e) {
                    console.warn("[BarConfig] Error leyendo config guardada:", e)
                }
            }
            barConfig.loaded = true
            loadProc.buf = ""
        }
    }
}
