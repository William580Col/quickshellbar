pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Theme: singleton global de colores y geometría.
  Cambia entre modo claro/oscuro y persiste la preferencia en disco.
*/
Singleton {
    id: theme

    property bool dark: true
    property string statePath: Quickshell.env("HOME") + "/.local/state/quickshell-theme"
    property string accentStatePath: Quickshell.env("HOME") + "/.local/state/quickshell-accent"

    // Radios y espaciados generales (bordes redondeados en todo el shell)
    property int radiusSmall: 10
    property int radiusMedium: 16
    property int radiusLarge: 22
    property int spacing: 8
    property int barHeight: 40

    // Paleta oscura
    readonly property color darkBg: "#1a1b26"
    readonly property color darkBgAlt: "#20222f"
    readonly property color darkSurface: "#262838"
    readonly property color darkText: "#e6e6f0"
    readonly property color darkSubtext: "#9a9cb5"
    readonly property color darkBorder: "#3a3d52"

    // Paleta clara
    readonly property color lightBg: "#f4f4fb"
    readonly property color lightBgAlt: "#ffffff"
    readonly property color lightSurface: "#ffffff"
    readonly property color lightText: "#1c1c28"
    readonly property color lightSubtext: "#5b5d75"
    readonly property color lightBorder: "#d9d9ec"

    // Acento (igual en ambos modos, se puede generar con matugen/wallust si quieres)
    property color accent: "#8aa2ff"
    property color accentAlt: "#c792ea"
    property color danger: "#ff6b81"
    property color warning: "#ffb86b"
    property color ok: "#7ee8a0"

    property color bg: dark ? darkBg : lightBg
    property color bgAlt: dark ? darkBgAlt : lightBgAlt
    property color surface: dark ? darkSurface : lightSurface
    property color text: dark ? darkText : lightText
    property color subtext: dark ? darkSubtext : lightSubtext
    property color border: dark ? darkBorder : lightBorder

    function toggle() {
        dark = !dark
        save()
    }

    function save() {
        writeProc.text = dark ? "dark" : "light"
        writeProc.running = true
    }

    Process {
        id: writeProc
        property string text: ""
        command: ["sh", "-c", "mkdir -p $(dirname '" + theme.statePath + "') && printf '%s' '" + "'\"$MODE\"'" + "' > '" + theme.statePath + "'"]
        environment: ({ MODE: text })
    }

    Process {
        id: readProc
        command: ["sh", "-c", "cat '" + theme.statePath + "' 2>/dev/null || echo dark"]
        running: true
        stdout: SplitParser {
            onRead: data => {
                theme.dark = data.trim() !== "light"
            }
        }
    }

    // Recarga el color de acento generado por matugen a partir del
    // wallpaper activo (services/Wallpaper.qml llama a esto tras generar
    // la paleta). Si el archivo no existe todavía o el valor no es un hex
    // válido, se ignora silenciosamente y se mantiene el acento actual.
    function reloadAccent() {
        accentReadProc.running = true
    }

    Process {
        id: accentReadProc
        command: ["sh", "-c", "cat '" + theme.accentStatePath + "' 2>/dev/null || true"]
        stdout: SplitParser {
            onRead: line => {
                var hex = line.trim().replace(/^#/, "")
                if (/^[0-9a-fA-F]{6}$/.test(hex)) {
                    theme.accent = "#" + hex
                }
            }
        }
    }

    Component.onCompleted: reloadAccent()
}
