//@ pragma UseQApplication
import QtQuick
import Quickshell
import Quickshell.Io
import "modules"
import "config"
import "services" as Services

/*
  shell.qml — punto de entrada de Quickshell.
  Instalar en: ~/.config/quickshell/shell.qml (junto con modules/, config/, services/)
  Ejecutar con:  quickshell
  o en autostart de tu compositor (ver README.md).
*/
ShellRoot {
    id: root

    // Fuerza que los singletons de servicios se inicialicen desde el arranque
    Component.onCompleted: {
        Services.Wallpaper
        Services.Notifs
        Services.Network.refresh()
        Services.Brightness.refresh()
    }

    // Una barra por cada pantalla conectada
    Variants {
        model: Quickshell.screens

        Bar {
            id: barInstance
            launcherRef: launcherWindow
            powerMenuRef: powerMenuWindow
            clipRef: clipWindow
            wallpaperRef: wallpaperWindow
            wifiPanelRef: wifiPanelWindow
            barSettingsRef: barSettingsWindow
        }
    }

    // Capas globales (una sola instancia, visibles/ocultas por toggle)
    Launcher { id: launcherWindow }
    PowerMenu { id: powerMenuWindow }
    ClipHistoryPanel { id: clipWindow }
    WallpaperPanel { id: wallpaperWindow }
    WiFiPanel { id: wifiPanelWindow }
    BarSettingsPanel { id: barSettingsWindow }
    NotificationPopups {}
    VolumeOSD {}

    // ---- IPC: permite abrir paneles desde atajos de teclado del compositor ----
    // Ejemplo Hyprland (ver README.md):
    //   bind = SUPER, D, exec, qs ipc call launcher toggle
    //   bind = SUPER, ESCAPE, exec, qs ipc call powermenu toggle
    //   bind = SUPER, V, exec, qs ipc call clip toggle
    IpcHandler {
        target: "launcher"
        function toggle() { launcherWindow.toggle() }
        function show() { launcherWindow.show() }
        function hide() { launcherWindow.hide() }
    }

    IpcHandler {
        target: "powermenu"
        function toggle() { powerMenuWindow.toggle() }
    }

    IpcHandler {
        target: "clip"
        function toggle() { clipWindow.toggle() }
    }

    IpcHandler {
        target: "theme"
        function toggle() { Theme.toggle() }
    }

    IpcHandler {
        target: "wallpaper"
        function random() { Services.Wallpaper.random() }
        function next() { Services.Wallpaper.random() }
        function toggle() { wallpaperWindow.toggle() }
    }

    IpcHandler {
        target: "wifi"
        function toggle() { wifiPanelWindow.toggle() }
    }

    IpcHandler {
        target: "barsettings"
        function toggle() { barSettingsWindow.toggle() }
    }
}
