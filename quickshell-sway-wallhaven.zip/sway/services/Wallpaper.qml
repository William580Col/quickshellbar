pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import "../config"

/*
  Manejo de wallpapers. Prioridad de backends detectados automáticamente:
    1) awww   - fork activo y mantenido de swww, transiciones bonitas
                (swww fue archivado por su propio autor; awww lo continúa
                con binarios PROPIOS awww/awww-daemon, no son alias)
    2) swww   - por si todavía lo tienes instalado (deprecado, sin
                mantenimiento activo, se mantiene como último recurso
                antes de swaybg)
    3) swaybg - universal, sin transición (fallback final)

  awww:   https://codeberg.org/LGFae/awww (AUR: awww / awww-git)
  swww:   https://github.com/LGFae/swww (archivado, ya no se actualiza)
  swaybg: sudo apt install swaybg

  Si tienes matugen instalado, cada wallpaper nuevo también genera y aplica
  una paleta de color al acento del shell y a fuzzel (ver scripts/apply-colors.sh
  y matugen-templates/). No incluye theming de bordes de ventana porque eso
  es específico de cada compositor — si tu compositor soporta cambiar los
  colores de borde en caliente, se puede agregar de forma análoga a como se
  hizo en la variante Hyprland.
*/
Singleton {
    id: wallpaper

    property string directory: Quickshell.env("HOME") + "/Pictures/Wallpapers"
    property string statePath: Quickshell.env("HOME") + "/.local/state/quickshell-wallpaper"
    property string thumbDir: Quickshell.env("HOME") + "/.cache/quickshell/wallpaper-thumbs"
    property string current: ""
    property var list: []
    property string backend: "swaybg" // "awww" | "swww" | "swaybg"
    property bool backendChecked: false

    // Si tienes matugen instalado, cada wallpaper nuevo también genera y
    // aplica una paleta de color al acento del shell y a fuzzel. Pon esto
    // en 'false' si no quieres theming automático o no tienes matugen.
    property bool colorThemingEnabled: true

    // Modo de ajuste ("center" | "fill" | "stretch"). Solo tiene efecto
    // real con el backend swaybg (bandera -m); awww/swww no tienen una
    // bandera equivalente en su CLI — siempre recortan a llenar la
    // pantalla, así que con esos backends esta opción no cambia nada.
    property string fitMode: "fill"

    function setFitMode(mode) {
        wallpaper.fitMode = mode
        if (wallpaper.current.length > 0) wallpaper.set(wallpaper.current)
    }

    Component.onCompleted: {
        checkProc.running = true
        refresh()
    }

    function refresh() {
        wallpaper.list = []
        listProc.command = ["sh", "-c", "find '" + directory + "' -maxdepth 1 -type f \\( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o -iname '*.webp' \\) 2>/dev/null | sort"]
        listProc.running = true
    }

    function set(path) {
        current = path
        wallpaper.saveState(path)
        if (colorThemingEnabled) wallpaper.applyColorTheme(path)
        var escaped = path.replace(/'/g, "'\\''")

        if (backend === "awww" || backend === "swww") {
            // Misma CLI en ambos (awww mantiene compatibilidad de
            // comandos con swww): "<bin> img <ruta> --transition-type ... --transition-duration ..."
            // Si tu versión de awww no acepta estas banderas, corre
            // "awww img --help" para ver las vigentes y ajusta aquí.
            setImgProc.command = [backend, "img", path, "--transition-type", "wipe", "--transition-duration", "1"]
            setImgProc.running = true
        } else {
            // swaybg no permite "cambiar" en caliente: matar y relanzar,
            // desacoplado con setsid (no 'disown', que no existe en sh/dash).
            setSwaybgProc.command = ["sh", "-c",
                "pkill -x swaybg 2>/dev/null; sleep 0.2; " +
                "setsid swaybg -i '" + escaped + "' -m " + wallpaper.fitMode + " " +
                ">/tmp/swaybg.log 2>&1 < /dev/null &"]
            setSwaybgProc.running = true
        }
    }

    function random() {
        if (list.length === 0) return
        set(list[Math.floor(Math.random() * list.length)])
    }

    // Ruta de la miniatura cacheada para una imagen dada. Se usa el path
    // completo (con "/" -> "_") como nombre, así nunca hay colisiones y no
    // hace falta ninguna herramienta de hash externa.
    function thumbPathFor(path) {
        return thumbDir + "/" + path.replace(/\//g, "_") + ".jpg"
    }

    // Genera (una sola vez, cacheado en disco) una miniatura pequeña por
    // cada wallpaper con ImageMagick, para que abrir el panel sea rápido
    // incluso con muchas imágenes de alta resolución. Si no tienes
    // ImageMagick instalado, esto no hace nada y el panel simplemente usa
    // las imágenes originales (más lento, pero sigue funcionando).
    function generateThumbnails() {
        if (wallpaper.list.length === 0) return
        var script = "mkdir -p '" + thumbDir + "'; "
        script += "command -v convert >/dev/null 2>&1 || exit 0; "
        for (var i = 0; i < wallpaper.list.length; i++) {
            var src = wallpaper.list[i]
            var thumb = wallpaper.thumbPathFor(src)
            var escSrc = src.replace(/'/g, "'\\''")
            var escThumb = thumb.replace(/'/g, "'\\''")
            script += "[ -f '" + escThumb + "' ] || convert '" + escSrc + "[0]' -auto-orient -thumbnail '320x180^' -gravity center -extent 320x180 '" + escThumb + "' 2>/dev/null; "
        }
        thumbProc.command = ["sh", "-c", script]
        thumbProc.running = true
    }

    Process {
        id: thumbProc
        stderr: SplitParser { onRead: line => console.warn("[Wallpaper] miniatura:", line) }
    }

    // Detecta el mejor backend disponible, en orden de preferencia:
    // awww (activo) > swww (deprecado, por si aún lo tienes) > swaybg
    Process {
        id: checkProc
        command: ["sh", "-c",
            "if command -v awww >/dev/null 2>&1; then echo awww; " +
            "elif command -v swww >/dev/null 2>&1; then echo swww; " +
            "else echo swaybg; fi"]
        stdout: SplitParser {
            onRead: line => {
                wallpaper.backend = line.trim()
                wallpaper.backendChecked = true
                if (wallpaper.backend === "awww" || wallpaper.backend === "swww") {
                    daemonProc.command = ["sh", "-c",
                        "pgrep -x " + wallpaper.backend + "-daemon >/dev/null || " +
                        "setsid " + wallpaper.backend + "-daemon >/tmp/" + wallpaper.backend + "-daemon.log 2>&1 < /dev/null &"]
                    daemonProc.running = true
                    if (wallpaper.backend === "swww") {
                        console.warn("[Wallpaper] Usando 'swww' (deprecado, archivado por su autor). Considera migrar a 'awww': https://codeberg.org/LGFae/awww")
                    }
                } else {
                    console.warn("[Wallpaper] Ni 'awww' ni 'swww' encontrados, usando 'swaybg'. Revisa /tmp/swaybg.log si no cambia la imagen.")
                }
                startupTimer.restart()
            }
        }
    }

    Process { id: daemonProc }

    // Al arrancar (nueva sesión), reaplica el último wallpaper guardado.
    // El delay le da tiempo al daemon (awww-daemon/swww-daemon/swaybg) de
    // estar listo.
    Timer {
        id: startupTimer
        interval: 1200
        repeat: false
        onTriggered: wallpaper.loadSavedWallpaper()
    }

    function loadSavedWallpaper() {
        loadStateProc.running = true
    }

    function saveState(path) {
        saveStateProc.command = ["sh", "-c",
            "mkdir -p \"$(dirname '" + wallpaper.statePath + "')\" && printf '%s' '" +
            path.replace(/'/g, "'\\''") + "' > '" + wallpaper.statePath + "'"]
        saveStateProc.running = true
    }

    Process {
        id: loadStateProc
        command: ["sh", "-c", "cat '" + wallpaper.statePath + "' 2>/dev/null || true"]
        stdout: SplitParser {
            onRead: line => {
                var p = line.trim()
                if (p.length > 0) wallpaper.set(p)
            }
        }
    }

    Process { id: saveStateProc }

    // Genera la paleta con matugen (a partir del wallpaper) y la aplica al
    // acento del shell y a fuzzel (persistente). Ver scripts/apply-colors.sh.
    // Modo claro/oscuro sigue al toggle de tema del propio shell.
    function applyColorTheme(path) {
        var mode = Theme.dark ? "dark" : "light"
        var script = Quickshell.env("HOME") + "/.config/quickshell/sway/scripts/apply-colors.sh"
        colorThemeProc.command = ["sh", "-c", "'" + script + "' '" + path.replace(/'/g, "'\\''") + "' '" + mode + "'"]
        colorThemeProc.running = true
    }

    Process {
        id: colorThemeProc
        stdout: SplitParser { onRead: line => console.log("[Wallpaper] apply-colors:", line) }
        stderr: SplitParser { onRead: line => console.warn("[Wallpaper] apply-colors:", line) }
        onExited: (code, status) => {
            if (code !== 0) {
                console.warn("[Wallpaper] apply-colors.sh salió con código", code, "(¿tienes matugen instalado?)")
            } else {
                Theme.reloadAccent()
            }
        }
    }

    Process {
        id: listProc
        stdout: SplitParser {
            onRead: line => {
                if (line.trim().length > 0) wallpaper.list.push(line.trim())
                wallpaper.listChanged()
            }
        }
        onExited: wallpaper.generateThumbnails()
    }

    Process {
        id: setImgProc
        stderr: SplitParser { onRead: line => console.warn("[Wallpaper] " + wallpaper.backend + ":", line) }
    }

    Process {
        id: setSwaybgProc
        stderr: SplitParser { onRead: line => console.warn("[Wallpaper] swaybg (lanzador):", line) }
    }
}
