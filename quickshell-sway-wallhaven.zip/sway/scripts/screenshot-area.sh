#!/bin/sh
# Captura de área. Se invoca vía "swaymsg exec <esta-ruta>" desde
# Screenshot.qml — NUNCA como texto inline en swaymsg, porque el
# protocolo IPC de Sway trata ";" como separador entre comandos de Sway,
# y este script usa "if ... ; then ... fi" (rompería con un error tipo
# "Unknown/invalid command 'then'" si se mandara como texto directo).
dir="$HOME/Pictures/Screenshots"
mkdir -p "$dir"
g=$(slurp) || exit 0
[ -n "$g" ] || exit 0
f="$dir/$(date +%Y-%m-%d_%H-%M-%S).png"
grim -g "$g" "$f" && wl-copy < "$f" && notify-send "Captura de pantalla" "Área guardada en $f"
