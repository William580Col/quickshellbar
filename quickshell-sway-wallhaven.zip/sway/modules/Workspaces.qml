import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import "../config"

/*
  Indicador de workspaces con números para Sway. Usa `swaymsg -t
  get_workspaces` (JSON) por proceso, refrescado por timer, y cambia de
  workspace con `swaymsg workspace number <n>`.
*/
Row {
    id: root
    spacing: 6
    height: 26

    property var workspaces: []

    function refresh() { listProc.running = true }

    Timer { interval: 1000; running: true; repeat: true; onTriggered: root.refresh() }
    Component.onCompleted: root.refresh()

    Process {
        id: listProc
        command: ["swaymsg", "-t", "get_workspaces"]
        property string buf: ""
        stdout: SplitParser { onRead: line => listProc.buf += line }
        onExited: {
            try {
                root.workspaces = JSON.parse(listProc.buf)
            } catch (e) {
                console.warn("[Workspaces/Sway] Error parseando JSON:", e)
            }
            listProc.buf = ""
        }
    }

    Repeater {
        model: root.workspaces

        delegate: Item {
            id: cell
            required property var modelData
            property bool active: modelData.focused
            property bool hasWindows: modelData.visible || modelData.focused

            width: pill.width
            height: 26

            Rectangle {
                id: pill
                anchors.centerIn: parent
                width: Math.max(26, label.implicitWidth + 16)
                height: 22
                radius: 11
                color: cell.active ? Theme.accent
                       : (cell.hasWindows ? Theme.bgAlt : "transparent")
                border.width: cell.active ? 0 : 1
                border.color: cell.hasWindows ? Theme.border : Qt.rgba(Theme.border.r, Theme.border.g, Theme.border.b, 0.5)

                Behavior on width { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                Behavior on color { ColorAnimation { duration: 160 } }

                Text {
                    id: label
                    anchors.centerIn: parent
                    text: cell.modelData.num
                    font.pixelSize: 11
                    font.bold: cell.active
                    color: cell.active ? Theme.bg : (cell.hasWindows ? Theme.text : Theme.subtext)
                }
            }

            MouseArea {
                anchors.fill: parent
                anchors.margins: -4
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    switchProc.command = ["swaymsg", "workspace", "number", String(cell.modelData.num)]
                    switchProc.running = true
                }
            }
        }
    }

    Process { id: switchProc }
}
