import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import "../config"

/*
  Captura de pantalla para Sway.

  IMPORTANTE: la captura de área se lanza vía "swaymsg exec <archivo>",
  apuntando a un SCRIPT EXTERNO (scripts/screenshot-area.sh) — no se le
  pasa el script completo como texto en línea. El protocolo IPC de Sway
  trata ";" como separador entre comandos de Sway, así que cualquier
  script con más de una instrucción (if/then, &&, etc.) embebido
  directamente en el comando se rompe con un error tipo
  "Unknown/invalid command 'then'". Pasándole solo la ruta del archivo
  evitamos que Sway vea ningún ";" en el comando que le llega por IPC.
*/
Row {
    id: root
    spacing: 14

    property string scriptsDir: Quickshell.env("HOME") + "/.config/quickshell/sway/scripts"
    property string dir: Quickshell.env("HOME") + "/Pictures/Screenshots"

    // Captura completa (esta no tiene el problema del ";" porque no la
    // lanzamos por swaymsg, es un proceso directo de un solo comando)
    Item {
        width: 18; height: 18
        anchors.verticalCenter: parent.verticalCenter
        Text {
            anchors.centerIn: parent
            text: "󰄀"
            color: Theme.text
            font.pixelSize: 15
        }
        MouseArea {
            anchors.fill: parent
            anchors.margins: -8
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                if (fullProc.running) return
                fullProc.command = [
                    "sh", "-c",
                    "mkdir -p '" + root.dir + "' && " +
                    "f=\"" + root.dir + "/$(date +%Y-%m-%d_%H-%M-%S).png\" && " +
                    "grim \"$f\" && " +
                    "wl-copy < \"$f\" && " +
                    "notify-send 'Captura de pantalla' \"Guardada en $f\""
                ]
                fullProc.running = true
            }
        }
    }

    // Captura de área — vía swaymsg exec apuntando al SCRIPT (no al texto)
    Item {
        width: 18; height: 18
        anchors.verticalCenter: parent.verticalCenter
        Text {
            anchors.centerIn: parent
            text: "󰆞"
            color: Theme.text
            font.pixelSize: 15
        }
        MouseArea {
            anchors.fill: parent
            anchors.margins: -8
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                if (areaProc.running) return
                areaProc.command = ["swaymsg", "exec", "--", root.scriptsDir + "/screenshot-area.sh"]
                areaProc.running = true
            }
        }
    }

    Process {
        id: fullProc
        stdout: SplitParser { onRead: line => console.log("[Screenshot full] stdout:", line) }
        stderr: SplitParser { onRead: line => console.warn("[Screenshot full] stderr:", line) }
    }

    Process {
        id: areaProc
        stdout: SplitParser { onRead: line => console.log("[Screenshot area] stdout:", line) }
        stderr: SplitParser { onRead: line => console.warn("[Screenshot area] stderr:", line) }
    }
}
