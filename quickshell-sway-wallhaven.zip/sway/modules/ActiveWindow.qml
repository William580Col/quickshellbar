import QtQuick
import Quickshell
import Quickshell.Io
import "../config"

/*
  Ventana activa para Sway. Lee `swaymsg -t get_tree` y busca el nodo
  enfocado. Se refresca por timer (más simple y robusto que suscribirse
  al event stream de sway, a costa de una latencia mínima).
*/
Row {
    id: root
    spacing: 8

    property string title: ""
    visible: title.length > 0

    function refresh() { proc.running = true }

    Timer { interval: 800; running: true; repeat: true; onTriggered: root.refresh() }
    Component.onCompleted: root.refresh()

    function findFocused(node) {
        if (!node) return null
        if (node.focused && node.name && (node.type === "con" || node.type === "floating_con")) return node
        var kids = (node.nodes || []).concat(node.floating_nodes || [])
        for (var i = 0; i < kids.length; i++) {
            var r = findFocused(kids[i])
            if (r) return r
        }
        return null
    }

    Process {
        id: proc
        command: ["swaymsg", "-t", "get_tree"]
        property string buf: ""
        stdout: SplitParser { onRead: line => proc.buf += line }
        onExited: {
            try {
                var tree = JSON.parse(proc.buf)
                var found = root.findFocused(tree)
                root.title = found ? (found.name || "") : ""
            } catch (e) {
                console.warn("[ActiveWindow/Sway] Error parseando JSON:", e)
            }
            proc.buf = ""
        }
    }

    Text {
        anchors.verticalCenter: parent.verticalCenter
        text: root.title
        color: Theme.text
        font.pixelSize: 13
        elide: Text.ElideRight
        maximumLineCount: 1
        width: Math.min(implicitWidth, 380)
    }
}
