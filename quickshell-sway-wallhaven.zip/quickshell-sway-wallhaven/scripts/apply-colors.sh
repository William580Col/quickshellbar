#!/bin/sh
# Genera la paleta de color a partir de una imagen (matugen) y la aplica:
#   - al acento del shell (accent-color.txt -> Theme.accent)
#   - a fuzzel: persistente (colors.ini, se ve la próxima vez que lo abras)
#
# Esta variante no incluye theming de bordes de ventana (eso es específico
# de Hyprland en este proyecto). Si tu compositor soporta colores de borde
# configurables en caliente, puedes agregar aquí una llamada equivalente.
#
# Uso: apply-colors.sh /ruta/al/wallpaper.png [dark|light]

IMG="$1"
MODE="${2:-dark}"

[ -f "$IMG" ] || { echo "ERROR: no existe la imagen: $IMG" >&2; exit 1; }

if ! command -v matugen >/dev/null 2>&1; then
    echo "ERROR: 'matugen' no está instalado (cargo install matugen)" >&2
    exit 1
fi

# Genera una miniatura para acelerar matugen (decodificar imágenes grandes es lento).
THUMB="$(mktemp --suffix=.png "${TMPDIR:-/tmp}/matugen-thumb.XXXXXX")" || THUMB=""
[ -n "$THUMB" ] && trap 'rm -f "$THUMB"' EXIT INT TERM
MATUGEN_IMG="$IMG"
if [ -n "$THUMB" ]; then
    if command -v magick >/dev/null 2>&1; then
        magick "$IMG" -auto-orient -filter point -resize '256x256>' "$THUMB" 2>/dev/null && MATUGEN_IMG="$THUMB"
    elif command -v convert >/dev/null 2>&1; then
        convert "$IMG" -auto-orient -filter point -resize '256x256>' "$THUMB" 2>/dev/null && MATUGEN_IMG="$THUMB"
    fi
fi

matugen image "$MATUGEN_IMG" -m "$MODE" || { echo "ERROR: matugen falló" >&2; exit 1; }

# Asegura el CSS de usuario GTK4 (import de colors.css).
sh "$HOME/.config/matugen/scripts/ensure-gtk4-css.sh" 2>/dev/null || true

# Rota la variante de iconos Tela según el acento recién generado.
sh "$HOME/.config/matugen/scripts/set-tela-variant.sh" "$MODE" || true

echo "OK"
