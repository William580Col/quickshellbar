pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Servicio Bluetooth envolviendo bluetoothctl (BlueZ). Provee el estado del
  adaptador (encendido/apagado), la lista de dispositivos conocidos
  (emparejados y cercanos descubiertos) y las operaciones habituales:
  escanear, conectar, desconectar, emparejar, confiar y olvidar.

  Usa scripts/bluetooth-state.sh para sondear el estado; las operaciones
  disparan procesos de bluetoothctl y refrescan el estado al terminar.
*/
Singleton {
    id: bt

    property string stateScript: Quickshell.env("HOME") + "/.config/quickshell/sway/scripts/bluetooth-state.sh"

    property bool powered: false
    property bool discovering: false
    property bool refreshing: false
    property string busy: ""    // dirección del dispositivo con una operación en curso
    property string busyOp: ""  // connect | disconnect | pair | remove | trust
    property string lastError: ""
    property var devices: []    // { address, name, paired, trusted, connected, battery }

    property bool anyConnected: arrayAny(bt.devices, "connected")

    property var _buf: []
    property string _out: ""

    function refresh() {
        bt.refreshing = true
        stateProc.running = true
    }

    function toggleAdapter() {
        bt.runOp("toggle", "timeout 8 bluetoothctl power " + (bt.powered ? "off" : "on"))
    }

    function startScan() {
        bt.discovering = true
        scanProc.running = true
    }

    function stopScan() {
        stopScanProc.running = true
    }

    function toggleScan() {
        if (bt.discovering) bt.stopScan()
        else bt.startScan()
    }

    function connectDevice(addr) { bt.runOp("connect", "timeout 25 bluetoothctl connect '" + addr + "'") }
    function disconnectDevice(addr) { bt.runOp("disconnect", "timeout 25 bluetoothctl disconnect '" + addr + "'") }
    function removeDevice(addr) { bt.runOp("remove", "timeout 20 bluetoothctl remove '" + addr + "'") }
    function trustDevice(addr, trust) { bt.runOp("trust", "timeout 15 bluetoothctl trust '" + addr + "' " + (trust ? "on" : "off")) }

    function pairDevice(addr) {
        bt.busy = addr
        bt.busyOp = "pair"
        bt.lastError = ""
        bt._out = ""
        pairProc.command = ["sh", "-c",
            "( timeout 45 bluetoothctl pair '" + addr + "' && timeout 10 bluetoothctl trust '" + addr +
            "' on && timeout 20 bluetoothctl connect '" + addr + "' ) 2>&1"]
        pairProc.running = true
    }

    function runOp(op, cmd) {
        bt.busy = op === "toggle" ? "_adapter" : bt.busy
        bt.busyOp = op
        bt.lastError = ""
        bt._out = ""
        actProc.command = ["sh", "-c", cmd + " 2>&1"]
        actProc.running = true
    }

    function arrayAny(arr, key) {
        for (var i = 0; i < arr.length; i++) if (arr[i][key]) return true
        return false
    }

    function finishOp() {
        var out = bt._out
        bt._out = ""
        bt.busy = ""
        bt.busyOp = ""
        if (out.indexOf("Failed") !== -1 || out.indexOf("failed") !== -1) {
            var lines = out.trim().split(/[\r\n]+/)
            bt.lastError = lines[lines.length - 1] || "Operación fallida"
        } else {
            bt.lastError = ""
        }
        bt.refresh()
    }

    // Sonda periódica de estado
    Timer {
        interval: 6000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: bt.refresh()
    }

    Process {
        id: stateProc
        command: ["sh", bt.stateScript]
        stdout: SplitParser {
            onRead: line => {
                if (line.indexOf("ADAPTER|") === 0) {
                    var a = line.split("|")
                    bt.powered = a[2] === "yes"
                    bt.discovering = a[3] === "yes"
                } else if (line.indexOf("DEVICE|") === 0) {
                    var d = line.split("|")
                    if (!bt._buf.find(x => x.address === d[1])) {
                        bt._buf.push({ address: d[1], name: d[2], paired: false, trusted: false, connected: false, battery: -1 })
                    }
                } else if (line.indexOf("FACT|") === 0) {
                    var f = line.split("|")
                    var dev = bt._buf.find(x => x.address === f[1])
                    if (dev) {
                        if (f[2] === "Paired") dev.paired = f[3] === "yes"
                        else if (f[2] === "Trusted") dev.trusted = f[3] === "yes"
                        else if (f[2] === "Connected") dev.connected = f[3] === "yes"
                        else if (f[2] === "Battery") dev.battery = parseInt(f[3])
                    }
                }
            }
        }
        onExited: {
            bt.devices = bt._buf
            bt._buf = []
            bt.refreshing = false
        }
    }

    Process {
        id: scanProc
        command: ["sh", "-c", "timeout 20 bluetoothctl --timeout 15 scan on 2>&1"]
        stdout: SplitParser { onRead: line => {} }
        onExited: {
            bt.discovering = false
            bt.refresh()
        }
    }

    Process {
        id: stopScanProc
        command: ["bluetoothctl", "scan", "off"]
        onExited: {
            bt.discovering = false
            bt.refresh()
        }
    }

    Process {
        id: pairProc
        stdout: SplitParser { onRead: line => bt._out += line + "\n" }
        stderr: SplitParser { onRead: line => bt._out += line + "\n" }
        onExited: bt.finishOp()
    }

    Process {
        id: actProc
        stdout: SplitParser { onRead: line => bt._out += line + "\n" }
        stderr: SplitParser { onRead: line => bt._out += line + "\n" }
        onExited: bt.finishOp()
    }
}