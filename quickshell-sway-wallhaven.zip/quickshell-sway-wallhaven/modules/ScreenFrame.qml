import QtQuick
import QtQuick.Shapes
import Quickshell
import Quickshell.Wayland
import "../config"

/*
  Marco de pantalla estilo Caelestia: banda rellena de ~6px que abraza todo
  el borde de la pantalla. Exterior A ESCUADRA (la banda ocupa todo el borde
  sin huecos en las esquinas); hueco interior con esquinas redondeadas (el
  fondo de escritorio queda "enmarcado"). Las DOS esquinas del hueco donde
  el filete se encuentra con la barra (arriba si la barra está arriba, abajo
  si está abajo) se redondean con el radio del hueco: el hueco arranca/termina
  en el borde de la barra (barSurfaceEdge) y esos arcos SON el fillet, de modo
  que la banda opaca de la barra, el fillet y el filete quedan rellenos en un
  ÚNICO Shape (un solo resolve MSAA) y la unión barra-marco-filete es suave
  (tangente al filete vertical en edge+holeR y al borde de la barra en
  m+holeR).

  Es solo estética: la ventana no captura clics (mask vacío) ni desplaza a
  nadie (exclusiveZone -1: ignora zonas ajenas y cubre toda la pantalla).
  Se instancia una por pantalla desde shell.qml y vive en la capa Top:
  por encima de las ventanas normales (el marco se dibuja sobre ellas),
  pero DEBAJO de la barra, que se sube a Overlay (ver Bar.qml). Overlay >
  Top está garantizado por el protocolo, así que la banda opaca que se
  pinta aquí nunca puede tapar los iconos de la barra (el orden de
  creación de superficies no sirve: quickshell reutiliza ventanas al
  recargar config y las recrea al ocultarlas, con lo que el apilado
  dentro de una misma capa cambia sin aviso). La ventana de la barra
  queda transparente en la zona de la banda y sus iconos se dibujan por
  encima, en su propia ventana.
*/
PanelWindow {
    id: root

    required property var modelData // pantalla (screen) inyectada por Variants

    screen: modelData
    WlrLayershell.namespace: "quickshell"

    WlrLayershell.layer: WlrLayer.Top
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

    anchors {
        top: true
        bottom: true
        left: true
        right: true
    }
    // -1 = no respetar zonas exclusivas de otras capas: el marco debe
    // cubrir TODA la pantalla. Con0, Sway lo desplazaba hacia abajo la
    // zona exclusiva de la barra (52px) y la banda superior del marco
    // aparecía como una línea suelta debajo de la barra.
    exclusiveZone: -1

    color: "transparent"

    // La ventana se crea SIEMPRE (visible por defecto) y nunca se
    // destruye al cambiar la config: así su superficie existe desde el
    // arrancar y su posición en la capa Top es estable. Que la banda no
    // tape los iconos no depende del orden de creación (eso fallaba):
    // lo garantiza la capa Overlay de la barra (ver Bar.qml).
    // Lo que sí se apaga con la config es el Shape de abajo.

    // Sin interacción: solo dibuja el marco
    mask: Region {}

    // Geometría: el margen debe coincidir con el margen de la barra (6) y el
    // radio del hueco con el radio de la barra menos ese margen, para que la
    // unión barra-marco sea invisible.
    readonly property real m: 6
    readonly property real holeR: Math.max(4, Theme.radiusLarge - m)
    readonly property real frameR: Theme.radiusLarge
    // Filete interior: +0.5 hacia dentro del hueco para que caiga en una
    // sola columna/fila de píxel (centrado en un entero se partía en dos
    // columnas al50% = línea borrosa "pixelada").
    readonly property real sm: m + 0.5
    readonly property real shr: holeR - 0.5

    Shape {
        anchors.fill: parent
        antialiasing: true
        layer.enabled: true
        layer.samples: 4
        // Mismo antialiasing (MSAA 4x) que el Shape de la barra: al unir
        // la banda de la barra y el fillet en ESTE buffer, la calidad de
        // borde no puede ser peor que la que tenía la banda por sí sola.
        // Este es el único pintor de la unión barra↔marco (la barra apaga
        // su banda cuando el marco está activo, ver Bar.qml).
        visible: BarConfig.screenBorder && BarConfig.caelestia

        // Banda rellena: rectángulo exterior a ESCUADRA menos hueco interior
        // con las esquinas de unión a la barra redondeadas (OddEvenFill).
        // Relleno OPAQUE (sin "efecto cristal"): el marco es el chasis del
        // escritorio y la barra se funde con él; si fuera translúcido se
        // verían los filetes por debajo y el borde quedaría "separado".
        // El hueco arranca ya en barSurfaceEdge (no en m): la banda opaca
        // de la barra (x0..ancho, y0..barSurfaceEdge) queda DENTRO del
        // relleno, así que barra, fillet y filete se resuelven en el mismo
        // buffer con el mismo MSAA (antes la banda era otra ventana y la
        // esquina superior quedaba pixelada en la costura y=barSurfaceEdge).

        // --- Variante barra ARRIBA: el hueco interior arranca en
        // barSurfaceEdge y sus dos esquinas superiores (arco de radio
        // holeR tangente al borde de la barra) son el fillet de unión;
        // lo que queda por encima (banda opaca a todo el ancho) va
        // relleno en ESTE mismo Shape, con el mismo MSAA. (Solo una de
        // las dos variantes se pinta: ShapePath no tiene `visible`, se
        // apaga con fillColor transparent.)
        ShapePath {
            fillRule: ShapePath.OddEvenFill
            fillColor: BarConfig.position !== "bottom" ? Theme.bg : "transparent"
            strokeColor: "transparent"

            // --- Contorno exterior: A ESCUADRA, a sangre en el borde de
            // ventana. La banda debe ocupar TODO el borde de la pantalla
            // (sin "muescas" oscuras en las esquinas); el redondeo vive
            // solo en el hueco interior, que es lo que enmarca el fondo.
            PathMove { x: 0; y: 0 }
            PathLine { x: root.width; y: 0 }
            PathLine { x: root.width; y: root.height }
            PathLine { x: 0; y: root.height }

            // --- Hueco interior (dirección contraria; con OddEven no importa) ---
            // Borde superior del hueco en barSurfaceEdge: la banda opaca
            // de la barra queda rellena arriba y los arcos de esquina
            // (mismos PathQuad y controles de antes) hacen de fillet.
            PathMove { x: root.m + root.holeR; y: BarConfig.barSurfaceEdge }
            PathLine { x: root.width - root.m - root.holeR; y: BarConfig.barSurfaceEdge }
            PathQuad { x: root.width - root.m; y: BarConfig.barSurfaceEdge + root.holeR; controlX: root.width - root.m; controlY: BarConfig.barSurfaceEdge }
            PathLine { x: root.width - root.m; y: root.height - root.m - root.holeR }
            PathQuad { x: root.width - root.m - root.holeR; y: root.height - root.m; controlX: root.width - root.m; controlY: root.height - root.m }
            PathLine { x: root.m + root.holeR; y: root.height - root.m }
            PathQuad { x: root.m; y: root.height - root.m - root.holeR; controlX: root.m; controlY: root.height - root.m }
            PathLine { x: root.m; y: BarConfig.barSurfaceEdge + root.holeR }
            PathQuad { x: root.m + root.holeR; y: BarConfig.barSurfaceEdge; controlX: root.m; controlY: BarConfig.barSurfaceEdge }
        }

        // --- Variante barra ABAJO: mismo espejo — el hueco termina en
        // height - barSurfaceEdge y sus esquinas inferiores (arco de
        // radio holeR tangente al borde de la barra) son el fillet; la
        // banda opaca de la barra queda rellena en este mismo Shape.
        ShapePath {
            fillRule: ShapePath.OddEvenFill
            fillColor: BarConfig.position === "bottom" ? Theme.bg : "transparent"
            strokeColor: "transparent"

            PathMove { x: 0; y: 0 }
            PathLine { x: root.width; y: 0 }
            PathLine { x: root.width; y: root.height }
            PathLine { x: 0; y: root.height }

            PathMove { x: root.m + root.holeR; y: root.m }
            PathLine { x: root.width - root.m - root.holeR; y: root.m }
            PathQuad { x: root.width - root.m; y: root.m + root.holeR; controlX: root.width - root.m; controlY: root.m }
            PathLine { x: root.width - root.m; y: root.height - BarConfig.barSurfaceEdge - root.holeR }
            PathQuad { x: root.width - root.m - root.holeR; y: root.height - BarConfig.barSurfaceEdge; controlX: root.width - root.m; controlY: root.height - BarConfig.barSurfaceEdge }
            PathLine { x: root.m + root.holeR; y: root.height - BarConfig.barSurfaceEdge }
            PathQuad { x: root.m; y: root.height - BarConfig.barSurfaceEdge - root.holeR; controlX: root.m; controlY: root.height - BarConfig.barSurfaceEdge }
            PathLine { x: root.m; y: root.m + root.holeR }
            PathQuad { x: root.m + root.holeR; y: root.m; controlX: root.m; controlY: root.m }
        }

        // Filete interior de1px: sigue el contorno visible del hueco y
        // TERMINA en tangencia con el borde de la barra mediante un arco
        // redondeando la esquina de unión (se mantiene la geometría de
        // siempre: no cruza hacia la banda, cuyo relleno opaco ya vive en
        // el mismo Shape/buffer). Con la barra arriba empieza en el borde
        // inferior de la barra y con la barra abajo termina en su borde
        // superior.
        ShapePath {
            strokeWidth: 0
            fillColor: "transparent"
            strokeColor: Theme.border

            // Arco superior izquierdo (tangente al filete vertical en
            // sm, edge+holeR y al borde de la barra en m+holeR, edge+0.5):
            PathMove { x: root.m + root.holeR; y: BarConfig.barSurfaceEdge + 0.5 }
            PathQuad { x: root.sm; y: BarConfig.barSurfaceEdge + root.holeR; controlX: root.sm; controlY: BarConfig.barSurfaceEdge + 0.5 }
            PathLine { x: root.sm; y: root.height - root.sm - root.shr }
            PathQuad { x: root.sm + root.shr; y: root.height - root.sm; controlX: root.sm; controlY: root.height - root.sm }
            PathLine { x: root.width - root.sm - root.shr; y: root.height - root.sm }
            PathQuad { x: root.width - root.sm; y: root.height - root.sm - root.shr; controlX: root.width - root.sm; controlY: root.height - root.sm }
            PathLine { x: root.width - root.sm; y: BarConfig.barSurfaceEdge + root.holeR }
            PathQuad { x: root.width - root.m - root.holeR; y: BarConfig.barSurfaceEdge + 0.5; controlX: root.width - root.sm; controlY: BarConfig.barSurfaceEdge + 0.5 }
        }

        ShapePath {
            strokeWidth: BarConfig.position === "bottom" ? 1 : 0
            fillColor: "transparent"
            strokeColor: Theme.border

            // Arco superior izquierdo (variante barra abajo: esquina
            // inferior izquierda del hueco):
            PathMove { x: root.m + root.holeR; y: root.height - BarConfig.barSurfaceEdge - 0.5 }
            PathQuad { x: root.sm; y: root.height - BarConfig.barSurfaceEdge - root.holeR; controlX: root.sm; controlY: root.height - BarConfig.barSurfaceEdge - 0.5 }
            PathLine { x: root.sm; y: root.sm + root.shr }
            PathQuad { x: root.sm + root.shr; y: root.sm; controlX: root.sm; controlY: root.sm }
            PathLine { x: root.width - root.sm - root.shr; y: root.sm }
            PathQuad { x: root.width - root.sm; y: root.sm + root.shr; controlX: root.width - root.sm; controlY: root.sm }
            PathLine { x: root.width - root.sm; y: root.height - BarConfig.barSurfaceEdge - root.holeR }
            PathQuad { x: root.width - root.m - root.holeR; y: root.height - BarConfig.barSurfaceEdge - 0.5; controlX: root.width - root.sm; controlY: root.height - BarConfig.barSurfaceEdge - 0.5 }
        }
    }
}
