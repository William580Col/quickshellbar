import QtQuick
import QtQuick.Shapes
import "../config"

/*
  Superficie de panel estilo Caelestia: tarjeta con las esquinas "libres"
  redondeadas y "fillets" cóncavos en las esquinas de unión con la barra,
  de modo que el contorno de1px recorre toda la silueta (barra + panel)
  sin cortes rectos ni líneas horizontales en la unión.

  Uso: los paneles dejan su Rectangle raíz transparente (sin borde) y
  añaden PanelSurface como PRIMER hijo (queda detrás del contenido).
  attachedBottom = falso cuando la barra está arriba (fillets arriba);
  true cuando la barra está abajo (fillets abajo).

  Nota: el dibujo sobresale fillet px a cada lado de la tarjeta; los padres
  no recortan (clip:false), así que se pinta completo.
*/
Item {
    id: root

    property bool attachedBottom: false   // true: fillets en la esquina inferior
    property real radius: Theme.radiusLarge
    property real fillet: 16              // radio del cóncavo de unión
    property color fillColor: BarConfig.surfaceColor(Theme.surface)
    property color lineColor: Theme.border

    // Los fillets se pintan fuera de los límites de la tarjeta
    clip: false

    // ---------- Unión arriba (barra sobre el panel) ----------
    Shape {
        anchors.fill: parent
        visible: !root.attachedBottom
        antialiasing: true
        layer.enabled: true
        layer.samples: 4

        // Relleno: silueta completa (un solo pintado => alfa translúcida x1)
        ShapePath {
            fillColor: root.fillColor
            strokeColor: "transparent"

            PathMove { x: -root.fillet; y: 0 }
            PathQuad { x: 0; y: root.fillet; controlX: 0; controlY: 0 }
            PathLine { x: 0; y: root.height - root.radius }
            PathQuad { x: root.radius; y: root.height; controlX: 0; controlY: root.height }
            PathLine { x: root.width - root.radius; y: root.height }
            PathQuad { x: root.width; y: root.height - root.radius; controlX: root.width; controlY: root.height }
            PathLine { x: root.width; y: root.fillet }
            PathQuad { x: root.width + root.fillet; y: 0; controlX: root.width; controlY: 0 }
            PathLine { x: -root.fillet; y: 0 }
        }

        // Contorno: la MISMA silueta abierta (sin el tramo superior, que es
        // la unión con la barra)
        ShapePath {
            fillColor: "transparent"
            strokeColor: root.lineColor
            strokeWidth: 1

            PathMove { x: -root.fillet; y: 0 }
            PathQuad { x: 0; y: root.fillet; controlX: 0; controlY: 0 }
            PathLine { x: 0; y: root.height - root.radius }
            PathQuad { x: root.radius; y: root.height; controlX: 0; controlY: root.height }
            PathLine { x: root.width - root.radius; y: root.height }
            PathQuad { x: root.width; y: root.height - root.radius; controlX: root.width; controlY: root.height }
            PathLine { x: root.width; y: root.fillet }
            PathQuad { x: root.width + root.fillet; y: 0; controlX: root.width; controlY: 0 }
        }
    }

    // ---------- Unión abajo (barra bajo el panel; espejo en Y) ----------
    Shape {
        anchors.fill: parent
        visible: root.attachedBottom
        antialiasing: true
        layer.enabled: true
        layer.samples: 4

        ShapePath {
            fillColor: root.fillColor
            strokeColor: "transparent"

            PathMove { x: -root.fillet; y: root.height }
            PathQuad { x: 0; y: root.height - root.fillet; controlX: 0; controlY: root.height }
            PathLine { x: 0; y: root.radius }
            PathQuad { x: root.radius; y: 0; controlX: 0; controlY: 0 }
            PathLine { x: root.width - root.radius; y: 0 }
            PathQuad { x: root.width; y: root.radius; controlX: root.width; controlY: 0 }
            PathLine { x: root.width; y: root.height - root.fillet }
            PathQuad { x: root.width + root.fillet; y: root.height; controlX: root.width; controlY: root.height }
            PathLine { x: -root.fillet; y: root.height }
        }

        ShapePath {
            fillColor: "transparent"
            strokeColor: root.lineColor
            strokeWidth: 1

            PathMove { x: -root.fillet; y: root.height }
            PathQuad { x: 0; y: root.height - root.fillet; controlX: 0; controlY: root.height }
            PathLine { x: 0; y: root.radius }
            PathQuad { x: root.radius; y: 0; controlX: 0; controlY: 0 }
            PathLine { x: root.width - root.radius; y: 0 }
            PathQuad { x: root.width; y: root.radius; controlX: root.width; controlY: 0 }
            PathLine { x: root.width; y: root.height - root.fillet }
            PathQuad { x: root.width + root.fillet; y: root.height; controlX: root.width; controlY: root.height }
        }
    }
}
