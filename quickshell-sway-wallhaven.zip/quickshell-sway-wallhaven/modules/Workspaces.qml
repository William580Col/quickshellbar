import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import "../config"

/*
  Indicador de workspaces con números para Sway.

  Muestra SIEMPRE los workspaces 1..count (por defecto 5), estén creados o
  no: los no creados se pintan atenuados y al hacer clic se crean y se salta
  a ellos. Usa `swaymsg -t get_workspaces` (JSON) por proceso, refrescado
  por timer, y cambia de workspace con `swaymsg workspace number <n>`.

  Para volver al comportamiento dinámico (solo los workspaces que existan),
  pon count: 0.
*/
Row {
    id: root
    spacing: 6
    height: 26

    // Cuántos workspaces fijos mostrar (1..count). 0 = dinámico (todos los
    // que existan, como el comportamiento original de Sway).
    property int count: 5

    property var workspaces: []

    function refresh() { listProc.running = true }

    Timer { interval: 1000; running: true; repeat: true; onTriggered: root.refresh() }
    Component.onCompleted: root.refresh()

    Process {
        id: listProc
        command: ["swaymsg", "-t", "get_workspaces"]
        property string buf: ""
        stdout: SplitParser { onRead: line => listProc.buf += line }
        onExited: {
            try {
                root.workspaces = JSON.parse(listProc.buf)
            } catch (e) {
                console.warn("[Workspaces/Sway] Error parseando JSON:", e)
            }
            listProc.buf = ""
        }
    }

    // Lista fija 1..count con el estado leído de Sway. Se reevalúa sola
    // cuando cambia root.workspaces (la actualiza el timer).
    readonly property var fixedWorkspaces: {
        var out = []
        for (var i = 1; i <= root.count; i++) {
            var found = null
            for (var j = 0; j < root.workspaces.length; j++) {
                if (root.workspaces[j].num === i) { found = root.workspaces[j]; break }
            }
            out.push({
                id: i,
                active: found ? found.focused : false,
                hasWindows: found
                    ? (found.representation || found.visible || found.focused)
                    : false
            })
        }
        return out
    }

    // Modelo elegido: fijo (count > 0) o dinámico (count == 0).
    readonly property var workspaceModel: root.count > 0 ? root.fixedWorkspaces : root.workspaces

    Repeater {
        model: root.workspaceModel

        delegate: Item {
            id: cell
            required property var modelData
            property bool active: cell.modelData.active
            property bool hasWindows: cell.modelData.hasWindows !== undefined
                ? cell.modelData.hasWindows
                : (cell.modelData.visible || cell.modelData.focused)

            width: pill.width
            height: 26

            Rectangle {
                id: pill
                anchors.centerIn: parent
                width: Math.max(26, label.implicitWidth + 16)
                height: 22
                radius: 11
                color: cell.active ? Theme.accent
                       : (cell.hasWindows ? Theme.bgAlt : "transparent")
                border.width: cell.active ? 0 : 1
                border.color: cell.hasWindows ? Theme.border : Qt.rgba(Theme.border.r, Theme.border.g, Theme.border.b, 0.5)

                Behavior on width { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                Behavior on color { ColorAnimation { duration: 160 } }

                Text {
                    id: label
                    anchors.centerIn: parent
                    text: cell.modelData.id !== undefined ? cell.modelData.id : cell.modelData.num
                    font.pixelSize: 11
                    font.bold: cell.active
                    color: cell.active ? Theme.bg : (cell.hasWindows ? Theme.text : Theme.subtext)
                }
            }

            MouseArea {
                anchors.fill: parent
                anchors.margins: -4
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    var n = cell.modelData.id !== undefined ? cell.modelData.id : cell.modelData.num
                    switchProc.command = ["swaymsg", "workspace", "number", String(n)]
                    switchProc.running = true
                }
            }
        }
    }

    Process { id: switchProc }
}
