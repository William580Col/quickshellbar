# Quickshell — Entorno de escritorio Wayland (variante Sway)

Barra de tareas + lanzador + workspaces + calendario + wallpapers + idle
inhibitor + luz nocturna + audio + red (con selección de Wi-Fi y
contraseña) + portapapeles + tray + power menu + notificaciones + tema
claro/oscuro + brillo + ventana activa + captura de pantalla (completa y
de área) + panel de configuración de la barra + efecto cristal.

Esta es la variante para **Sway**. `modules/Workspaces.qml` y
`modules/ActiveWindow.qml` hablan con Sway vía `swaymsg` (protocolo
i3-ipc), `modules/Screenshot.qml` usa `grim`+`slurp` directo, y el botón
"Salir" del `PowerMenu` usa `swaymsg exit`.

> ⚠️ Esto se construyó y probó principalmente sobre la variante Hyprland de
> este mismo proyecto; la adaptación a Sway reutiliza la misma base de
> código pero no se pudo probar en vivo sobre Sway. Instálala, pruébala, y
> si algo falla, el patrón de diagnóstico que sirvió en Hyprland (revisar
> la terminal donde corres `quickshell -c ~/.config/quickshell`, buscar
> líneas `[NombreDelModulo] ...`) aplica igual aquí.

## 1. Instalar dependencias

```bash
sudo apt install brightnessctl wl-clipboard network-manager wlsunset \
    swaybg grim slurp libnotify-bin imagemagick
# cliphist (portapapeles) - no está en apt, instala el binario:
#   https://github.com/sentriz/cliphist/releases
# swww (wallpapers con transición, opcional):
#   https://github.com/LGFae/swww/releases
# Sway ya trae 'swaymsg' incluido.
```

Necesitas una **Nerd Font** instalada (los iconos de la barra son glifos
Nerd Font, ej. `JetBrainsMono Nerd Font`).

```bash
sudo apt install fonts-jetbrains-mono
```

## 2. Copiar los archivos

```bash
mkdir -p ~/.config/quickshell
cp -r shell.qml modules config services scripts matugen-templates ~/.config/quickshell/
chmod +x ~/.config/quickshell/scripts/*.sh
```

## 3. Ajustar

- `services/Wallpaper.qml` → cambia `directory` si tus wallpapers no están
  en `~/Pictures/Wallpapers`.
- `services/NightLight.qml` → pon tu latitud/longitud reales.
- `config/Theme.qml` → colores base y acento (el acento también se puede
  generar automáticamente desde el wallpaper, ver sección 8).

## 4. Ejecutar

```bash
quickshell -c ~/.config/quickshell
```

Autostart en Sway (`~/.config/sway/config`):

```
exec quickshell
```

## 5. Atajos de teclado recomendados (Sway)

En `~/.config/sway/config`:

```
bindsym $mod+d exec qs ipc call launcher toggle
bindsym $mod+Escape exec qs ipc call powermenu toggle
bindsym $mod+v exec qs ipc call clip toggle
bindsym $mod+t exec qs ipc call theme toggle
bindsym $mod+w exec qs ipc call wallpaper toggle
bindsym $mod+shift+w exec qs ipc call wifi toggle
bindsym $mod+comma exec qs ipc call barsettings toggle
```

## 6. Panel de configuración de la barra

Icono 󰢻 en la barra (o `qs ipc call barsettings toggle`). Permite:

- Posición: Arriba / Abajo
- Auto-ocultar (se reduce a una franja de 6px sin uso, reaparece al
  acercar el mouse al borde)
- Escala (80%–130%, afecta el grosor de la barra)
- Activar/desactivar módulos, reordenarlos con ←/→, y asignarles zona
  (Izquierda/Centro/Derecha) con un botón que rota entre las tres
- Efecto cristal (transparencia en la barra y todos los menús — ver
  sección 7 para blur real, específico de Hyprland, no aplicable en Sway)
- Restaurar valores por defecto

Todo se guarda en `~/.local/state/quickshell-bar-config.json`.

## 7. Efecto cristal

La opción "Efecto cristal" del panel de configuración aplica transparencia
real (no solo visual) a la barra y a todos los menús/paneles. El **blur**
detrás de las ventanas (difuminar lo que se ve a través del cristal) es una
característica de compositor: en Hyprland existe una regla de capa
(`layer_rule`) para esto, pero **Sway no tiene un mecanismo equivalente
documentado de blur configurable por regla de capa** al momento de escribir
esto. Con Sway solo obtendrás el efecto de transparencia, no blur real.

## 8. Wi-Fi, volumen y wallpapers

- **Wi-Fi**: clic en el icono de red de la barra abre un panel con lista de
  redes, candado si están protegidas, campo de contraseña inline al
  seleccionar una protegida, y desconectar con clic en la red actual.
- **Volumen**: pasa el mouse sobre el icono de volumen y usa la rueda para
  subir/bajar; aparece un OSD (indicador flotante) con una barra de
  progreso, igual que en cualquier sistema de escritorio.
- **Wallpapers**: el panel genera miniaturas cacheadas con ImageMagick
  (`convert`) la primera vez, para que abrir el selector sea rápido incluso
  con muchas imágenes.

## 9. Theming automático desde el wallpaper (matugen)

Cada vez que eliges un wallpaper, si tienes **matugen** instalado
(`cargo install matugen`, no está en los repos de Debian), se genera y
aplica automáticamente:

- El **acento** del propio shell (`Theme.accent`), usado en píldoras de
  workspace activo, toggles del panel de ajustes, barra del OSD de
  volumen, etc.
- Los **colores de fuzzel** (fondo, selección, borde, texto).

A diferencia de la variante Hyprland, **no incluye theming de bordes de
ventana** (eso depende de mecanismos específicos de cada compositor; Sway
no tiene un equivalente directo tan simple como `hyprctl` para esto).

Pasos:

```bash
sudo apt install cargo
cargo install matugen
mkdir -p ~/.config/matugen
cp matugen-config.toml ~/.config/matugen/config.toml
cp -r matugen-templates ~/.config/quickshell/   # ya se copia en el paso 2 si seguiste el orden
```

En `~/.config/fuzzel/fuzzel.ini`, agrega en la sección principal:

```ini
include=~/.config/fuzzel/colors.ini
```

Probar manualmente:

```bash
~/.config/quickshell/scripts/apply-colors.sh ~/Pictures/Wallpapers/tu-imagen.png dark
```

## 10. Captura de pantalla

Dos iconos en la barra: captura completa y captura de área (selección con
`slurp`). Usa `grim`+`slurp` directamente (no `grimshot`, que depende de
`swaymsg` — aquí no hay problema en usarlo directo porque estamos en Sway,
a diferencia de la variante Hyprland donde eso causaba un bloqueo).
Guarda en `~/Pictures/Screenshots/` y copia al portapapeles con `wl-copy`.

## 11. Estructura del proyecto

```
shell.qml                      punto de entrada
config/
  Theme.qml / BarConfig.qml / qmldir    colores, acento, config de la barra
services/
  Audio.qml, Network.qml, Brightness.qml, NightLight.qml,
  IdleInhibitor.qml, Wallpaper.qml, Notifs.qml, Apps.qml, ClipHistory.qml
modules/
  Bar.qml                        barra (data-driven según BarConfig)
  BarSettingsPanel.qml            panel de configuración de la barra
  Workspaces.qml / ActiveWindow.qml   específicos de Sway (swaymsg)
  Clock.qml / Calendar.qml / Tray.qml / QuickSettings.qml
  Launcher.qml / PowerMenu.qml / ClipHistoryPanel.qml / WallpaperPanel.qml
  WiFiPanel.qml / VolumeOSD.qml / NotificationPopups.qml
  Screenshot.qml                  específico de Sway (grim+slurp directo)
scripts/
  apply-colors.sh                  matugen -> acento + fuzzel
matugen-templates/
  fuzzel-colors.ini.template
  accent-color.txt.template
matugen-config.toml                copiar a ~/.config/matugen/config.toml
```

## 12. Depuración

```bash
quickshell -c ~/.config/quickshell 2>&1 | tee /tmp/quickshell.log
```

Si editas archivos con quickshell corriendo, el hot-reload puede dejar
procesos hijos huérfanos (por ejemplo `slurp` colgado). Mejor reinicia
completo tras cada cambio:

```bash
pkill -x slurp; pkill -x grim
pkill quickshell
quickshell -c ~/.config/quickshell
```
