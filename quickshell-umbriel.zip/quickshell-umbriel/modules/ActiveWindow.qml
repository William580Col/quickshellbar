import QtQuick
import Quickshell
import Quickshell.Io
import "../config"

/*
  Ventana activa para Umbriel. Lee "umbriel windows --json" y filtra la
  que tenga foco.

  NOTA honesta: la documentación de IPC de Umbriel confirma que la
  consulta de ventanas devuelve "ids, app ids, titles, client pids,
  geometry, workspace ids, and scratchpad membership", y confirma que hay
  un flujo de eventos de "focus" — pero no enumeró explícitamente el
  nombre exacto del campo booleano de foco por ventana (sí lo hace para
  workspaces: "focused"). Asumo por consistencia de nomenclatura que se
  llama igual ("focused"). Si no aparece nada aquí, corre
  "umbriel windows --json | jq" a mano para confirmar el nombre real del
  campo y ajústalo abajo.
*/
Row {
    id: root
    spacing: 8

    property string title: ""
    visible: title.length > 0

    function refresh() { proc.running = true }

    Timer { interval: 800; running: true; repeat: true; onTriggered: root.refresh() }
    Component.onCompleted: root.refresh()

    Process {
        id: proc
        command: ["umbriel", "windows", "--json"]
        property string buf: ""
        stdout: SplitParser { onRead: line => proc.buf += line }
        onExited: {
            try {
                var wins = JSON.parse(proc.buf)
                var focused = wins.find(w => w.focused)
                root.title = focused ? (focused.title || focused.app_id || "") : ""
            } catch (e) {
                console.warn("[ActiveWindow/Umbriel] Error parseando JSON:", e)
            }
            proc.buf = ""
        }
    }

    Text {
        anchors.verticalCenter: parent.verticalCenter
        text: root.title
        color: Theme.text
        font.pixelSize: 13
        elide: Text.ElideRight
        maximumLineCount: 1
        width: Math.min(implicitWidth, 380)
    }
}
