pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"
import "../services" as Services

/*
  Dock flotante estilo Mac: pastilla centrada con apps fijadas + abiertas,
  lupa al pasar el mouse, punto de "en ejecución", clic para lanzar/enfocar
  y clic derecho para fijar/soltar. Una instancia por pantalla (shell.qml).

  Ocultación como la barra: al ocultarse queda una franja sensora de 6px;
  pasar el mouse por el borde lo vuelve a mostrar.
*/
PanelWindow { // qmllint disable uncreatable-type
    id: dock

    required property var modelData // pantalla inyectada por Variants
    screen: modelData

    // Mismo namespace que la barra: comparte la regla de blur de Hyprland.
    WlrLayershell.namespace: "quickshell"

    property bool isBottom: DockConfig.position === "bottom"
    property bool isLeft: DockConfig.position === "left"
    property bool isRight: DockConfig.position === "right"
    property bool vertical: !isBottom

    anchors {
        top: !isBottom
        bottom: true
        left: isBottom || isLeft
        right: isBottom || isRight
    }

    visible: DockConfig.enabled

    property real base: DockConfig.iconSize
    property real zoomed: DockConfig.zoomEnabled ? DockConfig.iconSize * DockConfig.zoomScale : DockConfig.iconSize
    property real thickness: zoomed + 22
    property real dockMargin: 8

    property bool autoHidden: true
    property bool hidden: DockConfig.hideMode === "always" ? false
        : DockConfig.hideMode === "auto" ? autoHidden
        : (Services.RunningApps.smartHidden && autoHidden)

    implicitWidth: vertical ? (hidden ? 6 : thickness) : 0
    implicitHeight: !vertical ? (hidden ? 6 : thickness) : 0
    exclusiveZone: 0
    color: "transparent"

    function scheduleHide() {
        if (DockConfig.hideMode === "auto" || DockConfig.hideMode === "smart") hideTimer.restart()
    }

    Connections {
        target: DockConfig
        function onHideModeChanged() {
            if (DockConfig.hideMode !== "auto") {
                hideTimer.stop()
                dock.autoHidden = false
            } else dock.scheduleHide()
        }
        function onEnabledChanged() {
            if (!DockConfig.enabled) { hideTimer.stop(); dock.autoHidden = false }
        }
    }

    Timer {
        id: hideTimer
        interval: 1500
        repeat: false
        onTriggered: dock.autoHidden = true
    }

    Connections {
        target: Services.RunningApps
        function onSmartHiddenChanged() {
            if (Services.RunningApps.smartHidden) dock.autoHidden = true
        }
    }

    // Sensor de borde: revela sin interceptar clics.
    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.NoButton
        onEntered: { hideTimer.stop(); dock.autoHidden = false }
        onExited: dock.scheduleHide()
    }

    // ---- Pastilla flotante ----
    Rectangle {
        id: pill
        visible: !dock.hidden
        // Posición explícita sin anchors condicionales (se atoraban al
        // cambiar de posición en vivo o al cargar el JSON tras crear el dock).
        x: dock.isBottom ? (dock.width - width) / 2 : (dock.isLeft ? dock.dockMargin : dock.width - width - dock.dockMargin)
        y: dock.isBottom ? dock.height - height - dock.dockMargin : (dock.height - height) / 2
        width: dock.isBottom ? rowBox.implicitWidth + 20 : dock.thickness - 8
        height: dock.isBottom ? dock.thickness - 8 : colBox.implicitHeight + 20
        radius: 18
        color: DockConfig.dockSurface(Theme.bg)
        border.color: Theme.border
        border.width: 1

        // Posición del mouse para la lupa (coordenadas de la pastilla).
        property real hoverPos: -1000
        property bool hovering: false

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            acceptedButtons: Qt.NoButton
            onPositionChanged: mouse => {
                pill.hovering = true
                pill.hoverPos = dock.vertical ? mouse.y : mouse.x
            }
            onExited: { pill.hovering = false; pill.hoverPos = -1000 }
        }

        function zoomFor(slotCenter) {
            if (!DockConfig.zoomEnabled || !pill.hovering) return 1.0
            var d = Math.abs(slotCenter - pill.hoverPos)
            var range = dock.base * 2.2
            if (d >= range) return 1.0
            return 1.0 + (DockConfig.zoomScale - 1.0) * (1.0 - d / range)
        }

        // ---- Fila (abajo) ----
        Row {
            id: rowBox
            visible: dock.isBottom
            anchors.centerIn: parent
            spacing: 6

            Repeater {
                model: Services.RunningApps.items
                delegate: Item {
                    id: slotRow
                    required property var modelData
                    required property int index
                    property var e: modelData
                    property int i: index
                    width: inner.width; height: inner.height
                    DockIcon { id: inner; vertical: false; entry: slotRow.e; idx: slotRow.i }
                }
            }
        }

        // ---- Columna (lados) ----
        Column {
            id: colBox
            visible: dock.vertical
            anchors.centerIn: parent
            spacing: 6

            Repeater {
                model: Services.RunningApps.items
                delegate: Item {
                    id: slotCol
                    required property var modelData
                    required property int index
                    property var e: modelData
                    property int i: index
                    width: innerCol.width; height: innerCol.height
                    DockIcon { id: innerCol; vertical: true; entry: slotCol.e; idx: slotCol.i }
                }
            }
        }
    }

    // ================= Icono del dock =================
    component DockIcon: Item {
        id: icon
        required property var entry
        required property int idx
        property bool vertical: false

        property real slot: dock.base + 6
        property real maxSide: dock.base * (DockConfig.zoomEnabled ? DockConfig.zoomScale : 1.0)
        property real center: 10 + icon.idx * (icon.maxSide + 6) + (icon.maxSide + 6) / 2
        property real zf: pill.zoomFor(center)
        property real side: dock.base * zf

        // Separador estilo Mac antes de las abiertas no fijadas.
        property bool sep: icon.entry.sepBefore === true

        width: vertical ? maxSide + 4 : maxSide + (sep ? 11 : 0)
        height: vertical ? maxSide + (sep ? 11 : 0) : maxSide + 10

        Rectangle {
            visible: icon.sep
            color: Theme.border
            width: icon.vertical ? icon.maxSide : 1
            height: icon.vertical ? 1 : icon.maxSide
            x: icon.vertical ? 2 : 0
            y: icon.vertical ? 0 : 0
        }

        Image {
            id: iconImg
            source: icon.entry.icon ? "image://icon/" + icon.entry.icon : ""
            fillMode: Image.PreserveAspectFit
            smooth: true
            width: dock.base
            height: dock.base
            x: icon.vertical ? (dock.isLeft ? 2 : 2 + icon.maxSide - dock.base) : (icon.sep ? 11 : 0) + (icon.maxSide - dock.base) / 2
            y: icon.vertical ? (icon.sep ? 11 : 0) + (icon.maxSide - dock.base) / 2 : icon.maxSide - dock.base
            scale: icon.zf
            transformOrigin: dock.isBottom ? Item.Bottom : (dock.isLeft ? Item.Left : Item.Right)
        }

        // Punto de "en ejecución" (acento si enfocada).
        Rectangle {
            visible: icon.entry.running === true
            width: 4; height: 4; radius: 2
            color: icon.entry.active === true ? Theme.accent : Theme.subtext
            x: icon.vertical ? (dock.isLeft ? icon.maxSide : 0) : (icon.sep ? 11 : 0) + icon.maxSide / 2 - 2
            y: icon.vertical ? (icon.sep ? 11 : 0) + icon.maxSide / 2 - 2 : icon.maxSide + 2
        }

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            acceptedButtons: Qt.LeftButton | Qt.RightButton
            cursorShape: Qt.PointingHandCursor
            onClicked: mouse => {
                if (mouse.button === Qt.RightButton)
                    Services.RunningApps.togglePin(icon.entry.entryId)
                else
                    Services.RunningApps.activateEntry(icon.entry.entryId)
            }
            onPositionChanged: mouse => { var p = icon.mapToItem(pill, mouse.x, mouse.y); pill.hovering = true; pill.hoverPos = dock.vertical ? p.y : p.x }
        }
    }
}
