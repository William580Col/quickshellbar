import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import "../config"

/*
  Indicador de workspaces con números para Umbriel. Usa "umbriel
  workspaces --json" (confirmado en docs.noctalia.dev/umbriel/ipc/) y
  cambia de workspace con "umbriel msg workspace-switch:<index>" (bare
  digits seleccionan posición 1-based, según docs.noctalia.dev/umbriel/actions/).
*/
Row {
    id: root
    spacing: 6
    height: 26

    property var workspaces: []

    function refresh() { listProc.running = true }

    Timer { interval: 1000; running: true; repeat: true; onTriggered: root.refresh() }
    Component.onCompleted: root.refresh()

    Process {
        id: listProc
        command: ["umbriel", "workspaces", "--json"]
        property string buf: ""
        stdout: SplitParser { onRead: line => listProc.buf += line }
        onExited: {
            try {
                var all = JSON.parse(listProc.buf)
                all.sort((a, b) => a.index - b.index)
                root.workspaces = all
            } catch (e) {
                console.warn("[Workspaces/Umbriel] Error parseando JSON:", e)
            }
            listProc.buf = ""
        }
    }

    Repeater {
        model: root.workspaces

        delegate: Item {
            id: cell
            required property var modelData
            property bool active: modelData.focused
            property bool hasWindows: modelData.occupied

            width: pill.width
            height: 26

            Rectangle {
                id: pill
                anchors.centerIn: parent
                width: Math.max(26, label.implicitWidth + 16)
                height: 22
                radius: 11
                color: cell.active ? Theme.accent
                       : (cell.hasWindows ? Theme.bgAlt : "transparent")
                border.width: cell.active ? 0 : 1
                border.color: cell.hasWindows ? Theme.border : Qt.rgba(Theme.border.r, Theme.border.g, Theme.border.b, 0.5)

                Behavior on width { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                Behavior on color { ColorAnimation { duration: 160 } }

                Text {
                    id: label
                    anchors.centerIn: parent
                    text: cell.modelData.index
                    font.pixelSize: 11
                    font.bold: cell.active
                    color: cell.active ? Theme.bg : (cell.hasWindows ? Theme.text : Theme.subtext)
                }
            }

            MouseArea {
                anchors.fill: parent
                anchors.margins: -4
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    switchProc.command = ["umbriel", "msg", "workspace-switch:" + cell.modelData.index]
                    switchProc.running = true
                }
            }
        }
    }

    Process {
        id: switchProc
        stderr: SplitParser { onRead: line => console.warn("[Workspaces/Umbriel] umbriel msg:", line) }
    }
}
