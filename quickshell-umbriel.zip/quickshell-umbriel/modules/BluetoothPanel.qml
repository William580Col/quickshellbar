pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"
import "../services" as Services

/*
  Panel Bluetooth (accesible desde el módulo "bluetooth" de la barra).
  Permite encender/apagar el adaptador, escanear dispositivos cercanos,
  emparejar, conectar/desconectar, confiar y olvidar dispositivos.
*/
PanelWindow { // qmllint disable uncreatable-type
    id: root
    property bool open: false
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    // dispositivo expandido para ver opciones extra ("" = ninguno)
    property string expandedDevice: ""

    property var items: root.buildItems()

    function show() {
        open = true
        expandedDevice = ""
        Services.Bluetooth.refresh()
        if (Services.Bluetooth.powered) Services.Bluetooth.startScan()
    }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    // Lista visible: conectados, luego emparejados, luego cercanos.
    function buildItems() {
        var conn = [], paired = [], near = []
        var seen = {}
        for (var i = 0; i < Services.Bluetooth.devices.length; i++) {
            var d = Services.Bluetooth.devices[i]
            if (seen[d.address]) continue
            seen[d.address] = true
            if (d.connected) conn.push(d)
            else if (d.paired) paired.push(d)
            else near.push(d)
        }
        conn.sort((a, b) => (a.name || "").localeCompare(b.name || ""))
        paired.sort((a, b) => (a.name || "").localeCompare(b.name || ""))
        near.sort((a, b) => (a.name || "").localeCompare(b.name || ""))
        var out = conn.concat(paired, near)
        for (var k = 0; k < out.length; k++) {
            out[k].category = out[k].connected ? "Conectados" : (out[k].paired ? "Emparejados" : "Cercanos")
        }
        return out
    }

    function primaryAction(modelData) {
        if (Services.Bluetooth.busy === modelData.address) return
        if (modelData.connected) Services.Bluetooth.disconnectDevice(modelData.address)
        else if (modelData.paired) Services.Bluetooth.connectDevice(modelData.address)
        else Services.Bluetooth.pairDevice(modelData.address)
    }

    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.15
        width: 400
        height: 540
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 10

            // ---- Encabezado: título + estado + acciones ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 1
                    Text { text: "Bluetooth"; color: Theme.text; font.pixelSize: 15; font.bold: true }
                    Text {
                        text: Services.Bluetooth.powered
                            ? (Services.Bluetooth.discovering ? "Escaneando dispositivos cercanos…" : Services.Bluetooth.devices.length + " dispositivo(s) conocido(s)")
                            : "Bluetooth apagado"
                        color: Services.Bluetooth.powered ? Theme.subtext : Theme.warning
                        font.pixelSize: 10
                    }
                }

                // Escanear / detener escaneo
                Text {
                    visible: Services.Bluetooth.powered
                    text: Services.Bluetooth.discovering ? "󰑐" : "󰑓"
                    color: Theme.subtext
                    font.pixelSize: 15
                    MouseArea {
                        anchors.fill: parent
                        anchors.margins: -6
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Services.Bluetooth.toggleScan()
                    }
                }

                // Interruptor Bluetooth on/off
                Rectangle {
                    Layout.preferredWidth: 42
                    Layout.preferredHeight: 22
                    radius: 11
                    color: Services.Bluetooth.powered ? Theme.accent : Theme.bgAlt
                    border.color: Theme.border
                    border.width: Services.Bluetooth.powered ? 0 : 1

                    Rectangle {
                        width: 16; height: 16; radius: 8
                        color: Theme.bg
                        anchors.verticalCenter: parent.verticalCenter
                        x: Services.Bluetooth.powered ? parent.width - width - 3 : 3
                        Behavior on x { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Services.Bluetooth.toggleAdapter()
                    }
                }
            }

            // ---- Error de la última operación, si lo hay ----
            Rectangle {
                visible: Services.Bluetooth.lastError.length > 0
                Layout.fillWidth: true
                Layout.preferredHeight: errText.implicitHeight + 16
                radius: Theme.radiusSmall
                color: Qt.rgba(Theme.danger.r, Theme.danger.g, Theme.danger.b, 0.15)
                border.color: Theme.danger
                border.width: 1
                Text {
                    id: errText
                    anchors.fill: parent
                    anchors.margins: 8
                    text: Services.Bluetooth.lastError
                    color: Theme.danger
                    font.pixelSize: 11
                    wrapMode: Text.WordWrap
                }
            }

            // ---- Lista de dispositivos ----
            ListView {
                id: list
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                spacing: 4
                model: root.items
                enabled: Services.Bluetooth.powered
                opacity: Services.Bluetooth.powered ? 1 : 0.4
                section.property: "category"
                section.labelPositioning: ViewSection.CurrentLabelAtStart
                section.delegate: Item {
                    id: sectionDelegate
                    required property string section
                    width: list.width
                    height: 28
                    Text {
                        anchors.left: parent.left
                        anchors.leftMargin: 4
                        anchors.verticalCenter: parent.verticalCenter
                        text: sectionDelegate.section
                        color: Theme.subtext
                        font.pixelSize: 11
                        font.bold: true
                    }
                }

                delegate: Rectangle {
                    id: row
                    required property var modelData
                    property bool isBusy: Services.Bluetooth.busy === row.modelData.address
                    property bool isExpanded: root.expandedDevice === row.modelData.address

                    width: list.width
                    height: row.isExpanded ? 96 : 52
                    radius: Theme.radiusSmall
                    color: row.modelData.connected
                        ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.15)
                        : Theme.bgAlt
                    border.color: row.modelData.connected ? Theme.accent : Theme.border
                    border.width: row.modelData.connected ? 1 : 0
                    clip: true

                    Behavior on height { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }

                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 10
                        spacing: 8

                        RowLayout {
                            Layout.fillWidth: true
                            spacing: 10

                            Text {
                                text: row.modelData.connected ? "󰂱" : "󰂯"
                                color: row.modelData.connected ? Theme.accent : Theme.text
                                font.pixelSize: 16
                            }

                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 0
                                Text {
                                    text: row.modelData.name || row.modelData.address
                                    color: Theme.text
                                    font.pixelSize: 13
                                    font.bold: true
                                    elide: Text.ElideRight
                                }
                                Text {
                                    text: row.isBusy
                                        ? (Services.Bluetooth.busyOp === "pair" ? "Emparejando…"
                                          : Services.Bluetooth.busyOp === "connect" ? "Conectando…"
                                          : Services.Bluetooth.busyOp === "disconnect" ? "Desconectando…"
                                          : "Ocupado…")
                                        : (row.modelData.connected
                                          ? (row.modelData.battery >= 0 ? "Conectado · 󰁹 " + row.modelData.battery + "%" : "Conectado")
                                          : (row.modelData.paired ? "Emparejado" : "Cercano"))
                                    color: row.modelData.connected ? Theme.accent : Theme.subtext
                                    font.pixelSize: 10
                                }
                            }

                            PrimaryBtn {
                                label: row.modelData.connected ? "Desconectar"
                                    : (row.modelData.paired ? "Conectar" : "Emparejar")
                                accent: !row.modelData.connected
                                danger: row.modelData.connected
                                enabled: !row.isBusy
                                onClicked: root.primaryAction(row.modelData)
                            }

                            Text {
                                text: row.isExpanded ? "▾" : "▸"
                                color: Theme.subtext
                                font.pixelSize: 11
                                MouseArea {
                                    anchors.fill: parent
                                    anchors.margins: -8
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: root.expandedDevice = row.isExpanded ? "" : row.modelData.address
                                }
                            }
                        }

                        // ---- Opciones extra (expandido) ----
                        RowLayout {
                            visible: row.isExpanded
                            Layout.fillWidth: true
                            spacing: 8

                            Item { Layout.fillWidth: true }

                            SmallBtn {
                                visible: row.modelData.paired
                                text: row.modelData.trusted ? "No confiar" : "Confiar"
                                enabled: !row.isBusy
                                onClicked: Services.Bluetooth.trustDevice(row.modelData.address, !row.modelData.trusted)
                            }

                            SmallBtn {
                                text: "Olvidar"
                                danger: true
                                enabled: !row.isBusy
                                onClicked: Services.Bluetooth.removeDevice(row.modelData.address)
                            }
                        }
                    }

                    // Expande/colapsa al hacer clic en la fila (z bajo, no tapa
                    // los botones ni el campo de acciones, igual que en WiFiPanel).
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        z: -1
                        onClicked: root.expandedDevice = row.isExpanded ? "" : row.modelData.address
                    }
                }
            }

            // ---- Mensajes de estado vacío ----
            Text {
                Layout.fillWidth: true
                visible: Services.Bluetooth.powered && root.items.length === 0
                text: Services.Bluetooth.discovering
                    ? "Buscando dispositivos cercanos…"
                    : "Sin dispositivos. Pulsa el icono 󰑓 para escanear."
                color: Theme.subtext
                font.pixelSize: 11
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
            }
        }
    }

    // ================= Componentes reutilizables =================

    component PrimaryBtn: Rectangle {
        id: pb
        property string label: ""
        property bool accent: false
        property bool danger: false
        signal clicked()

        Layout.preferredWidth: labelText.implicitWidth + 20
        Layout.preferredHeight: 28
        radius: Theme.radiusSmall
        color: pb.danger
            ? Qt.rgba(Theme.danger.r, Theme.danger.g, Theme.danger.b, 0.15)
            : (pb.enabled ? Theme.accent : Theme.bgAlt)
        border.color: pb.danger ? Theme.danger : (pb.enabled ? Theme.accent : Theme.border)
        border.width: 1
        opacity: pb.enabled ? 1 : 0.5

        Text {
            id: labelText
            anchors.centerIn: parent
            text: pb.label
            color: pb.danger ? Theme.danger : (pb.enabled ? Theme.bg : Theme.subtext)
            font.pixelSize: 10
            font.bold: true
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            enabled: pb.enabled
            onClicked: pb.clicked()
        }
    }

    component SmallBtn: Rectangle {
        id: sb
        property string text: ""
        property bool danger: false
        signal clicked()

        Layout.preferredWidth: labelText.implicitWidth + 16
        Layout.preferredHeight: 26
        radius: Theme.radiusSmall
        color: sb.danger
            ? Qt.rgba(Theme.danger.r, Theme.danger.g, Theme.danger.b, 0.12)
            : (sb.enabled ? Theme.bg : Theme.bgAlt)
        border.color: sb.danger ? Theme.danger : Theme.border
        border.width: 1
        opacity: sb.enabled ? 1 : 0.5

        Text {
            id: labelText
            anchors.centerIn: parent
            text: sb.text
            color: sb.danger ? Theme.danger : Theme.subtext
            font.pixelSize: 10
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            enabled: sb.enabled
            onClicked: sb.clicked()
        }
    }
}