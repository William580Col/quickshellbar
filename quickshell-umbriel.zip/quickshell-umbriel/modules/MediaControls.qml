import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Services.Mpris
import "../config"

/*
  Control de medios en la barra: título de la pista/video en reproducción
  + controles de anterior/pausa-play/siguiente. Usa el soporte MPRIS nativo
  de Quickshell (Quickshell.Services.Mpris), compatible con cualquier
  reproductor que hable MPRIS (mpv con el plugin correspondiente,
  navegadores reproduciendo video, Spotify, etc.) — no depende de
  playerctl externo.

  Si hay varios reproductores activos a la vez, se prioriza el que esté
  sonando; si ninguno está reproduciendo, se muestra el primero disponible.
*/
Item {
    id: root

    property var activePlayer: {
        var list = Mpris.players.values
        for (var i = 0; i < list.length; i++) {
            if (list[i].isPlaying) return list[i]
        }
        return list.length > 0 ? list[0] : null
    }

    visible: activePlayer !== null
    width: visible ? content.implicitWidth : 0
    height: 30

    RowLayout {
        id: content
        anchors.verticalCenter: parent.verticalCenter
        spacing: 8

        Text {
            text: "󰝚"
            color: Theme.accent
            font.pixelSize: 13
        }

        Text {
            Layout.maximumWidth: 200
            text: root.activePlayer
                  ? ((root.activePlayer.trackTitle || "Reproduciendo")
                     + (root.activePlayer.trackArtist ? " — " + root.activePlayer.trackArtist : ""))
                  : ""
            color: Theme.text
            font.pixelSize: 12
            elide: Text.ElideRight
        }

        Text {
            text: "󰒮"
            color: (root.activePlayer && root.activePlayer.canGoPrevious) ? Theme.text : Theme.subtext
            font.pixelSize: 13
            MouseArea {
                anchors.fill: parent
                anchors.margins: -5
                cursorShape: Qt.PointingHandCursor
                enabled: root.activePlayer && root.activePlayer.canGoPrevious
                onClicked: root.activePlayer.previous()
            }
        }

        Text {
            text: (root.activePlayer && root.activePlayer.isPlaying) ? "󰏤" : "󰐊"
            color: Theme.accent
            font.pixelSize: 15
            MouseArea {
                anchors.fill: parent
                anchors.margins: -5
                cursorShape: Qt.PointingHandCursor
                enabled: root.activePlayer && root.activePlayer.canTogglePlaying
                onClicked: root.activePlayer.isPlaying = !root.activePlayer.isPlaying
            }
        }

        Text {
            text: "󰒭"
            color: (root.activePlayer && root.activePlayer.canGoNext) ? Theme.text : Theme.subtext
            font.pixelSize: 13
            MouseArea {
                anchors.fill: parent
                anchors.margins: -5
                cursorShape: Qt.PointingHandCursor
                enabled: root.activePlayer && root.activePlayer.canGoNext
                onClicked: root.activePlayer.next()
            }
        }
    }
}
