import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import "../config"

/*
  Visor de ventanas abiertas (todas las workspaces, no solo la actual).
  Usa "umbriel windows --json" (confirmado en docs.noctalia.dev/umbriel/ipc/)
  y "umbriel msg window-focus:<id>" / "umbriel msg window-close:<id>"
  (confirmado en docs.noctalia.dev/umbriel/actions/) para saltar/cerrar.
  Agrupadas por workspace, con icono de app, búsqueda, y cerrar al vuelo.
*/
PanelWindow {
    id: root
    property bool open: false
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    property var windows: []
    property string filterText: ""

    // Agrupa windows[] en [{ workspace, items: [...] }, ...], ordenado por
    // nombre de workspace, filtrando por el texto de búsqueda si hay.
    property var groups: {
        var byWs = {}
        var order = []
        var needle = root.filterText.toLowerCase()
        for (var i = 0; i < root.windows.length; i++) {
            var w = root.windows[i]
            if (needle.length > 0 && w.name.toLowerCase().indexOf(needle) === -1
                && w.app_id.toLowerCase().indexOf(needle) === -1) continue
            var ws = w.workspace || "?"
            if (!byWs[ws]) { byWs[ws] = []; order.push(ws) }
            byWs[ws].push(w)
        }
        order.sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))
        return order.map(ws => ({ workspace: ws, items: byWs[ws] }))
    }

    function show() {
        open = true
        filterText = ""
        refresh()
    }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    function refresh() { listProc.running = true }

    // "umbriel windows --json" ya devuelve una lista plana (no un árbol
    // como Sway), así que no hace falta recorrer nada recursivamente.
    // NOTA: no se confirmó en la documentación el nombre exacto de un
    // campo de título "amigable" vs "name" — se usa "title" con caída a
    // "app_id" si falta, y "workspace" tal cual lo reporte Umbriel (puede
    // ser un id numérico, no necesariamente un nombre legible).
    Process {
        id: listProc
        command: ["umbriel", "windows", "--json"]
        property string buf: ""
        stdout: SplitParser { onRead: line => listProc.buf += line }
        onExited: {
            try {
                var wins = JSON.parse(listProc.buf)
                var out = wins.map(w => ({
                    id: w.id,
                    name: w.title || w.app_id || "Ventana",
                    app_id: w.app_id || "",
                    workspace: (w.workspace !== undefined && w.workspace !== null && w.workspace !== "") ? String(w.workspace) : "Scratchpad",
                    focused: !!w.focused
                }))
                root.windows = out
            } catch (e) {
                console.warn("[WindowSwitcher/Umbriel] Error parseando JSON:", e)
            }
            listProc.buf = ""
        }
    }

    function focusWindow(id) {
        focusProc.command = ["umbriel", "msg", "window-focus:" + id]
        focusProc.running = true
        root.hide()
    }
    Process {
        id: focusProc
        stderr: SplitParser { onRead: line => console.warn("[WindowSwitcher/Umbriel] umbriel msg:", line) }
    }

    function closeWindow(id) {
        closeProc.command = ["umbriel", "msg", "window-close:" + id]
        closeProc.running = true
        // la lista cambia al cerrar; refresca tras un breve instante
        refreshAfterCloseTimer.restart()
    }
    Process {
        id: closeProc
        stderr: SplitParser { onRead: line => console.warn("[WindowSwitcher/Umbriel] umbriel msg:", line) }
    }
    Timer {
        id: refreshAfterCloseTimer
        interval: 200
        onTriggered: root.refresh()
    }

    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        anchors.centerIn: parent
        width: 720
        height: 500
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 12

            // ---- Encabezado: título + refrescar ----
            RowLayout {
                Layout.fillWidth: true
                Text {
                    text: "Ventanas abiertas"
                    color: Theme.text
                    font.pixelSize: 16
                    font.bold: true
                    Layout.fillWidth: true
                }
                Text {
                    text: root.windows.length + (root.windows.length === 1 ? " ventana" : " ventanas")
                    color: Theme.subtext
                    font.pixelSize: 11
                }
                Text {
                    text: "󰑓"
                    color: Theme.subtext
                    font.pixelSize: 15
                    MouseArea {
                        anchors.fill: parent
                        anchors.margins: -6
                        cursorShape: Qt.PointingHandCursor
                        onClicked: root.refresh()
                    }
                }
            }

            // ---- Buscador ----
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 40
                radius: Theme.radiusMedium
                color: Theme.bgAlt
                border.color: searchField.activeFocus ? Theme.accent : Theme.border
                border.width: 1

                RowLayout {
                    anchors.fill: parent
                    anchors.margins: 8
                    spacing: 8
                    Text { text: "󰍉"; color: Theme.subtext; font.pixelSize: 13 }
                    TextInput {
                        id: searchField
                        Layout.fillWidth: true
                        color: Theme.text
                        font.pixelSize: 13
                        clip: true
                        onTextChanged: root.filterText = text
                        Keys.onEscapePressed: root.hide()
                        Text {
                            visible: searchField.text.length === 0
                            text: "Buscar ventana…"
                            color: Theme.subtext
                            font.pixelSize: 13
                        }
                    }
                }
            }

            // ---- Grupos por workspace ----
            ScrollView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true

                ColumnLayout {
                    width: parent.width
                    spacing: 16

                    Repeater {
                        model: root.groups

                        delegate: ColumnLayout {
                            id: groupCol
                            required property var modelData
                            Layout.fillWidth: true
                            spacing: 8

                            RowLayout {
                                spacing: 8
                                Rectangle {
                                    width: 22; height: 22; radius: 11
                                    color: Theme.accent
                                    Text {
                                        anchors.centerIn: parent
                                        text: groupCol.modelData.workspace
                                        color: Theme.bg
                                        font.pixelSize: 10
                                        font.bold: true
                                    }
                                }
                                Rectangle { Layout.fillWidth: true; height: 1; color: Theme.border }
                            }

                            GridLayout {
                                Layout.fillWidth: true
                                columns: 2
                                rowSpacing: 10
                                columnSpacing: 10

                                Repeater {
                                    model: groupCol.modelData.items

                                    delegate: Rectangle {
                                        id: cell
                                        required property var modelData
                                        Layout.preferredWidth: 320
                                        Layout.preferredHeight: 64
                                        radius: Theme.radiusMedium
                                        color: area.containsMouse
                                               ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.12)
                                               : (cell.modelData.focused ? Qt.rgba(Theme.accent.r, Theme.accent.g, Theme.accent.b, 0.18) : Theme.bgAlt)
                                        border.width: cell.modelData.focused ? 1 : 0
                                        border.color: Theme.accent

                                        Behavior on color { ColorAnimation { duration: 100 } }

                                        RowLayout {
                                            anchors.fill: parent
                                            anchors.margins: 10
                                            spacing: 10

                                            Rectangle {
                                                width: 40; height: 40
                                                radius: Theme.radiusSmall
                                                color: Theme.bg

                                                Image {
                                                    id: appIcon
                                                    anchors.fill: parent
                                                    anchors.margins: 6
                                                    source: cell.modelData.app_id ? "image://icon/" + cell.modelData.app_id : ""
                                                    fillMode: Image.PreserveAspectFit
                                                    asynchronous: true
                                                    visible: status === Image.Ready
                                                }
                                                Text {
                                                    anchors.centerIn: parent
                                                    visible: appIcon.status !== Image.Ready
                                                    text: "󰖯"
                                                    color: Theme.subtext
                                                    font.pixelSize: 18
                                                }
                                            }

                                            ColumnLayout {
                                                Layout.fillWidth: true
                                                spacing: 1
                                                Text {
                                                    text: cell.modelData.name
                                                    color: Theme.text
                                                    font.pixelSize: 12
                                                    font.bold: true
                                                    elide: Text.ElideRight
                                                    Layout.fillWidth: true
                                                }
                                                Text {
                                                    text: cell.modelData.app_id || "—"
                                                    color: Theme.subtext
                                                    font.pixelSize: 10
                                                    elide: Text.ElideRight
                                                    Layout.fillWidth: true
                                                }
                                            }

                                            // Botón cerrar, solo visible al pasar el mouse
                                            Rectangle {
                                                visible: area.containsMouse
                                                width: 22; height: 22; radius: 11
                                                color: closeArea.containsMouse ? Theme.danger : "transparent"
                                                Text {
                                                    anchors.centerIn: parent
                                                    text: "×"
                                                    color: closeArea.containsMouse ? Theme.bg : Theme.subtext
                                                    font.pixelSize: 14
                                                    font.bold: true
                                                }
                                                MouseArea {
                                                    id: closeArea
                                                    anchors.fill: parent
                                                    hoverEnabled: true
                                                    cursorShape: Qt.PointingHandCursor
                                                    onClicked: root.closeWindow(cell.modelData.id)
                                                }
                                            }
                                        }

                                        MouseArea {
                                            id: area
                                            anchors.fill: parent
                                            hoverEnabled: true
                                            cursorShape: Qt.PointingHandCursor
                                            onClicked: root.focusWindow(cell.modelData.id)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Text {
                visible: root.windows.length === 0
                Layout.fillWidth: true
                Layout.fillHeight: true
                text: "No hay ventanas abiertas"
                color: Theme.subtext
                font.pixelSize: 12
                horizontalAlignment: Text.AlignHCenter
                verticalAlignment: Text.AlignVCenter
            }
        }
    }
}
