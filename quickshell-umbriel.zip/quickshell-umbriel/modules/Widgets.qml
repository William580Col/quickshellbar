import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"
import "../services" as Services

/*
  Widgets de escritorio estilo Mac: pastillas de cristal (fondo
  translúcido + blur de Hyprland por el namespace "quickshell";
  en Sway solo transparencia, sin blur por diseño del compositor),
  números grandes tabulares y acento del wallpaper.

  Un overlay transparente por pantalla, sin zona exclusiva. La máscara
  de clics (mask) hace que solo las pastillas intercepten el mouse:
  el resto del escritorio sigue recibiendo clics con normalidad.

  Cada widget se arrastra con el mouse y al soltar guarda su posición
  en WidgetsConfig (persistente). Se instancia una vez por pantalla
  desde shell.qml, en su propio bloque Variants.
*/
PanelWindow { // qmllint disable uncreatable-type
    id: root

    required property var modelData // pantalla inyectada por Variants
    screen: modelData

    // Mismo namespace que barra y dock: comparte la regla de blur.
    WlrLayershell.namespace: "quickshell"
    // Capa baja: los widgets viven en el escritorio, debajo de las ventanas.
    WlrLayershell.layer: WlrLayer.Bottom
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }
    exclusiveZone: 0
    color: "transparent"
    visible: WidgetsConfig.enabled

    // Solo las pastillas visibles son clicables (item nulo = sin zona).
    mask: Region {
        Region { item: clockCard.visible ? clockCard : null }
        Region { item: cpuCard.visible ? cpuCard : null }
        Region { item: memCard.visible ? memCard : null }
        Region { item: batCard.visible ? batCard : null }
    }

    function accentFor(name) {
        return WidgetsConfig[name].useAccent ? Theme.accent : Theme.text
    }

    // ---- Reloj digital ----
    property string timeStr: "--:--"
    property string dateStr: ""
    function updateClock() {
        var d = new Date()
        timeStr = Qt.formatTime(d, "HH:mm")
        dateStr = Qt.formatDate(d, "ddd d MMM")
    }
    Timer {
        interval: 1000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.updateClock()
    }

    // ---- Pastilla: reloj ----
    Rectangle {
        id: clockCard
        width: WidgetsConfig.baseSize("clock").w
        height: WidgetsConfig.baseSize("clock").h
        x: WidgetsConfig.clock.x
        y: WidgetsConfig.clock.y
        scale: WidgetsConfig.clock.scale
        transformOrigin: Item.TopLeft
        visible: WidgetsConfig.enabled && WidgetsConfig.clock.enabled
        radius: Theme.radiusLarge
        color: WidgetsConfig.widgetSurface(Theme.surface)
        border.color: Theme.border
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 2
            Text {
                text: root.timeStr
                color: root.accentFor("clock")
                font.pixelSize: 36
                font.bold: true
                font.family: "monospace"
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
            }
            Text {
                text: root.dateStr
                color: Theme.subtext
                font.pixelSize: 12
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
            }
        }

        MouseArea {
            anchors.fill: parent
            drag.target: parent
            drag.axis: Drag.XAndYAxis
            onReleased: {
                WidgetsConfig.setPos("clock", Math.round(clockCard.x), Math.round(clockCard.y))
                clockCard.x = Qt.binding(function() { return WidgetsConfig.clock.x })
                clockCard.y = Qt.binding(function() { return WidgetsConfig.clock.y })
            }
        }
    }

    // ---- Pastilla: CPU ----
    Rectangle {
        id: cpuCard
        width: WidgetsConfig.baseSize("cpu").w
        height: WidgetsConfig.baseSize("cpu").h
        x: WidgetsConfig.cpu.x
        y: WidgetsConfig.cpu.y
        scale: WidgetsConfig.cpu.scale
        transformOrigin: Item.TopLeft
        visible: WidgetsConfig.enabled && WidgetsConfig.cpu.enabled
        radius: Theme.radiusLarge
        color: WidgetsConfig.widgetSurface(Theme.surface)
        border.color: Theme.border
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 8
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Text {
                    text: "CPU"
                    color: Theme.subtext
                    font.pixelSize: 11
                    font.bold: true
                    Layout.fillWidth: true
                }
                Text {
                    text: Math.round(Services.SystemStats.cpuPercent) + "%"
                    color: root.accentFor("cpu")
                    font.pixelSize: 22
                    font.bold: true
                    font.family: "monospace"
                    horizontalAlignment: Text.AlignRight
                }
            }
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 6
                radius: 3
                color: Theme.bgAlt
                Rectangle {
                    width: parent.width * Math.max(0, Math.min(1, Services.SystemStats.cpuPercent / 100))
                    height: parent.height
                    radius: 3
                    color: root.accentFor("cpu")
                    Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
                }
            }
        }

        MouseArea {
            anchors.fill: parent
            drag.target: parent
            drag.axis: Drag.XAndYAxis
            onReleased: {
                WidgetsConfig.setPos("cpu", Math.round(cpuCard.x), Math.round(cpuCard.y))
                cpuCard.x = Qt.binding(function() { return WidgetsConfig.cpu.x })
                cpuCard.y = Qt.binding(function() { return WidgetsConfig.cpu.y })
            }
        }
    }

    // ---- Pastilla: memoria ----
    Rectangle {
        id: memCard
        width: WidgetsConfig.baseSize("mem").w
        height: WidgetsConfig.baseSize("mem").h
        x: WidgetsConfig.mem.x
        y: WidgetsConfig.mem.y
        scale: WidgetsConfig.mem.scale
        transformOrigin: Item.TopLeft
        visible: WidgetsConfig.enabled && WidgetsConfig.mem.enabled
        radius: Theme.radiusLarge
        color: WidgetsConfig.widgetSurface(Theme.surface)
        border.color: Theme.border
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 8
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Text {
                    text: "RAM"
                    color: Theme.subtext
                    font.pixelSize: 11
                    font.bold: true
                    Layout.fillWidth: true
                }
                Text {
                    text: Math.round(Services.SystemStats.memPercent) + "%"
                    color: root.accentFor("mem")
                    font.pixelSize: 22
                    font.bold: true
                    font.family: "monospace"
                    horizontalAlignment: Text.AlignRight
                }
            }
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 6
                radius: 3
                color: Theme.bgAlt
                Rectangle {
                    width: parent.width * Math.max(0, Math.min(1, Services.SystemStats.memPercent / 100))
                    height: parent.height
                    radius: 3
                    color: root.accentFor("mem")
                    Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
                }
            }
            Text {
                text: Services.SystemStats.memUsedGB.toFixed(1) + " / " + Services.SystemStats.memTotalGB.toFixed(1) + " GB"
                color: Theme.subtext
                font.pixelSize: 11
                font.family: "monospace"
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
            }
        }

        MouseArea {
            anchors.fill: parent
            drag.target: parent
            drag.axis: Drag.XAndYAxis
            onReleased: {
                WidgetsConfig.setPos("mem", Math.round(memCard.x), Math.round(memCard.y))
                memCard.x = Qt.binding(function() { return WidgetsConfig.mem.x })
                memCard.y = Qt.binding(function() { return WidgetsConfig.mem.y })
            }
        }
    }

    // ---- Pastilla: batería (oculta si no hay batería) ----
    Rectangle {
        id: batCard
        width: WidgetsConfig.baseSize("battery").w
        height: WidgetsConfig.baseSize("battery").h
        x: WidgetsConfig.battery.x
        y: WidgetsConfig.battery.y
        scale: WidgetsConfig.battery.scale
        transformOrigin: Item.TopLeft
        visible: WidgetsConfig.enabled && WidgetsConfig.battery.enabled && Services.SystemStats.batAvailable
        radius: Theme.radiusLarge
        color: WidgetsConfig.widgetSurface(Theme.surface)
        border.color: Theme.border
        border.width: 1

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 14
            spacing: 8
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Text {
                    text: Services.SystemStats.batCharging ? "Cargando" : "Batería"
                    color: Theme.subtext
                    font.pixelSize: 11
                    font.bold: true
                    Layout.fillWidth: true
                }
                Text {
                    visible: Services.SystemStats.batCharging
                    text: "⚡"
                    color: root.accentFor("battery")
                    font.pixelSize: 14
                }
                Text {
                    text: Math.round(Services.SystemStats.batPercent) + "%"
                    color: root.accentFor("battery")
                    font.pixelSize: 22
                    font.bold: true
                    font.family: "monospace"
                    horizontalAlignment: Text.AlignRight
                }
            }
            RowLayout {
                Layout.fillWidth: true
                spacing: 3
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 14
                    radius: 4
                    color: "transparent"
                    border.color: Theme.subtext
                    border.width: 1
                    Rectangle {
                        anchors.fill: parent
                        anchors.margins: 3
                        radius: 2
                        color: Theme.bgAlt
                        Rectangle {
                            width: parent.width * Math.max(0, Math.min(1, Services.SystemStats.batPercent / 100))
                            height: parent.height
                            radius: 2
                            color: root.accentFor("battery")
                            Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
                        }
                    }
                }
                Rectangle {
                    Layout.preferredWidth: 3
                    Layout.preferredHeight: 7
                    radius: 1
                    color: Theme.subtext
                }
            }
            Text {
                text: Services.SystemStats.batCharging ? "Conectada a la corriente" : "Queda " + Math.round(Services.SystemStats.batPercent) + "% de carga"
                color: Theme.subtext
                font.pixelSize: 11
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignHCenter
            }
        }

        MouseArea {
            anchors.fill: parent
            drag.target: parent
            drag.axis: Drag.XAndYAxis
            onReleased: {
                WidgetsConfig.setPos("battery", Math.round(batCard.x), Math.round(batCard.y))
                batCard.x = Qt.binding(function() { return WidgetsConfig.battery.x })
                batCard.y = Qt.binding(function() { return WidgetsConfig.battery.y })
            }
        }
    }
}
