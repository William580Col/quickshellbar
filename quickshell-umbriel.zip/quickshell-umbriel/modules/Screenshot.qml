import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import "../config"

/*
  Captura de pantalla para Umbriel.

  Confirmado en docs.noctalia.dev/umbriel/keybinds/: "These bindings
  capture through grim and slurp over wlr-screencopy" — es decir, Umbriel
  SÍ implementa wlr-screencopy directamente (no solo vía xdg-desktop-
  portal), así que grim/slurp deberían funcionar lanzados normalmente.

  Aun así, la captura de ÁREA se enruta vía "umbriel msg spawn:<script>"
  (equivalente a hyprctl dispatch exec_cmd / swaymsg exec que usamos en
  las otras variantes) apuntando a un script EXTERNO, como medida de
  seguridad: en Hyprland encontramos un caso real donde slurp lanzado
  directo como hijo de Quickshell no lograba su grab de teclado/mouse,
  pero sí funcionaba lanzado por el propio compositor. Si en tu Umbriel
  esto no hiciera falta, puedes simplificar a un proceso directo como la
  captura completa de abajo.
*/
Row {
    id: root
    spacing: 14

    property string scriptsDir: Quickshell.env("HOME") + "/.config/quickshell/umbriel/scripts"
    property string dir: Quickshell.env("HOME") + "/Pictures/Screenshots"

    // Captura completa (proceso directo, no necesita superficie interactiva)
    Item {
        width: 18; height: 18
        anchors.verticalCenter: parent.verticalCenter
        Text { anchors.centerIn: parent; text: "󰄀"; color: Theme.text; font.pixelSize: 15 }
        MouseArea {
            anchors.fill: parent
            anchors.margins: -8
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                if (fullProc.running) return
                fullProc.command = [
                    "sh", "-c",
                    "mkdir -p '" + root.dir + "' && " +
                    "f=\"" + root.dir + "/$(date +%Y-%m-%d_%H-%M-%S).png\" && " +
                    "grim \"$f\" && " +
                    "wl-copy < \"$f\" && " +
                    "notify-send 'Captura de pantalla' \"Guardada en $f\""
                ]
                fullProc.running = true
            }
        }
    }

    // Captura de área — enrutada a través de "umbriel msg spawn:<script>"
    Item {
        width: 18; height: 18
        anchors.verticalCenter: parent.verticalCenter
        Text { anchors.centerIn: parent; text: "󰆞"; color: Theme.text; font.pixelSize: 15 }
        MouseArea {
            anchors.fill: parent
            anchors.margins: -8
            cursorShape: Qt.PointingHandCursor
            onClicked: {
                if (areaProc.running) return
                areaProc.command = ["umbriel", "msg", "spawn:" + root.scriptsDir + "/screenshot-area.sh"]
                areaProc.running = true
            }
        }
    }

    Process {
        id: fullProc
        stdout: SplitParser { onRead: line => console.log("[Screenshot full] stdout:", line) }
        stderr: SplitParser { onRead: line => console.warn("[Screenshot full] stderr:", line) }
    }

    Process {
        id: areaProc
        stdout: SplitParser { onRead: line => console.log("[Screenshot area] stdout:", line) }
        stderr: SplitParser { onRead: line => console.warn("[Screenshot area] stderr:", line) }
    }
}
