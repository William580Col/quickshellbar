pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Estadísticas del sistema sin dependencias externas (sin upower ni
  lm-sensors): CPU desde /proc/stat (delta entre lecturas), memoria
  desde /proc/meminfo y batería desde /sys/class/power_supply/BAT*.
  Se actualiza cada 2000ms con un Timer.
*/
Singleton {
    id: stats

    property real cpuPercent: 0
    property real memPercent: 0
    property real memUsedGB: 0
    property real memTotalGB: 0
    property real batPercent: 0
    property bool batCharging: false
    property bool batAvailable: false

    property real _prevIdle: -1
    property real _prevTotal: -1

    function refresh() {
        if (!statProc.running) statProc.running = true
        if (!memProc.running) memProc.running = true
        if (!batProc.running) batProc.running = true
    }

    Timer {
        interval: 2000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: stats.refresh()
    }

    function _parseStat(text) {
        var lines = text.split("\n")
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim()
            if (line.indexOf("cpu ") !== 0) continue
            var parts = line.split(/\s+/)
            var nums = []
            for (var k = 1; k < parts.length; k++) {
                var n = parseFloat(parts[k])
                nums.push(isNaN(n) ? 0 : n)
            }
            if (nums.length < 4) return
            var idle = nums[3] + (nums.length > 4 ? nums[4] : 0)
            var total = 0
            for (var j = 0; j < nums.length; j++) total += nums[j]
            if (stats._prevTotal > 0 && total > stats._prevTotal) {
                var dTotal = total - stats._prevTotal
                var dIdle = idle - stats._prevIdle
                var u = 100 * (1 - dIdle / dTotal)
                stats.cpuPercent = Math.max(0, Math.min(100, u))
            }
            stats._prevTotal = total
            stats._prevIdle = idle
            return
        }
    }

    function _parseMem(text) {
        var t = /MemTotal:\s+(\d+)/.exec(text)
        var a = /MemAvailable:\s+(\d+)/.exec(text)
        if (!a) a = /MemFree:\s+(\d+)/.exec(text)
        if (!t) return
        var totalKB = parseFloat(t[1])
        if (!(totalKB > 0)) return
        var availKB = a ? parseFloat(a[1]) : 0
        var usedKB = Math.max(0, totalKB - availKB)
        stats.memTotalGB = totalKB / 1048576
        stats.memUsedGB = usedKB / 1048576
        stats.memPercent = Math.max(0, Math.min(100, 100 * usedKB / totalKB))
    }

    function _parseBat(text) {
        var parts = text.split("BATSEP")
        var cap = parts.length > 0 ? parts[0].trim().split("\n")[0].trim() : ""
        var st = parts.length > 1 ? parts[1].trim().split("\n")[0].trim() : ""
        var pct = parseFloat(cap)
        if (cap === "" || isNaN(pct)) {
            stats.batAvailable = false
            return
        }
        stats.batAvailable = true
        stats.batPercent = Math.max(0, Math.min(100, pct))
        stats.batCharging = st === "Charging"
    }

    Process {
        id: statProc
        command: ["cat", "/proc/stat"]
        property string buf: ""
        stdout: SplitParser { onRead: line => statProc.buf += line + "\n" }
        onExited: {
            stats._parseStat(statProc.buf)
            statProc.buf = ""
        }
    }

    Process {
        id: memProc
        command: ["cat", "/proc/meminfo"]
        property string buf: ""
        stdout: SplitParser { onRead: line => memProc.buf += line + "\n" }
        onExited: {
            stats._parseMem(memProc.buf)
            memProc.buf = ""
        }
    }

    Process {
        id: batProc
        command: ["sh", "-c", "cat /sys/class/power_supply/BAT*/capacity 2>/dev/null | head -n 1; echo BATSEP; cat /sys/class/power_supply/BAT*/status 2>/dev/null | head -n 1"]
        property string buf: ""
        stdout: SplitParser { onRead: line => batProc.buf += line + "\n" }
        onExited: {
            stats._parseBat(batProc.buf)
            batProc.buf = ""
        }
    }
}
