pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Configuración persistente del dock estilo Mac: activado, posición,
  tamaño de iconos, lupa, opacidad propia y modo de ocultación, más la
  lista de aplicaciones fijadas (ids de .desktop).
*/
Singleton {
    id: dockConfig

    property string statePath: Quickshell.env("HOME") + "/.local/state/quickshell-dock-config.json"

    property bool enabled: true
    property string position: "bottom" // "bottom" | "left" | "right"
    property real iconSize: 36         // 32 .. 64
    property bool zoomEnabled: true
    property real zoomScale: 1.4       // 1.2 .. 2.0
    property real dockAlpha: 0.82      // 0.2 .. 1.0
    property string hideMode: "always" // "always" | "auto" | "smart"
    property var pinned: defaultPinned()

    property bool loaded: false

    // Candidatas a fijar por defecto; al cargar se filtran a las instaladas.
    function defaultPinned() {
        return ["kitty", "alacritty", "firefox", "org.mozilla.firefox",
                "dolphin", "org.kde.dolphin", "nautilus", "org.gnome.nautilus"]
    }

    function setEnabled(v) { dockConfig.enabled = v; save() }
    function setPosition(p) { dockConfig.position = p; save() }
    function setIconSize(v) { dockConfig.iconSize = Math.max(32, Math.min(64, v)); save() }
    function setZoomEnabled(v) { dockConfig.zoomEnabled = v; save() }
    function setZoomScale(v) { dockConfig.zoomScale = Math.max(1.2, Math.min(2.0, v)); save() }
    function setDockAlpha(v) { dockConfig.dockAlpha = Math.max(0.2, Math.min(1.0, v)); save() }
    function setHideMode(m) { dockConfig.hideMode = m; save() }

    function isPinned(id) { return dockConfig.pinned.indexOf(id) !== -1 }

    function togglePin(id) {
        var arr = dockConfig.pinned.slice()
        var idx = arr.indexOf(id)
        if (idx === -1) arr.push(id)
        else arr.splice(idx, 1)
        dockConfig.pinned = arr
        save()
    }

    function unpin(id) {
        if (!isPinned(id)) return
        var arr = dockConfig.pinned.slice()
        arr.splice(arr.indexOf(id), 1)
        dockConfig.pinned = arr
        save()
    }

    function dockSurface(base) {
        return Qt.rgba(base.r, base.g, base.b, dockConfig.dockAlpha)
    }

    function restoreDefaults() {
        dockConfig.enabled = true
        dockConfig.position = "bottom"
        dockConfig.iconSize = 36
        dockConfig.zoomEnabled = true
        dockConfig.zoomScale = 1.4
        dockConfig.dockAlpha = 0.82
        dockConfig.hideMode = "always"
        dockConfig.pinned = defaultPinned()
        save()
    }

    function save() {
        var data = {
            enabled: dockConfig.enabled,
            position: dockConfig.position,
            iconSize: dockConfig.iconSize,
            zoomEnabled: dockConfig.zoomEnabled,
            zoomScale: dockConfig.zoomScale,
            dockAlpha: dockConfig.dockAlpha,
            hideMode: dockConfig.hideMode,
            pinned: dockConfig.pinned
        }
        var json = JSON.stringify(data)
        saveProc.command = ["sh", "-c",
            "mkdir -p \"$(dirname '" + dockConfig.statePath + "')\" && cat > '" + dockConfig.statePath + "' << 'QSDOCKCONFEOF'\n" +
            json + "\nQSDOCKCONFEOF"]
        saveProc.running = true
    }

    Process { id: saveProc }

    Component.onCompleted: {
        loadProc.running = true
    }

    Process {
        id: loadProc
        command: ["sh", "-c", "cat '" + dockConfig.statePath + "' 2>/dev/null || true"]
        property string buf: ""
        stdout: SplitParser { onRead: line => loadProc.buf += line }
        // qmllint disable signal-handler-parameters
        onExited: () => {
            if (loadProc.buf.trim().length > 0) {
                try {
                    var data = JSON.parse(loadProc.buf)
                    if (typeof data.enabled === "boolean") dockConfig.enabled = data.enabled
                    if (data.position === "bottom" || data.position === "left" || data.position === "right")
                        dockConfig.position = data.position
                    if (typeof data.iconSize === "number")
                        dockConfig.iconSize = Math.max(32, Math.min(64, data.iconSize))
                    if (typeof data.zoomEnabled === "boolean") dockConfig.zoomEnabled = data.zoomEnabled
                    if (typeof data.zoomScale === "number")
                        dockConfig.zoomScale = Math.max(1.2, Math.min(2.0, data.zoomScale))
                    if (typeof data.dockAlpha === "number")
                        dockConfig.dockAlpha = Math.max(0.2, Math.min(1.0, data.dockAlpha))
                    if (data.hideMode === "always" || data.hideMode === "auto" || data.hideMode === "smart")
                        dockConfig.hideMode = data.hideMode
                    if (Array.isArray(data.pinned)) dockConfig.pinned = data.pinned
                } catch (e) {
                    console.warn("[DockConfig] Error leyendo config guardada:", e)
                }
            }
            dockConfig.loaded = true
            loadProc.buf = ""
        }
        // qmllint enable signal-handler-parameters
    }
}
