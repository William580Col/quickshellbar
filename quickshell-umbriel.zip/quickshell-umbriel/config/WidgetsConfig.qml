pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io

/*
  Configuración persistente de los widgets de escritorio estilo Mac
  (reloj, CPU, memoria y batería): activado global, y por widget
  activado, posición en el escritorio, escala y si usa el color de
  acento del wallpaper (Theme.accent, que ya sigue a matugen) o
  tonos neutros (Theme.text/subtext).
*/
Singleton {
    id: widgetsConfig

    property string statePath: Quickshell.env("HOME") + "/.local/state/quickshell-widgets-config.json"

    property bool enabled: true

    property real widgetsAlpha: 0.82
    function widgetSurface(base) {
        return Qt.rgba(base.r, base.g, base.b, widgetsConfig.widgetsAlpha)
    }

    property var clock: defaultWidget("clock")
    property var cpu: defaultWidget("cpu")
    property var mem: defaultWidget("mem")
    property var battery: defaultWidget("battery")

    property bool loaded: false

    function defaults() {
        return {
            clock:   { enabled: true, x: 64, y: 64,  scale: 1.0, useAccent: true },
            cpu:     { enabled: true, x: 64, y: 196, scale: 1.0, useAccent: true },
            mem:     { enabled: true, x: 64, y: 322, scale: 1.0, useAccent: true },
            battery: { enabled: true, x: 64, y: 468, scale: 1.0, useAccent: true }
        }
    }

    function defaultWidget(name) {
        return defaults()[name]
    }

    // Tamaño base (sin escala) de cada pastilla. modules/Widgets.qml lo
    // usa para dimensionar y el panel para centrar; mantener sincronizado.
    function baseSize(name) {
        if (name === "clock") return { w: 216, h: 116 }
        if (name === "cpu") return { w: 176, h: 110 }
        if (name === "mem") return { w: 176, h: 130 }
        return { w: 176, h: 130 } // battery
    }

    function label(name) {
        if (name === "clock") return "Reloj"
        if (name === "cpu") return "CPU"
        if (name === "mem") return "Memoria"
        return "Batería"
    }

    function validName(name) {
        return name === "clock" || name === "cpu" || name === "mem" || name === "battery"
    }

    function clampScale(v) {
        return Math.max(0.8, Math.min(1.5, v))
    }

    function _patch(name, field, value) {
        if (!validName(name)) return
        var upd = Object.assign({}, widgetsConfig[name])
        upd[field] = value
        widgetsConfig[name] = upd
        save()
    }

    function setGlobalEnabled(v) { widgetsConfig.enabled = v; save() }
    function setWidgetsAlpha(v) { widgetsConfig.widgetsAlpha = Math.max(0.2, Math.min(1.0, v)); save() }
    function setEnabled(name, v) { _patch(name, "enabled", !!v) }
    function setScale(name, v) { _patch(name, "scale", clampScale(v)) }
    function setUseAccent(name, v) { _patch(name, "useAccent", !!v) }

    function setPos(name, x, y) {
        if (!validName(name)) return
        var upd = Object.assign({}, widgetsConfig[name])
        upd.x = Math.round(x)
        upd.y = Math.round(y)
        widgetsConfig[name] = upd
        save()
    }

    // Centra el widget en una pantalla de tamaño pw x ph.
    function center(name, pw, ph) {
        if (!validName(name)) return
        var s = baseSize(name)
        var cur = widgetsConfig[name]
        var w = s.w * cur.scale
        var h = s.h * cur.scale
        setPos(name, Math.max(0, Math.round((pw - w) / 2)), Math.max(0, Math.round((ph - h) / 2)))
    }

    function restoreDefaults() {
        var d = defaults()
        widgetsConfig.enabled = true
        widgetsConfig.widgetsAlpha = 0.82
        widgetsConfig.clock = d.clock
        widgetsConfig.cpu = d.cpu
        widgetsConfig.mem = d.mem
        widgetsConfig.battery = d.battery
        save()
    }

    function save() {
        var data = {
            enabled: widgetsConfig.enabled,
            widgetsAlpha: widgetsConfig.widgetsAlpha,
            clock: widgetsConfig.clock,
            cpu: widgetsConfig.cpu,
            mem: widgetsConfig.mem,
            battery: widgetsConfig.battery
        }
        var json = JSON.stringify(data)
        saveProc.command = ["sh", "-c",
            "mkdir -p \"$(dirname '" + widgetsConfig.statePath + "')\" && cat > '" + widgetsConfig.statePath + "' << 'QSWIDGETSCONFEOF'\n" +
            json + "\nQSWIDGETSCONFEOF"]
        saveProc.running = true
    }

    Process { id: saveProc }

    Component.onCompleted: {
        loadProc.running = true
    }

    function _cleanWidget(raw, fallback) {
        if (typeof raw !== "object" || raw === null) return fallback
        return {
            enabled: typeof raw.enabled === "boolean" ? raw.enabled : fallback.enabled,
            x: typeof raw.x === "number" ? Math.round(raw.x) : fallback.x,
            y: typeof raw.y === "number" ? Math.round(raw.y) : fallback.y,
            scale: typeof raw.scale === "number" ? clampScale(raw.scale) : fallback.scale,
            useAccent: typeof raw.useAccent === "boolean" ? raw.useAccent : fallback.useAccent
        }
    }

    Process {
        id: loadProc
        command: ["sh", "-c", "cat '" + widgetsConfig.statePath + "' 2>/dev/null || true"]
        property string buf: ""
        stdout: SplitParser { onRead: line => loadProc.buf += line }
        // qmllint disable signal-handler-parameters
        onExited: () => {
            if (loadProc.buf.trim().length > 0) {
                try {
                    var data = JSON.parse(loadProc.buf)
                    var d = widgetsConfig.defaults()
                    if (typeof data.enabled === "boolean") widgetsConfig.enabled = data.enabled
                    if (typeof data.widgetsAlpha === "number") widgetsConfig.widgetsAlpha = Math.max(0.2, Math.min(1.0, data.widgetsAlpha))
                    widgetsConfig.clock = widgetsConfig._cleanWidget(data.clock, d.clock)
                    widgetsConfig.cpu = widgetsConfig._cleanWidget(data.cpu, d.cpu)
                    widgetsConfig.mem = widgetsConfig._cleanWidget(data.mem, d.mem)
                    widgetsConfig.battery = widgetsConfig._cleanWidget(data.battery, d.battery)
                } catch (e) {
                    console.warn("[WidgetsConfig] Error leyendo config guardada:", e)
                }
            }
            widgetsConfig.loaded = true
            loadProc.buf = ""
        }
        // qmllint enable signal-handler-parameters
    }
}
