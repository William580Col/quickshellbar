#!/bin/sh
# Captura de área. Se invoca vía "umbriel msg spawn:<esta-ruta>" desde
# Screenshot.qml.
dir="$HOME/Pictures/Screenshots"
mkdir -p "$dir"
g=$(slurp) || exit 0
[ -n "$g" ] || exit 0
f="$dir/$(date +%Y-%m-%d_%H-%M-%S).png"
grim -g "$g" "$f" && wl-copy < "$f" && notify-send "Captura de pantalla" "Área guardada en $f"
