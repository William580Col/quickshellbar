#!/bin/sh
# Genera la paleta de color a partir de una imagen (matugen) y la aplica:
#   - al acento del shell (accent-color.txt -> Theme.accent)
#   - a fuzzel: persistente (colors.ini, se ve la próxima vez que lo abras)
#
# Esta variante no incluye theming de bordes de ventana (eso es específico
# de Hyprland en este proyecto). Si tu compositor soporta colores de borde
# configurables en caliente, puedes agregar aquí una llamada equivalente.
#
# Uso: apply-colors.sh /ruta/al/wallpaper.png [dark|light]

IMG="$1"
MODE="${2:-dark}"

[ -f "$IMG" ] || { echo "ERROR: no existe la imagen: $IMG" >&2; exit 1; }

if ! command -v matugen >/dev/null 2>&1; then
    echo "ERROR: 'matugen' no está instalado (cargo install matugen)" >&2
    exit 1
fi

matugen image "$IMG" -m "$MODE" || { echo "ERROR: matugen falló" >&2; exit 1; }

echo "OK"
