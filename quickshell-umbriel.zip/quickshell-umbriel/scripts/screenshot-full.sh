#!/bin/sh
# Captura completa. No hace falta pasar por "umbriel msg" (no crea
# ninguna superficie interactiva como slurp), pero se deja como script
# externo por consistencia.
dir="$HOME/Pictures/Screenshots"
mkdir -p "$dir"
f="$dir/$(date +%Y-%m-%d_%H-%M-%S).png"
grim "$f" && wl-copy < "$f" && notify-send "Captura de pantalla" "Guardada en $f"
