import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Wayland
import "../config"
import "../services" as Services

PanelWindow {
    id: root
    property bool open: false
    visible: open
    color: "transparent"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }

    property string activeTab: "local" // "local" | "wallhaven"

    function show() {
        open = true
        Services.Wallpaper.refresh()
        if (activeTab === "wallhaven" && Services.Wallhaven.results.length === 0) Services.Wallhaven.search()
    }
    function hide() { open = false }
    function toggle() { open ? hide() : show() }

    MouseArea { anchors.fill: parent; onClicked: root.hide() }

    Rectangle {
        anchors.centerIn: parent
        width: 760
        height: 560
        radius: Theme.radiusLarge
        color: BarConfig.surfaceColor(Theme.surface)
        border.color: Theme.border
        border.width: 1

        MouseArea { anchors.fill: parent }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 12

            // ---- Encabezado: título + pestañas + modo de ajuste ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 12

                Text {
                    text: "Fondo de pantalla"
                    color: Theme.text
                    font.pixelSize: 16
                    font.bold: true
                }

                Item { Layout.fillWidth: true }

                Text { text: "Ajuste:"; color: Theme.subtext; font.pixelSize: 11 }
                TabPill {
                    label: "Centrada"
                    active: Services.Wallpaper.fitMode === "center"
                    onClicked: Services.Wallpaper.setFitMode("center")
                }
                TabPill {
                    label: "Full"
                    active: Services.Wallpaper.fitMode === "fill"
                    onClicked: Services.Wallpaper.setFitMode("fill")
                }
                TabPill {
                    label: "Estirada"
                    active: Services.Wallpaper.fitMode === "stretch"
                    onClicked: Services.Wallpaper.setFitMode("stretch")
                }
            }

            // ---- Pestañas Local / Wallhaven ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                TabPill {
                    label: "Local"
                    active: root.activeTab === "local"
                    onClicked: root.activeTab = "local"
                }
                TabPill {
                    label: "Wallhaven"
                    active: root.activeTab === "wallhaven"
                    onClicked: {
                        root.activeTab = "wallhaven"
                        if (Services.Wallhaven.results.length === 0) Services.Wallhaven.search()
                    }
                }
                Item { Layout.fillWidth: true }
                Text {
                    visible: root.activeTab === "local"
                    text: "  Aleatorio 🔀"
                    color: Theme.accent
                    font.pixelSize: 12
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: Services.Wallpaper.random()
                    }
                }
            }

            // ==================== PESTAÑA LOCAL (sin cambios) ====================
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                visible: root.activeTab === "local"
                spacing: 8

                Text {
                    text: "Carpeta: " + Services.Wallpaper.directory
                    color: Theme.subtext
                    font.pixelSize: 10
                }

                Text {
                    visible: Services.Wallpaper.list.length === 0
                    text: "No se encontraron imágenes en la carpeta configurada.\nEdita 'directory' en services/Wallpaper.qml o coloca fotos en ~/Pictures/Wallpapers"
                    color: Theme.subtext
                    font.pixelSize: 12
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                    wrapMode: Text.WordWrap
                }

                GridView {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    visible: Services.Wallpaper.list.length > 0
                    clip: true
                    cellWidth: 150
                    cellHeight: 96
                    model: Services.Wallpaper.list

                    delegate: Item {
                        id: cell
                        required property var modelData
                        width: 140
                        height: 86

                        Rectangle {
                            anchors.fill: parent
                            radius: Theme.radiusMedium
                            color: Theme.bgAlt
                            border.width: cell.modelData === Services.Wallpaper.current ? 2 : 1
                            border.color: cell.modelData === Services.Wallpaper.current ? Theme.accent : Theme.border
                            clip: true

                            Image {
                                id: thumbImg
                                anchors.fill: parent
                                anchors.margins: 3
                                source: "file://" + Services.Wallpaper.thumbPathFor(cell.modelData)
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                cache: true
                                sourceSize: Qt.size(300, 180)
                                onStatusChanged: {
                                    if (status === Image.Error && source.toString().indexOf("wallpaper-thumbs") !== -1) {
                                        source = "file://" + cell.modelData
                                    }
                                }
                            }
                        }

                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: { Services.Wallpaper.set(cell.modelData); root.hide() }
                        }
                    }
                }
            }

            // ==================== PESTAÑA WALLHAVEN ====================
            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                visible: root.activeTab === "wallhaven"
                spacing: 8

                // ---- Buscador + categorías ----
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 36
                        radius: Theme.radiusMedium
                        color: Theme.bgAlt
                        border.color: whSearchField.activeFocus ? Theme.accent : Theme.border
                        border.width: 1

                        RowLayout {
                            anchors.fill: parent
                            anchors.margins: 8
                            spacing: 6
                            Text { text: "󰍉"; color: Theme.subtext; font.pixelSize: 12 }
                            TextInput {
                                id: whSearchField
                                Layout.fillWidth: true
                                text: Services.Wallhaven.query
                                color: Theme.text
                                font.pixelSize: 12
                                clip: true
                                onAccepted: Services.Wallhaven.setQuery(text)
                                Keys.onReturnPressed: Services.Wallhaven.setQuery(text)
                            }
                        }
                    }

                    Text { text: "Categoría:"; color: Theme.subtext; font.pixelSize: 11 }
                    TabPill {
                        label: "General"
                        active: Services.Wallhaven.categories.general
                        onClicked: Services.Wallhaven.toggleCategory("general")
                    }
                    TabPill {
                        label: "Anime"
                        active: Services.Wallhaven.categories.anime
                        onClicked: Services.Wallhaven.toggleCategory("anime")
                    }
                    TabPill {
                        label: "Personas"
                        active: Services.Wallhaven.categories.people
                        onClicked: Services.Wallhaven.toggleCategory("people")
                    }
                }

                Text {
                    visible: Services.Wallhaven.lastError.length > 0
                    text: Services.Wallhaven.lastError
                    color: Theme.danger
                    font.pixelSize: 11
                }

                // ---- Resultados ----
                GridView {
                    id: whGrid
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    cellWidth: 178
                    cellHeight: 112
                    model: Services.Wallhaven.results

                    delegate: Item {
                        id: whCell
                        required property var modelData
                        width: 168
                        height: 102

                        Rectangle {
                            anchors.fill: parent
                            radius: Theme.radiusMedium
                            color: Theme.bgAlt
                            border.width: 1
                            border.color: Theme.border
                            clip: true

                            Image {
                                anchors.fill: parent
                                source: whCell.modelData.thumbs ? whCell.modelData.thumbs.small : ""
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                cache: true
                            }

                            Rectangle {
                                anchors.left: parent.left
                                anchors.bottom: parent.bottom
                                anchors.margins: 4
                                width: resLabel.implicitWidth + 8
                                height: resLabel.implicitHeight + 4
                                radius: 4
                                color: Qt.rgba(0, 0, 0, 0.55)
                                Text {
                                    id: resLabel
                                    anchors.centerIn: parent
                                    text: whCell.modelData.resolution || ""
                                    color: "#ffffff"
                                    font.pixelSize: 9
                                }
                            }

                            // Overlay de "descargando…" mientras se aplica esta imagen
                            Rectangle {
                                anchors.fill: parent
                                color: Qt.rgba(0, 0, 0, 0.5)
                                visible: Services.Wallhaven.downloading && whArea.pressed
                                Text {
                                    anchors.centerIn: parent
                                    text: "Descargando…"
                                    color: "#ffffff"
                                    font.pixelSize: 10
                                }
                            }
                        }

                        MouseArea {
                            id: whArea
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: Services.Wallhaven.downloadAndApply(whCell.modelData)
                        }
                    }
                }

                // ---- Paginación ----
                RowLayout {
                    Layout.fillWidth: true
                    Text {
                        text: "‹ Anterior"
                        color: Services.Wallhaven.page > 1 ? Theme.accent : Theme.subtext
                        font.pixelSize: 11
                        MouseArea {
                            anchors.fill: parent
                            anchors.margins: -4
                            cursorShape: Qt.PointingHandCursor
                            enabled: Services.Wallhaven.page > 1
                            onClicked: Services.Wallhaven.prevPage()
                        }
                    }
                    Item { Layout.fillWidth: true }
                    Text {
                        text: Services.Wallhaven.loading ? "Buscando…" : ("Página " + Services.Wallhaven.page + " de " + Services.Wallhaven.lastPage)
                        color: Theme.subtext
                        font.pixelSize: 11
                    }
                    Item { Layout.fillWidth: true }
                    Text {
                        text: "Siguiente ›"
                        color: Services.Wallhaven.page < Services.Wallhaven.lastPage ? Theme.accent : Theme.subtext
                        font.pixelSize: 11
                        MouseArea {
                            anchors.fill: parent
                            anchors.margins: -4
                            cursorShape: Qt.PointingHandCursor
                            enabled: Services.Wallhaven.page < Services.Wallhaven.lastPage
                            onClicked: Services.Wallhaven.nextPage()
                        }
                    }
                }
            }
        }
    }

    // Al terminar de descargar una imagen de Wallhaven, la aplicamos y
    // refrescamos la lista local (para que quede disponible ahí también).
    Connections {
        target: Services.Wallhaven
        function onDownloadFinished(path) {
            Services.Wallpaper.set(path)
            Services.Wallpaper.refresh()
            root.hide()
        }
    }

    // ================= Componente reutilizable: pestaña/pill =================
    component TabPill: Rectangle {
        id: pill
        property string label: ""
        property bool active: false
        signal clicked()

        implicitWidth: labelText.implicitWidth + 20
        implicitHeight: 26
        radius: 13
        color: pill.active ? Theme.accent : Theme.bgAlt
        border.width: pill.active ? 0 : 1
        border.color: Theme.border

        Text {
            id: labelText
            anchors.centerIn: parent
            text: pill.label
            color: pill.active ? Theme.bg : Theme.subtext
            font.pixelSize: 11
            font.bold: pill.active
        }
        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }
}
