# Quickshell para Umbriel WM

Umbriel es un compositor Wayland **muy joven** del proyecto Noctalia
(el mismo proyecto que, curiosamente, dejó de usar Quickshell en su
propio shell). Toda la sintaxis de este port viene verificada contra la
documentación oficial en `docs.noctalia.dev/umbriel/` — no se adivinó
nada, a diferencia de cómo tuvimos que iterar con Hyprland al principio.

Aun así, la propia documentación de Umbriel advierte: *"claves de
configuración, atajos de teclado y comportamiento pueden cambiar entre
versiones"* — es un proyecto en movimiento. Si algo de esto no funciona
tal cual, probablemente cambió algo en tu versión instalada; revisa
`docs.noctalia.dev/umbriel/` para lo más reciente.

## Instalación

**Arch (AUR):**
```bash
yay -S umbriel-git
```

**Debian:** vía el repositorio apt de NickH (revisa las instrucciones
exactas en `docs.noctalia.dev/umbriel/installation/`, cambian con
frecuencia). No está en los repos oficiales de Debian.

## 1. Copiar Quickshell

```bash
mkdir -p ~/.config/quickshell/umbriel
cp -r umbriel/* ~/.config/quickshell/umbriel/
chmod +x ~/.config/quickshell/umbriel/scripts/*.sh
```

## 2. Copiar/fusionar la config de Umbriel

```bash
mkdir -p ~/.config/umbriel
# si no tienes una config propia todavía, arranca de la de ejemplo:
cp /usr/share/umbriel/config.toml ~/.config/umbriel/config.toml
# revisa y fusiona el contenido de umbriel-compositor-config/config.toml
# con el tuyo (NO lo sobrescribas a ciegas)
cp umbriel-compositor-config/colors.toml ~/.config/umbriel/colors.toml
```

**Importante:** el paso de copiar `colors.toml` no es opcional aunque
parezca solo un archivo de respaldo — el `include` de Umbriel exige que
el archivo exista o `umbriel validate` falla con
`include not found: .../colors.toml`. matugen lo sobrescribe con los
colores reales en cuanto elijas tu primer wallpaper desde el shell.

Verifica que la config es válida antes de reiniciar sesión:
```bash
umbriel validate
```

## 3. matugen (theming automático desde el wallpaper)

```bash
cargo install matugen   # no está empaquetado en ningún repo
mkdir -p ~/.config/matugen
# agrega/fusiona el contenido de umbriel/matugen-config.toml en tu
# ~/.config/matugen/config.toml real
```

En `~/.config/fuzzel/fuzzel.ini`, agrega en la sección principal:
```ini
include=~/.config/fuzzel/colors.ini
```

## 4. Reinicia todo por completo (no hot-reload)

```bash
pkill quickshell
umbriel msg config-reload   # o reinicia sesión si tu versión no lo soporta
quickshell -c ~/.config/quickshell/umbriel
```

## Qué se portó y con qué certeza

| Función | Mecanismo en Umbriel | Confirmado contra docs oficiales |
|---|---|---|
| Workspaces (barra) | `umbriel workspaces --json` + `umbriel msg workspace-switch:N` | ✅ Sí |
| Ventana activa | `umbriel windows --json` (campo `focused`) | ⚠️ Nombre de campo inferido por consistencia, no enumerado explícitamente en la doc de IPC |
| Visor de ventanas | `umbriel windows --json` + `window-focus:<id>` / `window-close:<id>` | ✅ Sí |
| Salir | `umbriel msg session-quit:skip-confirmation` | ✅ Sí |
| Captura completa | `grim` directo | ✅ Sí (docs confirman wlr-screencopy nativo) |
| Captura de área | `umbriel msg spawn:<script>` + `slurp`/`grim` | ⚠️ Enrutado por precaución (mismo patrón que salvó a Hyprland); puede que ni haga falta en Umbriel |
| Wallpaper | `awww`/`swww`/`swaybg` vía layer-shell | ✅ Umbriel confirma soporte de layer-shell |
| Bordes de ventana (matugen) | `colors.toml` incluido, recarga automática al guardar | ✅ Sí |
| Blur real en la barra | `[[layer_rule]] match.namespace="^quickshell$" blur=true` | ✅ Sí |
| Reglas de ventana (kitty, mpv, thunar, PiP, calculadora) | `[[window_rule]]` con `match.app_id`/`match.title` | ✅ Sí |
| Mover/redimensionar ventana flotante con mouse | — | ❌ No se encontró una acción explícita en la referencia de Actions; puede que ya funcione arrastrando el borde sin bind |
| Grupos de ventana en pestañas (Super+G) | — | ❌ Sin equivalente encontrado, omitido |
| Zoom de cursor | — | ❌ Sin equivalente encontrado, omitido |
| Pseudotile / togglesplit (dwindle) | — | ❌ El modelo de layout de Umbriel no tiene este concepto exacto |

## Aviso honesto

No se pudo probar nada de esto en vivo (no hay una instancia real de
Umbriel disponible para verificar). Todo está construido leyendo la
documentación oficial línea por línea, pero un compositor tan joven puede
tener comportamiento distinto al documentado, o la documentación puede
quedar desactualizada entre versiones. Cuando lo pruebes, si algo falla,
el mismo método que usamos en Hyprland/Sway/Niri aplica igual aquí:
corre `quickshell -c ~/.config/quickshell/umbriel` en una terminal
visible y pásame el log completo — los `console.warn`/`console.log` que
dejé en cada módulo (`[Workspaces/Umbriel]`, `[Wallpaper]`,
`[WindowSwitcher/Umbriel]`, etc.) apuntan directo a dónde está el
problema.

## Estructura del paquete

```
umbriel/                          copiar a ~/.config/quickshell/umbriel/
  (todo el shell, igual que las otras variantes, con los módulos
   específicos de Umbriel ya adaptados)
umbriel-compositor-config/
  config.toml                     revisar y fusionar en ~/.config/umbriel/config.toml
```
